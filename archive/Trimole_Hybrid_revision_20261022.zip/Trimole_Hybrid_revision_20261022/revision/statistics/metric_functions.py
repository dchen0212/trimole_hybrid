"""Paired scaffold bootstrap of saved predictions; no model inference or fitting."""
import os
for k in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS"]:
    os.environ[k]="1"
from pathlib import Path
import json,hashlib,warnings
import numpy as np,pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score,average_precision_score,mean_absolute_error
R=Path(__file__).resolve().parent
B=2000;METHODS=["trimole","minimol","chemprop"]
BINS=[("MW",300,"<"),("MW",300,">="),("cLogP",3,"<"),("cLogP",3,">="),("TPSA",75,"<"),("TPSA",75,">=")]
def plain(metric,y,p):
    if metric in ["AUROC","AUPRC"] and len(np.unique(y))<2:return np.nan
    if metric=="Spearman":
        if len(np.unique(y))<2 or len(np.unique(p))<2:return np.nan
        return float(spearmanr(y,p).statistic)
    return float({"AUROC":roc_auc_score,"AUPRC":average_precision_score,"MAE":mean_absolute_error}[metric](y,p))
def grouped(x,w):
    order=np.argsort(x,kind="stable")
    sx=x[order];starts=np.r_[0,np.flatnonzero(np.diff(sx)!=0)+1]
    counts=np.add.reduceat(w[:,order],starts,axis=1)
    groups=np.cumsum(np.r_[0,np.diff(sx)!=0])
    inverse=np.empty(len(x),int);inverse[order]=groups
    return counts,inverse,order,starts
def ranks(x,w):
    counts,inverse,_,_=grouped(x,w)
    return (np.cumsum(counts,axis=1)-.5*counts+.5)[:,inverse]
def weighted(metric,y,p,w):
    total=w.sum(axis=1)
    with np.errstate(divide="ignore",invalid="ignore"):
        if metric=="MAE":return (w*np.abs(y-p)).sum(axis=1)/total
        if metric=="Spearman":
            ry=ranks(y,w);rp=ranks(p,w)
            cy=ry-(ry*w).sum(axis=1)[:,None]/total[:,None]
            cp=rp-(rp*w).sum(axis=1)[:,None]/total[:,None]
            return (w*cy*cp).sum(axis=1)/np.sqrt((w*cy**2).sum(axis=1)*(w*cp**2).sum(axis=1))
        counts,_,order,starts=grouped(p,w)
        pos=np.add.reduceat((w*y)[:,order],starts,axis=1)
        npos=pos.sum(axis=1);nneg=total-npos
        if metric=="AUROC":
            neg=counts-pos;below=np.cumsum(neg,axis=1)-neg
            out=(pos*(below+.5*neg)).sum(axis=1)/(npos*nneg)
        else:
            pos=pos[:,::-1];counts=counts[:,::-1]
            pp=np.cumsum(pos,axis=1);nn=np.cumsum(counts,axis=1)
            out=np.nansum(pos*np.divide(pp,nn,out=np.zeros_like(pp),where=nn>0),axis=1)/npos
        out[(npos==0)|(nneg==0)]=np.nan
        return out
def verify():
    rng=np.random.default_rng(42)
    for met in ["AUROC","AUPRC","Spearman","MAE"]:
        y=np.array([0,1,0,1,1,0,1,0.]) if met in ["AUROC","AUPRC"] else np.array([0,0,1,1,2,4,4,6.])
        p=np.array([.2,.7,.5,.7,.2,.1,.9,.5])
        w=rng.multinomial(len(y),np.ones(len(y))/len(y),size=30).astype(float)
        fast=weighted(met,y,p,w)
        for i in range(len(w)):
            idx=np.repeat(np.arange(len(y)),w[i].astype(int))
            ref=plain(met,y[idx],p[idx])
            assert np.isclose(fast[i],ref,atol=1e-12,equal_nan=True),(met,fast[i],ref)
    return "120 weighted bootstrap metric checks matched sklearn/scipy using explicitly repeated rows"
