import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parent/"deps"))
import json,hashlib,collections
import numpy as np,pandas as pd
R=Path(__file__).resolve().parent;P=R.parents[2]
SRC=P/'outputs/subgroup_four_recovery_20261020_v01'
# Import pure metric functions only; do not execute the old analysis loop.
code=(SRC/'analyze_repaired.py').read_text().split('check=verify()')[0];scope={"__file__":str(SRC/"analyze_repaired.py")};exec(code,scope)
plain,weighted=scope['plain'],scope['weighted'];check=scope['verify']()
coverage=json.loads((SRC/'COVERAGE_v02.json').read_text());out=[];audit=[];hashes={}
B=2000
for ti,info in enumerate(coverage):
 task=info['task'];metric=info['metric'];f=pd.read_csv(SRC/'data_v02'/f'{task}_rows.csv',keep_default_na=False,float_precision='round_trip');z=np.load(SRC/'data_v02'/f'{task}_predictions.npz')
 for fp in [SRC/'data_v02'/f'{task}_rows.csv',SRC/'data_v02'/f'{task}_predictions.npz']:hashes[str(fp)]=hashlib.sha256(fp.read_bytes()).hexdigest()
 for mode in ['external','pool']:
  if mode=='external':
   pred={k:z[k] for k in z.files};keep=np.logical_and.reduce([np.isfinite(v).all(axis=0) for v in pred.values()]);rows=f.loc[keep].reset_index(drop=True);pred={k:v[:,keep] for k,v in pred.items()};reference='trimole'
  else:
   d=R/'pool'/task;ready=json.loads((d/'READY.json').read_text());s=pd.read_csv(d/'test.csv',float_precision='round_trip');freeze=json.loads((d/'PREDICTIONS_FROZEN.json').read_text());pred={}
   for run in range(1,6):
    fp=d/f'predictions_run{run}.npz';digest=hashlib.sha256(fp.read_bytes()).hexdigest();assert digest==freeze['prediction_hashes'][fp.name];hashes[str(fp)]=digest
    zz=np.load(fp)
    for k in zz.files:pred.setdefault(k,[]).append(zz[k])
   pred={k:np.stack(v) for k,v in pred.items()};reference='fixed_recipe'
   lookup=collections.defaultdict(collections.deque)
   for i,r in f.iterrows():lookup[str(r.smiles)].append(i)
   ids=[]
   for smi,y in zip(s['smiles'] if 'smiles' in s else s['Drug'],s[ready['test_label_column']]):
    assert lookup[str(smi)],(task,'missing identity',smi)
    candidates=lookup[str(smi)];idx=next((j for j in candidates if np.isclose(float(f.iloc[j].target),y,atol=1e-9,rtol=1e-9)),None)
    assert idx is not None,(task,'label mismatch');candidates.remove(idx);ids.append(idx)
   rows=f.iloc[ids].reset_index(drop=True);assert np.allclose(rows.target.to_numpy(float),s[ready['test_label_column']].to_numpy(float),atol=1e-9)
   saved=json.loads((d/'RESULTS.json').read_text())['rows']
   for k,a in pred.items():
    for ri,p in enumerate(a):assert abs(plain(metric,rows.target.to_numpy(float),p)-next(r['score'] for r in saved if r['method']==k and r['run']==ri+1))<1e-8,(task,k,ri)
  y=rows.target.to_numpy(float);groups=rows.cluster.to_numpy(str);_,inv=np.unique(groups,return_inverse=True);nc=len(np.unique(groups));n=len(y)
  assert all(a.shape[1]==n and np.isfinite(a).all() for a in pred.values())
  points={k:float(np.mean([plain(metric,y,p) for p in a])) for k,a in pred.items()}
  reason=''
  if nc<30:reason='fewer than 30 clusters'
  if metric in ['AUROC','AUPRC'] and min((y==0).sum(),(y==1).sum())<5:reason='fewer than 5 in one class'
  boots={k:np.full(B,np.nan) for k in pred}
  if not reason:
   rng=np.random.default_rng(20261021+ti*10+(mode=='pool'))
   for start in range(0,B,50):
    mult=rng.multinomial(nc,np.full(nc,1/nc),size=min(50,B-start));w=mult[:,inv].astype(float)
    for k,a in pred.items():boots[k][start:start+len(w)]=np.mean(np.stack([weighted(metric,y,p,w) for p in a]),axis=0)
  for k in pred:
   if k==reference:continue
   delta=(boots[reference]-boots[k])*(-1 if metric=='MAE' else 1);valid=delta[np.isfinite(delta)];ok=not reason and len(valid)>=1900
   lo,hi=np.quantile(valid,[.025,.975]) if ok else (np.nan,np.nan)
   note='stored ensemble, not five-run mean' if mode=='external' and task=='bbb_martins' else '1995 matched rows' if task=='solubility_aqsoldb' else 'mean of saved run metrics'
   out.append(dict(analysis=mode,task=task,metric=metric,n=n,clusters=nc,reference=reference,comparator=k,reference_score=points[reference],baseline_score=points[k],delta=(points[reference]-points[k])*(-1 if metric=='MAE' else 1),ci_low=lo,ci_high=hi,valid_bootstraps=len(valid),status='interval' if ok else 'withheld',reason=reason,note=note))
  audit.append(dict(task=task,analysis=mode,n=n,clusters=nc,prediction_shapes={k:list(v.shape) for k,v in pred.items()},points=points))
  pd.DataFrame(out).to_csv(R/'WHOLE_TASK_CI.csv',index=False)
  print(task,mode,n,'done',flush=True)
(R/'INPUT_HASHES.json').write_text(json.dumps(hashes,indent=2));(R/'QA.json').write_text(json.dumps({'metric_validation':check,'analyses':audit,'rows':len(out),'bootstrap_replicates':B,'training_or_inference':False},indent=2))
