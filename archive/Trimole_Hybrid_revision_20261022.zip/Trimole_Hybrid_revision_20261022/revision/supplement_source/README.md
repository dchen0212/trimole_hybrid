Compile main.tex twice with pdflatex. Expected length: 20 pages. This is the supplementary project, not the manuscript root.
