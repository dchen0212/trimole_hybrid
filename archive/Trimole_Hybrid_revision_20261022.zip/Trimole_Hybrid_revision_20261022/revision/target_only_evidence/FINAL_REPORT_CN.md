# 肝细胞清除率：达标结果与交付

五次完整运行的 Spearman 均值为 **0.537833878 ± 0.005849143**（population SD），超过本次目标 0.536，差值 **+0.001833878**。
刚核对的 TDC 肝细胞清除率榜首为 CFA，公布均值 0.536 ± 0.020。这里比较的是公布点估计，没有统计优越性或已获榜单认可的结论。
这是历史已曝光 test 上的 benchmark reuse。每轮配方与融合权重按开发集选择并冻结，但多轮研究本身参考了已知 benchmark 结果，因此不能写成新的独立 test 验证。

| Seed | Spearman |
|---|---:|
| 101 | 0.539106932 |
| 202 | 0.543355204 |
| 303 | 0.531937316 |
| 404 | 0.530181353 |
| 505 | 0.544588587 |

达标方案

优化构象 Uni-Mol 的秩预测占 25%，既有分阶段 KPGT 融合参考的秩预测占 75%。参考内部依次组合冻结 C/K 预测头、规范化图 KPGT 微调和原始图分阶段 KPGT 微调，各级都沿用之前开发集冻结的权重与重新取秩操作。完整路径与权重见 LINEAGE.json。
新 Uni-Mol 使用 MMFF94s/UFF 优化后的构象，从绑定的官方预训练权重开始；开发集选中全层微调、encoder LR 1e-5、head LR 5e-4、log1p 目标 SmoothL1、16 epochs（原 32-epoch 学习率计划的前缀）。五个种子均重新拟合。单独 Uni-Mol 的均值为 0.483023154，达标的是上述融合系统。

核验结果

监督拟合只使用本端点 970 行开发标签；243 行官方 test 全部保留。按规范化完整结构统计，开发集 817 个、test 203 个唯一分子，两者精确匹配为 0，总计 1020 个。这不等同于骨架隔离或完整预训练曝光审计。
三个微调分支的全部 15 个最终模型都有对应种子、拟合行、完整训练记录和当前权重哈希。获胜轮五个 Uni-Mol 模型分别有 193 个非预测头参数张量发生变化，初始编码器参数与官方权重相同，保存模型回放预测差异为 0。冻结 C/K 的 15 个已保存预测头在本次收尾中重新回放，三层融合也逐种子重建；Spearman 另按平均秩相关定义复算。
配方与融合权重的开发选择、预测封存和评分顺序已核对。早期 KPGT 的回执格式与新轮不同，已按它实际保存的哈希绑定和时间记录核验；没有补造缺失字段。两次汇总脚本的格式错误及日志保留在 verifier_history，科学代码、权重、预测和数字均未修改。
CYP3A4 的 12 个保留产物哈希与开始跟踪时一致。下一轮多初始化集成已自动跳过，未启动任何训练；本 Goal 没有待运行的训练进程。

来源与保留范围

当前 train_val/test CSV 与既有归档 TDC 数据包成员逐字节匹配。本轮重新下载 Dataverse 包及元数据的请求返回 HTTP 403，没有取得当前远端发布件的新校验和；原请求回执保留在 official_source_retry_records。完整预训练样本成员仍未排除曝光，不能据当前官方权重字节绑定声称全流程从未见过任何 test 分子。
ALL_ATTEMPTS.csv/JSON 保留 23 个已评分的方法或组合记录以及 1 个未启动的后续方案；单模型和其融合并非互相独立的实验。此前失败、未改善的轮次及全部远端权重保留原位。

使用文件

- RESULTS.csv：五个运行的分数。
- PREDICTIONS_5RUN.csv：243 行真实值及五组预测，便于检查。
- authoritative_predictions/：原始 NPZ 预测，作为精确数值依据。
- LINEAGE.json / ARTIFACT_INDEX.tsv：每个最终模型、预测头与预测的路径和哈希。
- GOAL_COMPLETION_AUDIT.json：逐项要求核验；本地交付另见 FINAL_DELIVERY_RECEIPT.json。
- winning_run_evidence/：获胜轮的冻结、更新、回放和评分回执。
- 完整获胜轮代码、轻量结果包：/mnt/data/projects/trimole_hepatocyte_goal_tracking_20261014_v01/package_unimol_refined_v01（本地有同名副本）。
- 完整训练权重：/mnt/data/projects/trimole_hepatocyte_unimol_refined_geometry_20261014_v02 及 LINEAGE.json 指向的参考运行目录。

可用于汇报的一句话：在仅以肝细胞清除率开发标签进行下游监督训练的复用 benchmark 实验中，开发集选定的优化构象 Uni-Mol/KPGT 融合获得五次 Spearman 0.538 ± 0.006，高于当前 TDC 榜首公布均值 0.536；这一结果属于 benchmark reuse，而非独立 SOTA 确认。

排行榜来源：https://tdcommons.ai/benchmark/admet_group/17clhepa/；核对记录见 PUBLIC_TARGET_AT_COMPLETION.json。
