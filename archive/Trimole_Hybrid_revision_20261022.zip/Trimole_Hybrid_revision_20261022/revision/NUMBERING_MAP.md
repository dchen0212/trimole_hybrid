# Supplementary numbering map

Numbers follow the order of tables and figures in the 20-page supplementary PDF. The manuscript and response letter use these same identifiers.

| Type | New | Previous | Title |
|---|---|---|---|
| table | S1 | S19 | Dataset sources, endpoint definitions and coverage |
| table | S2 | S2 | Historical task-specific model components |
| table | S3 | S31 | Trimole-Hybrid, MiniMol and Chemprop across 22 tasks (mean $\pm$ SD) |
| table | S4 | S34 | Seven-method comparison on identical task/run inputs (mean $\pm$ population SD) |
| table | S5 | S33 | Chemprop configurations selected using seed 101 |
| table | S6 | S40 | Paired differences against MiniMol and Chemprop (95\% intervals) |
| table | S7 | S41 | Fixed recipe versus FLAML: paired differences on identical inputs |
| table | S8 | S37c | Relative changes from the reselected single-candidate reference (\%) |
| table | S9 | S37d | Validation ranks for the global model-family choice |
| table | S10 | S42 | Mean ranks of 27 methods across 20 development tasks |
| table | S11 | S43 | Seven-method comparison on six reused tests (five-run mean $\pm$ population SD) |
| table | S12 | S20 | Source tasks for the two historical transfer models |
| table | S13 | S36 | Results for the two target-only replacement models |
| table | S14 | S38 | Molecular-subgroup scores and paired differences across 22 tasks |
| figure | S1 | S6 | Expanded FLAML and the Trimole-Hybrid reference across 22 tasks |
| figure | S2 | S7 | Trimole-Hybrid, MiniMol and Chemprop across 22 tasks, grouped by official metric |
| figure | S3 | S8 | Historical and target-only results against the archived public top-1 reference (CFA) |
