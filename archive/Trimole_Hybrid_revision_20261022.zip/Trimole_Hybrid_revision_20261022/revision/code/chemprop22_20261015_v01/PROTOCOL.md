# Chemprop 22-task benchmark, v01, 2026-10-15

Official Chemprop 2.3.1 directed bond-message-passing network, trained from scratch, target task only. No pretrained encoder or family-transfer data. Official CLI, default bond graph features, normalized-sum aggregation and Adam with warmup/exponential LR decay; no extra molecular descriptors.

Per task: 20 configurations, including official default and 19 seeded random configurations. Search seed 20261015. Depth 2–6; hidden widths 300/600/900/1200 (explicit resource-bounded subset of the official search space); FFN hidden layers 1/2; dropout 0–0.4; max LR log-uniform 1e-4–1e-2; initial and final LR 0.1 times max LR. Batch 64, up to 50 epochs, validation patience 20. All candidates use the same seed101 development split. At least 16 successful trials required; failures recorded, no silent budget reduction. Candidate list is written before training.

Development train/validation partitions are the exact saved scaffold splits used by the KPGT baseline, independently verified against the train_val hash; no test partition is supplied to training. Regression target scaling is official train-only scaling. Checkpoint and configuration selection use task-native validation AUROC, average precision, MAE or Spearman. Two custom metrics register average precision and Spearman without altering the model or optimizer. CSV logger replaces TensorBoard solely for auditability. Metrics must match sklearn/scipy on fixtures before launch.

After the winning configuration is frozen, run seeds 101,202,303,404,505 with their saved development splits. Reuse the already-trained winning seed101 trial, do not train it twice. Primary result is mean and population SD over these five single models. The five-model prediction ensemble is a separately declared secondary result, with no fabricated SD and no test-driven choice between it and the primary result. No final full-development refit; validation-best checkpoints are retained, following the official training interface.

Official test labels are prohibited from fitting and inference processes. Evaluation is a separate process after the configuration, all five models and predictions are frozen. Keyed row checks and prediction hashes are required. All test rows retained. Solubility uses the existing disclosed two-structure representation correction, and all 1997 test rows. Source and corrected input strings remain in ROWS.json.

This is a controlled external baseline on reused benchmark tests, not an equal-budget independent comparison to historical Trimole scores. Do not claim an exact reproduction of a published Chemprop leaderboard result. Subsequent numerical repairs must be versioned. No budget/recipe changes may be based on test performance.

Sources:
https://chemprop.readthedocs.io/en/latest/tutorial/cli/train.html
https://chemprop.readthedocs.io/en/main/tutorial/cli/hpopt.html
https://github.com/chemprop/chemprop/tree/v2.3.1
