import os,json,subprocess,sys,time,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent;PY=R/'env/bin/python';env=os.environ.copy();env['CUDA_VISIBLE_DEVICES']='GPU-8dccd0a6-2c1e-0e9a-dda8-105662f17745'
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:env[k]='4'
def state(stage,**kw):(R/'CONTROLLER_STATUS.json').write_text(json.dumps({'stage':stage,**kw},indent=2))
try:
 state('SMOKE_TEST')
 with (R/'smoke.log').open('x') as f:subprocess.run([str(PY),str(R/'smoke.py')],env=env,cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
 assert (R/'SMOKE_PASS.json').exists()
 (R/'ENVIRONMENT_FREEZE.txt').write_text(subprocess.check_output([str(PY),'-m','pip','freeze'],text=True))
 (R/'RUN_FREEZE.json').write_text(json.dumps({p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in list(R.glob('*.py'))+[R/'PROTOCOL.md',R/'SEARCH_CONFIGS.json',R/'ENVIRONMENT_FREEZE.txt']},indent=2))
 state('TRAINING')
 with (R/'training.log').open('x') as f:subprocess.run([str(PY),str(R/'run_benchmark.py')],env=env,cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
 rows=[json.loads(p.read_text()) for p in sorted((R/'chemprop').glob('*/evaluation/RESULTS.json'))]
 (R/'FINAL_RESULTS.json').write_text(json.dumps({'results':rows,'complete':len(rows)==22},indent=2));state('COMPLETE' if len(rows)==22 else 'FINISHED_WITH_FAILURES',completed=len(rows))
except Exception as e:state('FAILED',error=repr(e));raise
