import os,sys
from pathlib import Path
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='4'
def guard(event,args):
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(os.fsdecode(args[0]))
        if p.name=='test.csv' and '/data/admet_group/' in str(p):raise PermissionError('Official test labels forbidden during fit and prediction')
sys.addaudithook(guard)
import torch
torch.set_num_threads(4)
import custom_metrics
import chemprop.cli.train as train_cli
from lightning.pytorch.loggers import CSVLogger
train_cli.TensorBoardLogger=lambda save_dir,name,**kwargs:CSVLogger(save_dir,name)
from chemprop.cli.main import main
if __name__=='__main__':main()
