from pathlib import Path
import json,csv,subprocess,sys
import numpy as np,torch
from scipy.stats import spearmanr
from sklearn.metrics import average_precision_score
from custom_metrics import Spearman,AveragePrecision
from run_benchmark import fit,command
R=Path(__file__).resolve().parent
p=torch.tensor([[.1],[.5],[.5],[.8],[.2]]);y=torch.tensor([[0.],[1.],[0.],[1.],[1.]]);mask=torch.ones_like(y,dtype=torch.bool)
for c,fn in [(Spearman,lambda a,b:spearmanr(a,b).statistic),(AveragePrecision,average_precision_score)]:
 m=c();m.update(p[:2],y[:2],mask[:2]);m.update(p[2:],y[2:],mask[2:]);v=float(m.compute());ref=float(fn(y.numpy().ravel(),p.numpy().ravel()));assert abs(v-ref)<1e-6,(c,v,ref)
assert torch.cuda.is_available();z=torch.ones(8,8,device='cuda');assert (z@z).sum().item()==512
cfg=json.loads((R/'SEARCH_CONFIGS.json').read_text())[0];tasks=list(csv.DictReader((R/'SUBMITTED_TABLE1.csv').open()));records=[]
for name in ['bioavailability_ma','cyp2c9_substrate_carbonmangels','clearance_hepatocyte_az','caco2_wang']:
 t=next(t for t in tasks if t['task']==name);o=R/'smoke'/name;rec=fit(t,cfg,101,o,3);records.append(rec)
 (o/'synthetic.csv').write_text('Drug\nCCO\nc1ccccc1\n')
 command(['predict','--test-path',str(o/'synthetic.csv'),'--smiles-columns','Drug','--model-paths',rec['model'],'--preds-path',str(o/'predictions.csv'),'--accelerator','gpu','--devices','1'],o/'predict.log')
 import pandas as pd
 a=pd.read_csv(o/'predictions.csv');assert len(a)==2 and np.isfinite(a.Y).all()
(R/'SMOKE_PASS.json').write_text(json.dumps({'metrics_match_scipy_sklearn':True,'four_task_types_fit_and_reload_predict':records,'cuda':torch.cuda.get_device_name(),'torch':torch.__version__},indent=2));print('SMOKE_PASS',flush=True)
