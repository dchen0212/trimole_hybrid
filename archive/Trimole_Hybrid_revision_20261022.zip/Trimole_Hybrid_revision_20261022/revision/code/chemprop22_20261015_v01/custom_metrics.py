import torch
import torchmetrics
from chemprop.nn.metrics import MetricRegistry,ClassificationMixin
@MetricRegistry.register('ap')
class AveragePrecision(ClassificationMixin,torchmetrics.classification.BinaryAveragePrecision):
    pass
@MetricRegistry.register('spearman')
class Spearman(torchmetrics.SpearmanCorrCoef):
    higher_is_better=True
    def __init__(self,task_weights=1.0,**kwargs):
        super().__init__()
        self.register_buffer('task_weights',torch.as_tensor(task_weights,dtype=torch.float).view(1,-1))
    def update(self,preds,targets,mask=None,*args,**kwargs):
        mask=torch.ones_like(targets,dtype=torch.bool) if mask is None else mask
        super().update(preds[mask].flatten(),targets[mask].flatten())
