from pathlib import Path
import json,sys,hashlib
import pandas as pd,numpy as np
from sklearn.metrics import roc_auc_score,average_precision_score,mean_absolute_error
from scipy.stats import spearmanr
R=Path(__file__).resolve().parent;task=sys.argv[1];d=R/'chemprop'/task;out=d/'evaluation';out.mkdir(exist_ok=True)
if (out/'RESULTS.json').exists():sys.exit()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
s=json.loads((d/'PREDICTIONS_FROZEN.json').read_text());assert len(s['runs'])==5
(out/'ACCESS_STARTED.json').write_text(json.dumps({'seal_sha256':sha(d/'PREDICTIONS_FROZEN.json')}))
t=pd.read_csv(R.parent/'trimole_hybrid_revision_20260915/data/admet_group'/task/'test.csv');rr=json.loads((d/'ROWS.json').read_text());assert t.Drug.tolist()==[r['smiles'] for r in rr]
a=next(x for x in json.loads((R/'current_table.json').read_text())['results'] if x['task']==task);metric=a['metric'];fn={'AUROC':roc_auc_score,'AUPRC':average_precision_score,'MAE':mean_absolute_error,'Spearman':lambda y,p:spearmanr(y,p).statistic}[metric];vals=[];preds=[]
for rec in s['runs']:
 p=d/f"seed{rec['seed']}/predictions.npz";assert sha(p)==rec['prediction_sha256'];z=np.load(p);assert z['row_ids'].tolist()==[r['row_id'] for r in rr];pred=z['prediction'];preds.append(pred);vals.append(float(fn(t.Y,pred)))
m=float(np.mean(vals));sd=float(np.std(vals));result={'task':task,'metric':metric,'mean':m,'population_sd':sd,'seed_scores':vals,'current_table_mean':a['current_mean'],'current_table_sd':a['current_sd'],'current_advantage':m-a['current_mean'] if metric=='MAE' else a['current_mean']-m,'five_seed_prediction_ensemble_score':float(fn(t.Y,np.mean(preds,axis=0))),'interpretation':'benchmark reuse; primary mean and SD of 5 runs, secondary ensemble score has no fabricated SD','rows':len(t)}
(out/'RESULTS.json').write_text(json.dumps(result,indent=2));print(json.dumps(result),flush=True)
