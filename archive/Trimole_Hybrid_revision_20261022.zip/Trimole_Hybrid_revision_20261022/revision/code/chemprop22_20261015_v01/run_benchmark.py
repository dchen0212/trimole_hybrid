import os,sys,json,csv,time,hashlib,subprocess,traceback
from pathlib import Path
import numpy as np,pandas as pd
R=Path(__file__).resolve().parent;S=Path('/mnt/data/projects/trimole_hybrid_revision_20260915/data/admet_group');ST=Path('/mnt/data/projects/trimole_dual3090_transfer_20261011_v01/staging/structures');PY=R/'env/bin/python'
ENV=os.environ.copy();ENV['CUDA_VISIBLE_DEVICES']='GPU-8dccd0a6-2c1e-0e9a-dda8-105662f17745';ENV['OMP_NUM_THREADS']='4';ENV['MKL_NUM_THREADS']='4';ENV['OPENBLAS_NUM_THREADS']='4';ENV['WANDB_MODE']='disabled'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(x,f,indent=2,allow_nan=False)
def command(args,out):
 with Path(out).open('x') as f:subprocess.run([str(PY),str(R/'cli_guard.py'),*args],env=ENV,stdout=f,stderr=subprocess.STDOUT,cwd=R,check=True)
def fit(task,cfg,seed,out,epochs=50):
 out.mkdir(parents=True,exist_ok=True)
 if (out/'FIT.json').exists():return json.loads((out/'FIT.json').read_text())
 metric=task['metric'];m={'AUROC':'roc','AUPRC':'ap','Spearman':'spearman','MAE':'mae'}[metric];d=R/'prepared'/task['task'];start=time.monotonic()
 args=['train','--data-path',str(d/'development.csv'),'--smiles-columns','Drug','--target-columns','Y','--splits-file',str(d/f'split{seed}.json'),'--task-type','classification' if metric in ['AUROC','AUPRC'] else 'regression','--metrics',m,'--tracking-metric',m,'--epochs',str(epochs),'--patience','20','--pytorch-seed',str(seed),'--data-seed',str(seed),'--batch-size','64','--num-workers','0','--accelerator','gpu','--devices','1','--output-dir',str(out/'model')]
 for k,v in cfg.items():args += ['--'+k,str(v)]
 command(args,out/'training.log')
 models=list((out/'model').rglob('best.pt'));assert len(models)==1
 logs=list((out/'model').rglob('metrics.csv'));assert len(logs)==1
 df=pd.read_csv(logs[0]);col='val/'+m;v=df[col].dropna().to_numpy();assert len(v)>0 and np.isfinite(v).all();score=float(v.min() if metric=='MAE' else v.max())
 rec={'validation_score':score,'seed':seed,'configuration':cfg,'seconds':time.monotonic()-start,'model':str(models[0]),'model_sha256':sha(models[0]),'epochs_observed':int(df.epoch.max()+1),'metric':metric,'split_sha256':sha(d/f'split{seed}.json')};write(out/'FIT.json',rec);return rec

def taskrun(t):
 task=t['task'];d=R/'chemprop'/task;d.mkdir(parents=True,exist_ok=True)
 if (d/'PREDICTIONS_FROZEN.json').exists():return
 prep=R/'prepared'/task;assert (prep/'READY.json').exists()
 configs=json.loads((R/'SEARCH_CONFIGS.json').read_text());trials=[]
 for i,c in enumerate(configs):
  o=d/f'trial{i:02d}'
  try:rec=fit(t,c,101,o);trials.append(dict(rec,trial=i));print(task,'TRIAL',i,rec['validation_score'],flush=True)
  except Exception as e:
   if not (o/'FAILED.json').exists():write(o/'FAILED.json',{'error':repr(e),'traceback':traceback.format_exc()})
   print(task,'TRIAL_FAILED',i,repr(e),flush=True)
 assert len(trials)>=16,'Fewer than 16 of 20 valid configurations; investigate before reporting'
 winner=sorted(trials,key=lambda x:(x['validation_score'] if t['metric']=='MAE' else -x['validation_score'],x['trial']))[0]
 if not (d/'CONFIGURATION_FROZEN.json').exists():write(d/'CONFIGURATION_FROZEN.json',{'winner':winner,'successful_trials':len(trials),'total_trials':20,'selection':'validation only; all trials same seed101 development split'})
 rr=json.loads((prep/'ROWS.json').read_text());write(d/'ROWS.json',rr) if not (d/'ROWS.json').exists() else None
 fits=[]
 for seed in [101,202,303,404,505]:
  o=d/f'seed{seed}'
  if seed==101 and not o.exists():o.symlink_to(d/f"trial{winner['trial']:02d}",target_is_directory=True)
  rec=fit(t,winner['configuration'],seed,o);fits.append(rec)
 write(d/'ALL_MODELS_FROZEN.json',{'fits':fits,'configuration_sha256':sha(d/'CONFIGURATION_FROZEN.json')}) if not (d/'ALL_MODELS_FROZEN.json').exists() else None
 runs=[]
 for rec in fits:
  seed=rec['seed'];o=d/f'seed{seed}';pred=o/'predictions.npz'
  if not pred.exists():
   command(['predict','--test-path',str(prep/'inference.csv'),'--smiles-columns','Drug','--model-paths',rec['model'],'--preds-path',str(o/'raw_predictions.csv'),'--accelerator','gpu','--devices','1'],o/'predict.log')
   p=pd.read_csv(o/'raw_predictions.csv');inp=pd.read_csv(prep/'inference.csv');assert p.Drug.tolist()==inp.Drug.tolist();y=p.Y.to_numpy(float);assert len(y)==len(rr) and np.isfinite(y).all()
   np.savez_compressed(pred,row_ids=np.array([r['row_id'] for r in rr]),prediction=y)
  runs.append({'seed':seed,'prediction_sha256':sha(pred),'fit_sha256':sha(o/'FIT.json'),'model_sha256':rec['model_sha256']})
 write(d/'PREDICTIONS_FROZEN.json',{'runs':runs,'rows_sha256':sha(d/'ROWS.json'),'labels_used_for_selection':False,'config_sha256':sha(d/'CONFIGURATION_FROZEN.json')})
 print(task,'PREDICTIONS_FROZEN',flush=True)
 subprocess.run([str(PY),str(R/'evaluate_task.py'),task],env=ENV,check=True)

if __name__=='__main__':
 tasks=list(csv.DictReader((R/'SUBMITTED_TABLE1.csv').open()));status={}
 if len(sys.argv)>1 and sys.argv[1]=='smoke':
  t=tasks[0];fit(t,json.loads((R/'SEARCH_CONFIGS.json').read_text())[0],101,R/'smoke',3);print('SMOKE_PASS');sys.exit()
 for t in tasks:
  try:taskrun(t);status[t['task']]='COMPLETE'
  except Exception as e:status[t['task']]='FAILED';traceback.print_exc()
  (R/'STATUS.json').write_text(json.dumps(status,indent=2))
