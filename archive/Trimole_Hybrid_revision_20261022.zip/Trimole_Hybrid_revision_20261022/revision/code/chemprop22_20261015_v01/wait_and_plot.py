from pathlib import Path
import json,subprocess,time,sys,csv
R=Path(__file__).resolve().parent
for i in range(4320):
 try:
  p=subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=15','dachen-server','cat /mnt/data/projects/trimole_chemprop22_20261015_v01/FINAL_RESULTS.json'],capture_output=True,text=True,timeout=30)
  if p.returncode==0:
   x=json.loads(p.stdout)
   if x['complete']:
    (R/'FINAL_RESULTS.json').write_text(p.stdout);base=json.loads((R.parent/'minimol_complete22_comparison_20261014_v01/LATEST.json').read_text());cp={z['task']:z for z in x['results']};rows=[]
    for z in base['results']:
     if z['method']=='MiniMol':rows.append(dict(z,chemprop_mean=cp[z['task']]['mean'],chemprop_sd=cp[z['task']]['population_sd']))
    assert len(rows)==22
    (R/'COMBINED.json').write_text(json.dumps({'results':rows},indent=2))
    with (R/'THREE_MODEL_COMPARISON.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
    subprocess.run([sys.executable,str(R/'plot_three.py')],check=True)
    (R/'FIGURES_READY.json').write_text(json.dumps({'tasks':22,'visual_review_pending':True}));break
 except Exception as e:print(repr(e),flush=True)
 time.sleep(120)
