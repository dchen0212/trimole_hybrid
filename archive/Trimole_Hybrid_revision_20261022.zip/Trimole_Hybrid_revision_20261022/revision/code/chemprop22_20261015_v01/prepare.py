from pathlib import Path
import json,hashlib,csv,random
import pandas as pd
from rdkit import Chem
R=Path(__file__).resolve().parent;B=R.parent;S=B/'trimole_hybrid_revision_20260915/data/admet_group';SIDE=B/'trimole_dual3090_transfer_20261011_v01/staging/structures';K=B/'trimole_kpgt_finetune22_20261014_v01'
repair=json.loads((B/'trimole_solubility_structure_repair_20261014_v01/STRUCTURE_REPAIR.json').read_text())['mapping']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
for f in ['SUBMITTED_TABLE1.csv','current_table.json']:(R/f).write_bytes((K/f).read_bytes())
for t in csv.DictReader((R/'SUBMITTED_TABLE1.csv').open()):
 task=t['task'];d=R/'prepared'/task;d.mkdir(parents=True,exist_ok=True);df=pd.read_csv(S/task/'train_val.csv');h=json.loads((SIDE/(task+'.json')).read_text());assert h['labels_present'] is False
 assert all(Chem.MolFromSmiles(s) is not None for s in df.Drug)
 df[['Drug','Y']].to_csv(d/'development.csv',index=False)
 inputs=[repair.get(r['raw_smiles'],r['raw_smiles']) for r in h['rows']];assert all(Chem.MolFromSmiles(s) is not None for s in inputs)
 pd.DataFrame({'Drug':inputs}).to_csv(d/'inference.csv',index=False)
 rows=[{'row_id':f'{task}:test:{r["source_row"]}','smiles':r['raw_smiles'],'model_input_smiles':s} for r,s in zip(h['rows'],inputs)];(d/'ROWS.json').write_text(json.dumps(rows,indent=2))
 kr=K/'kpgt_ft'/task if task!='solubility_aqsoldb' else B/'trimole_solubility_structure_repair_20261014_v01/kpgt_ft/kpgt_ft'/task
 for seed in [101,202,303,404,505]:
  f=kr/f'seed{seed}/SPLIT.json';x=json.loads(f.read_text());assert x['train_val_sha256']==sha(S/task/'train_val.csv');tr=x['train'];va=x['valid'];assert set(tr).isdisjoint(va) and sorted(tr+va)==list(range(len(df)))
  if t['metric'] in ['AUROC','AUPRC']:assert set(df.Y.iloc[tr])==set(df.Y.iloc[va])=={0,1}
  (d/f'split{seed}.json').write_text(json.dumps([{'train':tr,'val':va,'test':[]}]))
 (d/'READY.json').write_text(json.dumps({'dev_sha256':sha(S/task/'train_val.csv'),'rows':len(rows),'test_labels_read':False,'splits':'same keyed TDC scaffold splits as completed KPGT fine-tuning','repaired_rows':sum(a['smiles']!=a['model_input_smiles'] for a in rows)},indent=2))
rng=random.Random(20261015);configs=[{'depth':3,'message-hidden-dim':300,'ffn-hidden-dim':300,'ffn-num-layers':1,'dropout':0,'max-lr':.001,'init-lr':.0001,'final-lr':.0001}]
for i in range(19):
 lr=10**rng.uniform(-4,-2);configs.append({'depth':rng.choice([2,3,4,5,6]),'message-hidden-dim':rng.choice([300,600,900,1200]),'ffn-hidden-dim':rng.choice([300,600,900,1200]),'ffn-num-layers':rng.choice([1,2]),'dropout':rng.choice([0,0,0,.1,.2,.3,.4]),'max-lr':lr,'init-lr':lr*.1,'final-lr':lr*.1})
(R/'SEARCH_CONFIGS.json').write_text(json.dumps(configs,indent=2));print('PREPARED 22 tasks; 20 configs')
