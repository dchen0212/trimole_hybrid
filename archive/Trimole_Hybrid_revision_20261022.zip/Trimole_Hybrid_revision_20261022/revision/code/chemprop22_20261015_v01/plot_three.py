from pathlib import Path
import json,hashlib,ast,shutil
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import MaxNLocator
from PIL import Image,ImageOps,ImageDraw
from pypdf import PdfReader,PdfWriter,Transformation
R=Path(__file__).resolve().parent;OLD=R.parent/'minimol_figure22_20261014_v01'
src=R/'COMBINED.json';rows=[x for x in json.loads(src.read_text())['results'] if x['method']=='MiniMol'];assert len(rows)==22
names=ast.literal_eval(next(n.value for n in ast.parse((OLD/'plot.py').read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='names' for t in n.targets)))
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial'],'font.size':8,'axes.linewidth':.7,'axes.spines.right':False,'axes.spines.top':False,'legend.frameon':False,'svg.fonttype':'none','pdf.fonttype':42})
colors=['#9CC8E2','#C9B7E8','#F3C983'];edges=['#6C8A9C','#8B7FA0','#A58A5D'];labels=['Trimole-Hybrid','MiniMol','Chemprop']
fig=plt.figure(figsize=(180/25.4,236/25.4));grid=fig.add_gridspec(3,2,left=.26,right=.98,bottom=.14,top=.91,height_ratios=[8,5,4],width_ratios=[1,1],hspace=.48,wspace=.5)
# Three horizontal groups, spanning width. MAE uses a separate five-panel strip below.
fig.clear();gs=fig.add_gridspec(4,1,left=.28,right=.97,top=.915,bottom=.17,height_ratios=[8,5,4,2.5],hspace=.75)
for i,metric in enumerate(['AUROC','AUPRC','Spearman']):
 ax=fig.add_subplot(gs[i]);group=[x for x in rows if x['metric']==metric]
 for j,r in enumerate(group):
  vals=[r['current_table_mean'],r['mean'],r['chemprop_mean']];errs=[r['current_table_sd'],r['population_sd'],r['chemprop_sd']];yy=[j-.17,j,j+.17]
  ax.plot(vals,yy,color='#BBBBBB',lw=.8,zorder=1)
  for k in range(3):ax.errorbar(vals[k],yy[k],xerr=errs[k],fmt=['o','s','^'][k],ms=4.5,mfc=colors[k],mec=edges[k],mew=.65,ecolor=edges[k],elinewidth=.85,capsize=2,zorder=3)
 ax.set_yticks(range(len(group)),[names[r['task']] for r in group],fontsize=7.4);ax.set_ylim(len(group)-.55,-.55);ax.tick_params(axis='y',length=0,pad=7)
 lows=[r[k]-r[e] for r in group for k,e in [('mean','population_sd'),('current_table_mean','current_table_sd'),('chemprop_mean','chemprop_sd')]];highs=[r[k]+r[e] for r in group for k,e in [('mean','population_sd'),('current_table_mean','current_table_sd'),('chemprop_mean','chemprop_sd')]]
 lo=min(lows);hi=max(highs);pad=(hi-lo)*.08;ax.set_xlim(lo-pad,min(1.01,hi+pad));ax.xaxis.set_major_locator(MaxNLocator(5));ax.grid(axis='x',color='#EEEEEE',lw=.6);ax.set_axisbelow(True)
 ax.set_title(f'{metric} · higher is better',loc='left',fontsize=9,pad=8);ax.text(-.35,1.05,chr(97+i),transform=ax.transAxes,fontweight='bold',fontsize=11)
mae=[r for r in rows if r['metric']=='MAE'];inner=gs[3].subgridspec(1,5,wspace=.65)
for i,r in enumerate(mae):
 ax=fig.add_subplot(inner[i]);vals=[r['current_table_mean'],r['mean'],r['chemprop_mean']];errs=[r['current_table_sd'],r['population_sd'],r['chemprop_sd']]
 ax.plot(vals,[-.17,0,.17],c='#BBBBBB',lw=.8)
 for k in range(3):ax.errorbar(vals[k],[-.17,0,.17][k],xerr=errs[k],fmt=['o','s','^'][k],ms=4.5,mfc=colors[k],mec=edges[k],mew=.65,ecolor=edges[k],elinewidth=.85,capsize=2)
 lo=min(v-e for v,e in zip(vals,errs));hi=max(v+e for v,e in zip(vals,errs));pad=(hi-lo)*.2;ax.set_xlim(lo-pad,hi+pad);ax.set_ylim(.5,-.5);ax.set_yticks([]);ax.spines['left'].set_visible(False);ax.xaxis.set_major_locator(MaxNLocator(2));ax.tick_params(axis='x',labelsize=6.5);ax.set_title(names[r['task']],fontsize=7.3,pad=6)
 if i==0:
  ax.text(-2.8,1.55,'d',transform=ax.transAxes,fontweight='bold',fontsize=11)
  ax.text(0,1.55,'MAE · lower is better (task-specific scales)',transform=ax.transAxes,fontsize=9)
handles=[Line2D([],[],marker=m,color=e,mfc=c,mec=e,lw=.8,markersize=5,label=l) for m,c,e,l in zip(['o','s','^'],colors,edges,labels)]
fig.legend(handles=handles,loc='upper center',bbox_to_anchor=(.57,.98),ncol=3,fontsize=9)
for y,t in [(.095,'† Target-only retraining; other current-table entries are historical.'),(.073,'‡ External models: all 1,997 test rows; two corrected structures.'),(.051,'Points: mean ± SD. Reused benchmark tests; training and search budgets differ.')]:fig.text(.08,y,t,fontsize=6.8,color='#46515D')
for ext in ['pdf','svg','png']:fig.savefig(R/f'trimole_minimol_chemprop22.{ext}',dpi=600)
plt.close(fig)
