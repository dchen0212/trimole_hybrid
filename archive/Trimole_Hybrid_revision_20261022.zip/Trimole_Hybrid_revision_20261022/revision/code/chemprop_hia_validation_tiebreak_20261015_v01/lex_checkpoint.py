import math,torch
from lightning.pytorch.callbacks import ModelCheckpoint
class ValidationTieCheckpoint(ModelCheckpoint):
    """Max validation AUROC, then min validation loss, then earliest epoch."""
    def __init__(self,*args,**kwargs):
        args=list(args)
        if len(args)>=3:args[2]='val/selection_order'
        else:kwargs['monitor']='val/selection_order'
        kwargs['mode']='max'
        super().__init__(*args,**kwargs)
        self.lex_best=None;self.ordinal=0;self.seen={}
    def _monitor_candidates(self,trainer):
        d=super()._monitor_candidates(trainer)
        if 'val/roc' in d and 'val_loss' in d:
            auc=float(d['val/roc']);loss=float(d['val_loss']);ep=int(trainer.current_epoch)
            assert math.isfinite(auc) and math.isfinite(loss)
            key=(auc,-loss,-ep)
            if key not in self.seen:
                if self.lex_best is None or key>self.lex_best:self.lex_best=key;self.ordinal+=1;value=self.ordinal
                else:value=-1
                self.seen[key]=value
            d['val/selection_order']=torch.tensor(float(self.seen[key]))
        return d
    def state_dict(self):
        d=super().state_dict();d.update(lex_best=self.lex_best,ordinal=self.ordinal);return d
