from pathlib import Path
import json,shutil
old=Path('/mnt/data/projects/trimole_chemprop22_20261015_v01');r=Path('/mnt/data/projects/trimole_chemprop_hia_validation_tiebreak_20261015_v01');r.mkdir(exist_ok=False)
for n in ['env','prepared','current_table.json','SUBMITTED_TABLE1.csv']:(r/n).symlink_to(old/n,target_is_directory=(old/n).is_dir())
for n in ['custom_metrics.py','evaluate_task.py']:shutil.copy2(old/n,r/n)
s=(old/'cli_guard.py').read_text().replace("='4'","='2'").replace('torch.set_num_threads(4)','torch.set_num_threads(2)').replace('from chemprop.cli.main import main','from lex_checkpoint import ValidationTieCheckpoint\ntrain_cli.ModelCheckpoint=ValidationTieCheckpoint\nfrom chemprop.cli.main import main');(r/'cli_guard.py').write_text(s)
s=(old/'run_benchmark.py').read_text().replace("='4'","='2'").replace("='GPU-8dccd0a6-2c1e-0e9a-dda8-105662f17745'","=''").replace("'--patience','20'","'--patience','50'").replace("'--accelerator','gpu'","'--accelerator','cpu'");(r/'run_benchmark.py').write_text(s)
(r/'ORIGINAL_CONFIGURATION.json').write_text((old/'chemprop/hia_hou/CONFIGURATION_FROZEN.json').read_text())
print(r)
