import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS']:os.environ[k]='2'
os.environ['CUDA_VISIBLE_DEVICES']=''
import json,time,csv,traceback,subprocess
from pathlib import Path
import torch
from types import SimpleNamespace
from lex_checkpoint import ValidationTieCheckpoint
import run_benchmark as b
R=Path(__file__).resolve().parent

def status(stage,**kw):(R/'STATUS.json').write_text(json.dumps({'stage':stage,**kw},indent=2))
try:
 cb=ValidationTieCheckpoint(dirpath=str(R/'callback_fixture'),monitor='val/roc',save_last=True)
 values=[]
 for ep,auc,loss in [(0,1.,.4),(1,1.,.2),(2,.99,.01),(3,1.,.2),(4,1.,.1)]:
  t=SimpleNamespace(current_epoch=ep,global_step=ep,callback_metrics={'val/roc':torch.tensor(auc,dtype=torch.float64),'val_loss':torch.tensor(loss,dtype=torch.float64)})
  values.append(float(cb._monitor_candidates(t)['val/selection_order']))
 assert values==[1.,2.,-1.,-1.,3.],values
 b.write(R/'CALLBACK_CHECK.json',{'values':values,'PASS':True})
 b.write(R/'RUN_FREEZE.json',{'time':time.time(),'code_hashes':{p.name:b.sha(p) for p in R.glob('*.py')},'protocol_sha256':b.sha(R/'PROTOCOL.md'),'original_configuration_sha256':b.sha(R/'ORIGINAL_CONFIGURATION.json'),'prior_test_results_known':True,'new_selection_uses_test':False})
 task={'task':'hia_hou','metric':'AUROC'};cfg=json.loads((R/'ORIGINAL_CONFIGURATION.json').read_text())['winner']['configuration'];d=R/'chemprop/hia_hou';d.mkdir(parents=True)
 b.write(d/'CONFIGURATION_FROZEN.json',{'configuration':cfg,'selection':'original configuration unchanged; lexicographic validation checkpoint correction','seeds':[101,202,303,404,505]})
 prep=R/'prepared/hia_hou';rr=json.loads((prep/'ROWS.json').read_text());b.write(d/'ROWS.json',rr);fits=[]
 for seed in [101,202,303,404,505]:
  status('TRAINING',seed=seed,completed=len(fits));o=d/f'seed{seed}';rec=b.fit(task,cfg,seed,o)
  logs=list((o/'model').rglob('metrics.csv'));rows=list(csv.DictReader(logs[0].open()));v=[z for z in rows if z.get('val/roc')]
  assert len(v)==50 and {int(z['epoch']) for z in v}==set(range(50))
  best=max(v,key=lambda z:(float(z['val/roc']),-float(z['val_loss']),-int(z['epoch'])))
  ckpts=list((o/'model/model_0/checkpoints').glob('best-*.ckpt'));assert len(ckpts)==1
  checkpoint=torch.load(ckpts[0],map_location='cpu',weights_only=False)
  assert checkpoint['epoch']==int(best['epoch']),(seed,checkpoint['epoch'],best)
  b.write(o/'SELECTION_CHECK.json',{'selected_epoch_zero_based':int(best['epoch']),'validation_auroc':float(best['val/roc']),'validation_loss':float(best['val_loss']),'epochs':50,'checkpoint_sha256':b.sha(ckpts[0]),'model_sha256':rec['model_sha256'],'all_epoch_selection_verified':True})
  fits.append(rec);print('SEALED',seed,best,flush=True)
 b.write(d/'ALL_MODELS_FROZEN.json',{'fits':fits,'configuration_sha256':b.sha(d/'CONFIGURATION_FROZEN.json')});status('PREDICTING')
 runs=[]
 for rec in fits:
  seed=rec['seed'];o=d/f'seed{seed}';assert b.sha(rec['model'])==rec['model_sha256']
  b.command(['predict','--test-path',str(prep/'inference.csv'),'--smiles-columns','Drug','--model-paths',rec['model'],'--preds-path',str(o/'raw_predictions.csv'),'--accelerator','cpu','--devices','1'],o/'predict.log')
  pred=b.pd.read_csv(o/'raw_predictions.csv');inp=b.pd.read_csv(prep/'inference.csv');assert pred.Drug.tolist()==inp.Drug.tolist();y=pred.Y.to_numpy(float);assert len(y)==len(rr) and b.np.isfinite(y).all()
  b.np.savez_compressed(o/'predictions.npz',row_ids=b.np.array([r['row_id'] for r in rr]),prediction=y)
  runs.append({'seed':seed,'prediction_sha256':b.sha(o/'predictions.npz'),'model_sha256':rec['model_sha256'],'fit_sha256':b.sha(o/'FIT.json')})
 b.write(d/'PREDICTIONS_FROZEN.json',{'runs':runs,'rows_sha256':b.sha(d/'ROWS.json'),'config_sha256':b.sha(d/'CONFIGURATION_FROZEN.json'),'test_labels_used_for_selection':False})
 status('SCORING');subprocess.run([str(b.PY),str(R/'evaluate_task.py'),'hia_hou'],env=b.ENV,check=True);status('COMPLETE')
except Exception as ex:status('FAILED',error=repr(ex));traceback.print_exc();raise
