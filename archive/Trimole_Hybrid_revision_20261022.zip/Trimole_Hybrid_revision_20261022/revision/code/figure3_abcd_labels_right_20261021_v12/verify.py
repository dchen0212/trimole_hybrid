from pathlib import Path
import ast
import hashlib
import json
import numpy as np
from PIL import Image
from pypdf import PdfReader

OUT = Path(__file__).resolve().parent
BASE = OUT.parent / "figure3_e_paired_bars_20261021_v11"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
before = json.loads((OUT / "SOURCE_HASHES_BEFORE.json").read_text())
assert all(sha(Path(p)) == digest for p, digest in before.items())
for path in BASE.glob("*.csv"):
    assert path.read_bytes() == (OUT / path.name).read_bytes(), path.name
assert (BASE / "CAPTION_EN.md").read_bytes() == (OUT / "CAPTION_EN.md").read_bytes()
def functions(text):
    return {n.name: ast.get_source_segment(text, n)
            for n in ast.parse(text).body if isinstance(n, ast.FunctionDef)}
old = functions((BASE / "make_figure3_v11.py").read_text())
new = functions((OUT / "make_figure3_v12.py").read_text())
assert [k for k in old if old[k] != new[k]] == ["main"]
old_checks = json.loads((BASE / "AXIS_CHECKS.json").read_text())
checks = json.loads((OUT / "AXIS_CHECKS.json").read_text())
assert all(checks[k] == v for k, v in old_checks.items())
assert checks["label_layout"]["horizontal_shift_points"] == 5
assert sum(checks["label_layout"]["label_counts"].values()) == 21
old_img = Image.open(BASE / "Figure3.png").convert("RGB")
new_img = Image.open(OUT / "Figure3.png").convert("RGB")
assert old_img.size == new_img.size == (7200, 5190)
differences = np.any(np.asarray(old_img) != np.asarray(new_img), axis=2)
changed_rows = np.where(differences.any(axis=1))[0]
allowed = np.zeros_like(differences, dtype=bool)
allowed[1200:1600, :] = True
allowed[2780:3220, :] = True
assert not np.any(differences & ~allowed)
assert not differences[3240:, :].any()
pdf_old, pdf_new = PdfReader(BASE / "Figure3.pdf"), PdfReader(OUT / "Figure3.pdf")
assert len(pdf_new.pages) == 1 and not pdf_new.pages[0].images
assert pdf_old.pages[0].extract_text() == pdf_new.pages[0].extract_text()
assert pdf_old.pages[0].mediabox == pdf_new.pages[0].mediabox
preview = new_img.copy()
preview.thumbnail((1800, 1800))
preview.save(OUT / "preview.png")
receipt = {
    "status": "PASS",
    "change": "21 x-axis category labels in a-d shifted 5 pt right",
    "no_changes_outside_x_tick_label_bands": True,
    "panel_e_pixel_identical": True,
    "all_data_csvs_and_caption_byte_identical": True,
    "source_files_unchanged": True,
    "pdf_text_and_page_dimensions_unchanged": True,
    "pdf_vector_only": True,
    "png_dimensions": new_img.size, "png_dpi": 600,
    "changed_pixel_row_range": [int(changed_rows.min()), int(changed_rows.max())],
    "visual_review": "PASS: rendered PDF inspected; no label overlap or clipping.",
    "output_sha256": {n: sha(OUT / n) for n in ["Figure3.pdf", "Figure3.png", "Figure3.svg"]},
}
(OUT / "QA_RECEIPT.json").write_text(json.dumps(receipt, indent=2))
print(json.dumps({"status": "PASS", "label_shift_points": 5,
                  "labels": 21, "changes_only_in_label_bands": True}, indent=2))
