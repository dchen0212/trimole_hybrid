#!/usr/bin/env python3
"""Figure 3: separate metrics in a-d; preserve the original layout and panel e."""

from __future__ import annotations

from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from matplotlib.colors import LinearSegmentedColormap, TwoSlopeNorm
from matplotlib.patches import Patch


BUILD = Path('/Users/huangdachen/Desktop/ADMET_Project_Final/Task_adaptive_multimodal_ADMET_prediction_build')
TABLES = Path(__file__).resolve().parent / "source_data"
FIGURES = Path(__file__).resolve().parent
MLP_DIR = TABLES

VARIANT_ORDER = [
    "no_chemistry_sidecar",
    "no_ept_or_no_3d",
    "no_prediction_level_ensemble",
    "no_seedbag_single_seed",
    "no_task_adaptive_selection",
]

VARIANT_LABELS = {
    "no_chemistry_sidecar": "w/o Chemistry\nSidecar",
    "no_ept_or_no_3d": "w/o EPT /\n3D",
    "no_prediction_level_ensemble": "w/o\nEnsemble",
    "no_seedbag_single_seed": "Single\nSeed",
    "no_task_adaptive_selection": "w/o Task-\nAdaptive",
}

TASK_NAMES = {
    "solubility_aqsoldb": "Aqueous solubility",
    "bioavailability_ma": "Bioavailability",
    "caco2_wang": "Caco-2 permeability",
    "hia_hou": "Human intestinal absorption",
    "lipophilicity_astrazeneca": "Lipophilicity",
    "pgp_broccatelli": "P-glycoprotein substrate",
    "bbb_martins": "Blood-brain barrier penetration",
    "ppbr_az": "Plasma protein binding",
    "vdss_lombardo": "Volume of distribution",
    "clearance_hepatocyte_az": "Hepatocyte clearance",
    "clearance_microsome_az": "Microsome clearance",
    "half_life_obach": "Half-life",
    "cyp2c9_veith": "Cytochrome P450 2C9 inhibition",
    "cyp2c9_substrate_carbonmangels": "Cytochrome P450 2C9 substrate",
    "cyp2d6_veith": "Cytochrome P450 2D6 inhibition",
    "cyp2d6_substrate_carbonmangels": "Cytochrome P450 2D6 substrate",
    "cyp3a4_veith": "Cytochrome P450 3A4 inhibition",
    "cyp3a4_substrate_carbonmangels": "Cytochrome P450 3A4 substrate",
    "ames": "Bacterial mutagenicity",
    "dili": "Drug-induced liver injury",
    "ld50_zhu": "Median lethal dose",
    "herg": "hERG liability",
}

METRIC_COLORS = {
    "AUROC": "#9cc8e2",
    "AUPRC": "#f3c983",
    "Spearman": "#9bcaa6",
    "MAE": "#c9b7e8",
}

METRIC_ORDER = {"AUROC": 0, "AUPRC": 1, "Spearman": 2, "MAE": 3}


def setup_style() -> None:
    plt.rcParams.update(
        {
            "font.family": "sans-serif",
            "font.sans-serif": ["Arial", "Helvetica", "DejaVu Sans"],
            "svg.fonttype": "none",
            "pdf.fonttype": 42,
            "ps.fonttype": 42,
            "font.size": 8,
            "axes.spines.right": False,
            "axes.spines.top": False,
            "axes.linewidth": 0.9,
            "legend.frameon": False,
        }
    )


def load_ablation() -> tuple[pd.DataFrame, pd.DataFrame]:
    source = pd.read_csv(TABLES / "Table_S4c_formal_ablation_delta_vs_full.csv")
    assert len(source) == 132 and not source.duplicated(["task", "variant"]).any()
    full = source[source.variant == "full_v36_final"].set_index("task")
    assert full.groupby("metric").size().to_dict() == {
        "AUROC": 8, "AUPRC": 5, "Spearman": 4, "MAE": 5}
    long = source[source.variant.isin(VARIANT_ORDER)].copy()
    long["full_score"] = long.task.map(full.score_mean)
    long["delta_score"] = long.score_mean - long.full_score
    expected = np.where(long.metric == "MAE", -long.delta_score, long.delta_score)
    assert np.allclose(expected, long.delta_margin_vs_full, rtol=0, atol=1e-12)
    long.to_csv(FIGURES / "ABLATION_VALUES_ALL110.csv", index=False)
    long[long.metric != "MAE"].to_csv(FIGURES / "PANELS_ABC_VALUES85.csv", index=False)
    wide = source.pivot(index="task", columns="variant", values="score_mean")
    wide = wide.reindex(columns=["full_v36_final"] + VARIANT_ORDER)
    wide.insert(0, "metric", full.metric)
    wide["metric_order"] = wide.metric.map(METRIC_ORDER)
    wide = wide.reset_index().sort_values(["metric_order", "task"]).drop(columns="metric_order")
    wide.to_csv(FIGURES / "SUPPLEMENTARY_SCORES_ALL22.csv", index=False)
    full[["metric", "score_mean", "score_std"]].to_csv(FIGURES / "FULL_VALUES_ALL22.csv")
    return long, wide


def load_mlp() -> pd.DataFrame:
    df = pd.read_csv(MLP_DIR / "mlp_late_fusion_all22_summary.csv")
    df = df[df["status"] == "run"].copy()
    df["task_name"] = df["task"].map(TASK_NAMES).fillna(df["task"])
    df["metric_order"] = df["metric"].map(METRIC_ORDER)
    df = df.sort_values(
        ["metric_order", "direction_normalized_delta_mlp_vs_v36"],
        ascending=[True, False],
    ).reset_index(drop=True)
    return df


VARIANT_COLORS = ["#c9b7e8", "#f3c983", "#9bcaa6", "#c8b8a3", "#9cc8e2"]


def plot_metric_box(ax, long, metric, letter, show_all_points=False):
    part = long[long.metric == metric]
    tasks = sorted(part.task.unique())
    values = [part[part.variant == v].set_index("task").loc[tasks, "delta_score"].to_numpy()
              for v in VARIANT_ORDER]
    assert all(len(a) == len(tasks) for a in values)
    bp = ax.boxplot(
        values, patch_artist=True, widths=.55, showfliers=not show_all_points,
        medianprops={"color": "#666666", "lw": 1.1},
        boxprops={"lw": .9, "color": "#777777"},
        whiskerprops={"lw": .9, "color": "#777777"},
        capprops={"lw": .9, "color": "#777777"},
        flierprops={"marker": "o", "markersize": 2.1,
                    "markerfacecolor": "#666666", "markeredgecolor": "none"},
    )
    for patch, color in zip(bp["boxes"], VARIANT_COLORS):
        patch.set_facecolor(color)
        patch.set_alpha(.45)
    if show_all_points:
        offsets = np.linspace(-.12, .12, len(tasks))
        for i, vals in enumerate(values, 1):
            ax.scatter(i + offsets, vals, s=11, color="#555555",
                       linewidths=.3, edgecolors="white", zorder=4)
    ax.axhline(0, color="#777777", lw=.8, ls="--")
    all_values = np.concatenate(values)
    pad = max(np.ptp(all_values) * .10, .015)
    ax.set_ylim(min(0, all_values.min()) - pad, max(0, all_values.max()) + pad)
    assert all_values.min() > ax.get_ylim()[0] and all_values.max() < ax.get_ylim()[1]
    ax.set_xticks(np.arange(1, len(VARIANT_ORDER)+1))
    ax.set_xticklabels([VARIANT_LABELS[v] for v in VARIANT_ORDER], rotation=35, ha="right")
    ax.set_ylabel(f"Δ{metric} (ablation − Full)")
    ax.set_title(f"{letter}  {metric}", loc="left", fontweight="bold", fontsize=10)
    ax.text(1, 1.035, f"{len(tasks)} tasks", transform=ax.transAxes,
            ha="right", fontsize=7.4, color="#555555")
    ax.grid(False, which="both")
    AXIS_CHECKS[metric] = {"tasks": tasks, "n_values": len(all_values),
                           "min": float(all_values.min()), "max": float(all_values.max()),
                           "ylim": list(ax.get_ylim()), "all_task_points_visible": show_all_points}


AXIS_CHECKS = {}


def panel_a(ax: plt.Axes, long: pd.DataFrame) -> None:
    plot_metric_box(ax, long, "AUROC", "a", show_all_points=True)


def panel_b(ax: plt.Axes, long: pd.DataFrame) -> None:
    from matplotlib.colors import Normalize
    from matplotlib.ticker import FormatStrFormatter

    part = long[long.metric == "AUPRC"]
    tasks = [
        "cyp2c9_substrate_carbonmangels", "cyp2c9_veith",
        "cyp2d6_substrate_carbonmangels", "cyp2d6_veith", "cyp3a4_veith",
    ]
    names = ["CYP2C9-S", "CYP2C9-I", "CYP2D6-S", "CYP2D6-I", "CYP3A4-I"]
    assert set(part.task) == set(tasks) and len(part) == 25
    matrix = part.pivot(index="task", columns="variant", values="delta_score").loc[
        tasks, VARIANT_ORDER]
    values = matrix.to_numpy(dtype=float)
    assert np.isfinite(values).all()
    matrix.to_csv(FIGURES / "PANEL_B_AUPRC_DIFFERENCES.csv")
    # One linear numerical scale; the neutral cream anchor is exactly at zero.
    vmin, vmax = -.40, .04
    zero_position = (0-vmin)/(vmax-vmin)
    cmap = LinearSegmentedColormap.from_list(
        "original_purple_cream_orange",
        [(0, "#4b006e"), (.50, "#b8a6d9"),
         (zero_position, "#f7efe5"), (1, "#f0a63d")])
    norm = Normalize(vmin=vmin, vmax=vmax)
    assert values.min() > vmin and values.max() < vmax
    mesh = ax.pcolormesh(
        np.arange(6), np.arange(6), values, cmap=cmap, norm=norm,
        shading="flat", edgecolors="white", linewidth=.9, rasterized=False)
    displayed = []
    for row in range(5):
        for col in range(5):
            value = values[row, col]
            rgb = np.asarray(cmap(norm(value))[:3])
            linear_rgb = np.where(rgb <= .04045, rgb/12.92, ((rgb+.055)/1.055)**2.4)
            luminance = float(linear_rgb @ np.array([.2126, .7152, .0722]))
            text_color = "white" if luminance < .179 else "#222222"
            label = f"{value:+.3f}"
            ax.text(col+.5, row+.5, label, ha="center", va="center",
                    fontsize=7.3, color=text_color)
            displayed.append({"task": tasks[row], "variant": VARIANT_ORDER[col],
                              "delta_AUPRC": float(value), "display_text": label})
    ax.set_xlim(0, 5)
    ax.set_ylim(5, 0)
    ax.set_yticks(np.arange(5)+.5, names, fontsize=7.2)
    ax.set_xticks(np.arange(5)+.5,
                  [VARIANT_LABELS[v] for v in VARIANT_ORDER],
                  rotation=35, ha="right", fontsize=8)
    ax.tick_params(axis="both", length=0, pad=5)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.grid(False, which="both")
    ax.set_title("b  AUPRC", loc="left", fontweight="bold", fontsize=10)
    ax.text(1, 1.035, "5 tasks", transform=ax.transAxes,
            ha="right", fontsize=7.4, color="#555555")
    cbar = ax.figure.colorbar(mesh, ax=ax, fraction=.034, pad=.035,
                             ticks=[-.40, -.20, 0, .04])
    cbar.ax.yaxis.set_major_formatter(FormatStrFormatter("%.2f"))
    cbar.ax.tick_params(labelsize=6.6, length=2)
    cbar.set_label("ΔAUPRC (ablation − Full)", fontsize=6.8, labelpad=5)
    cbar.outline.set_linewidth(.5)
    cbar.solids.set_rasterized(False)
    cbar.solids.set_edgecolor("face")
    pd.DataFrame(displayed).to_csv(FIGURES / "PANEL_B_DISPLAY_VALUES.csv", index=False)
    AXIS_CHECKS["AUPRC"] = {
        "tasks": tasks, "n_values": int(values.size),
        "plot": "task-by-ablation heatmap",
        "color_scale": "linear", "color_range": [vmin, vmax],
        "min": float(values.min()), "max": float(values.max()),
        "color_zero_anchor": zero_position,
        "cell_labels": "native delta AUPRC rounded to 3 decimals, explicit signs",
        "all_task_values_visible": True, "inset_zoom": False, "broken_axis": False,
    }


def panel_c(ax: plt.Axes, long: pd.DataFrame) -> None:
    plot_metric_box(ax, long, "Spearman", "c", show_all_points=True)


def panel_d(ax: plt.Axes, wide: pd.DataFrame) -> None:
    from matplotlib.colors import Normalize
    from matplotlib.ticker import PercentFormatter

    tasks = ["caco2_wang", "ld50_zhu", "lipophilicity_astrazeneca",
             "ppbr_az", "solubility_aqsoldb"]
    names = ["Caco-2", "LD50", "Lipophilicity", "PPBR", "Solubility"]
    variants = ["full_v36_final"] + VARIANT_ORDER
    values = wide.set_index("task").loc[tasks, variants]
    native = values.to_numpy(dtype=float)
    assert np.isfinite(native).all() and (native[:, 0] > 0).all()
    # Only MAE is converted to a within-task relative error increase for color.
    relative = (native - native[:, [0]]) / native[:, [0]]
    assert relative.min() >= 0 and relative.max() < .40
    values.to_csv(FIGURES / "PANEL_D_MAE_VALUES.csv")
    pd.DataFrame(relative, index=tasks, columns=variants).to_csv(
        FIGURES / "PANEL_D_MAE_RELATIVE_INCREASE.csv", index_label="task")
    cmap = LinearSegmentedColormap.from_list(
        "original_cream_purple", ["#f7efe5", "#b8a6d9", "#4b006e"])
    mesh = ax.pcolormesh(
        np.arange(7), np.arange(6), relative,
        cmap=cmap, norm=Normalize(vmin=0, vmax=.40),
        shading="flat", edgecolors="white", linewidth=.9, rasterized=False)
    for row in range(5):
        for col in range(6):
            ax.text(col + .5, row + .5, f"{native[row, col]:.3f}",
                    ha="center", va="center", fontsize=7.1,
                    color="white" if relative[row, col] > .26 else "#333333")
    ax.set_xlim(0, 6)
    ax.set_ylim(5, 0)
    ax.set_yticks(np.arange(5) + .5, names, fontsize=7.2)
    ax.set_xticks(np.arange(6) + .5,
                  ["Full"] + [VARIANT_LABELS[v] for v in VARIANT_ORDER],
                  rotation=35, ha="right", fontsize=7.2)
    ax.tick_params(axis="both", length=0, pad=5)
    for spine in ax.spines.values():
        spine.set_visible(False)
    ax.grid(False, which="both")
    ax.set_title("d  MAE (lower is better)", loc="left", fontweight="bold", fontsize=10)
    cbar = ax.figure.colorbar(mesh, ax=ax, fraction=.034, pad=.035,
                             ticks=[0, .20, .40])
    cbar.ax.yaxis.set_major_formatter(PercentFormatter(xmax=1, decimals=0))
    cbar.ax.tick_params(labelsize=6.6, length=2)
    cbar.set_label("MAE increase vs Full", fontsize=6.8, labelpad=5)
    cbar.outline.set_linewidth(.5)
    cbar.solids.set_rasterized(False)
    cbar.solids.set_edgecolor("face")
    AXIS_CHECKS["MAE_heatmap"] = {
        "tasks": tasks, "n_native_values": int(native.size),
        "cell_labels": "native MAE rounded to 3 decimals",
        "color_formula": "(ablation_MAE - Full_MAE) / Full_MAE",
        "color_range": [0, .40], "min": float(relative.min()),
        "max": float(relative.max()), "full_column": relative[:, 0].tolist(),
    }


def panel_e(ax: plt.Axes, mlp: pd.DataFrame) -> None:
    from matplotlib.ticker import MaxNLocator

    full = pd.read_csv(TABLES / "Table_S4c_formal_ablation_delta_vs_full.csv")
    full = full[full["variant"] == "full_v36_final"].set_index("task")
    assert len(mlp) == 22 and set(mlp["task"]) == set(full.index)
    for row in mlp.itertuples():
        assert np.isclose(row.v36_final_test_score, full.loc[row.task, "score_mean"],
                          rtol=0, atol=1e-10)
    names = {
        "ames": "AMES", "bbb_martins": "BBB", "bioavailability_ma": "Bioavailability",
        "caco2_wang": "Caco-2", "clearance_hepatocyte_az": "Hepatocyte†",
        "clearance_microsome_az": "Microsome", "cyp2c9_substrate_carbonmangels": "CYP2C9-S",
        "cyp2c9_veith": "CYP2C9-I", "cyp2d6_substrate_carbonmangels": "CYP2D6-S",
        "cyp2d6_veith": "CYP2D6-I", "cyp3a4_substrate_carbonmangels": "CYP3A4-S†",
        "cyp3a4_veith": "CYP3A4-I", "dili": "DILI", "half_life_obach": "Half-life",
        "herg": "hERG", "hia_hou": "HIA", "ld50_zhu": "LD50",
        "lipophilicity_astrazeneca": "Lipophilicity", "pgp_broccatelli": "P-gp",
        "ppbr_az": "PPBR", "solubility_aqsoldb": "Solubility", "vdss_lombardo": "VDss",
    }
    model_colors = ["#9cc8e2", "#c9b7e8"]
    ax.set_axis_off()
    ax.set_title("e  MLP late-fusion control", loc="left", fontweight="bold", fontsize=10)
    ax.legend(handles=[
        Patch(facecolor=model_colors[0], edgecolor="#777777", linewidth=.4,
              label="Full (original)"),
        Patch(facecolor=model_colors[1], edgecolor="#777777", linewidth=.4,
              label="MLP late fusion"),
    ], loc="upper right", bbox_to_anchor=(1.0, 1.22), ncol=2,
       fontsize=7, handlelength=1.3, handleheight=.7)
    export_rows, geometry = [], []
    metric_positions = {"AUROC": (0.015, .18), "AUPRC": (.31, .17), "Spearman": (.615, .16)}
    for metric, (left, width) in metric_positions.items():
        part = mlp[mlp["metric"] == metric].copy()
        child = ax.inset_axes([left, -.48, width, 1.31])
        means, errors = [], []
        for i, row in enumerate(part.itertuples()):
            vals = [full.loc[row.task, "score_mean"], row.mlp_test_mean]
            sds = [full.loc[row.task, "score_std"], row.mlp_test_std]
            for j, (value, sd) in enumerate(zip(vals, sds)):
                child.barh(
                    i+(-.18 if j == 0 else .18), value, height=.28, left=0,
                    color=model_colors[j], edgecolor="#777777", linewidth=.35,
                    xerr=sd, error_kw={"ecolor": "#555555", "elinewidth": .65,
                                     "capsize": 1.3, "capthick": .65}, zorder=3)
                export_rows.append({"task": row.task, "metric": metric,
                                    "method": "Full" if j == 0 else "MLP",
                                    "mean": value, "sd": sd})
            means.extend(vals)
            errors.extend(sds)
        low = float(np.min(np.asarray(means)-np.asarray(errors)))
        high = float(np.max(np.asarray(means)+np.asarray(errors)))
        if metric in ["AUROC", "AUPRC"]:
            limits = [min(0, low-.02), max(1.02, high+.02)]
            child.set_xticks([0, .5, 1.0])
        else:
            limits = [min(0, low-.04), max(.75, high+.04)]
            child.set_xticks([-.25, 0, .25, .50, .75])
        child.set_xlim(*limits)
        child.set_ylim(len(part)-.55, -.55)
        child.set_yticks(range(len(part)), [names[t] for t in part["task"]], fontsize=6)
        child.set_title(metric+" ↑", fontsize=8.3, fontweight="bold", pad=5)
        child.set_xlabel("Score", fontsize=6.2, labelpad=2)
        child.tick_params(axis="both", length=2, labelsize=6)
        child.spines["left"].set_visible(False)
        child.spines["right"].set_visible(False)
        child.spines["top"].set_visible(False)
        child.axvline(0, color="#999999", linewidth=.55, zorder=1)
        child.grid(False, which="both")
        for row in export_rows:
            if row["metric"] == metric:
                assert limits[0] <= min(0, row["mean"]-row["sd"])
                assert max(0, row["mean"]+row["sd"]) <= limits[1]
                geometry.append({**row, "bar_origin": 0,
                                 "axis_min": limits[0], "axis_max": limits[1]})

    # Different MAE endpoints retain independent native-scale axes, all starting at zero.
    part = mlp[mlp["metric"] == "MAE"].copy()
    ax.text(.94, .93, "MAE ↓", transform=ax.transAxes, ha="center",
            fontsize=8.3, fontweight="bold")
    ax.text(.94, .83, "Task-specific scales", transform=ax.transAxes,
            ha="center", fontsize=5.6)
    for i, row in enumerate(part.itertuples()):
        child = ax.inset_axes([.89, .60-i*.267, .11, .18])
        vals = [full.loc[row.task, "score_mean"], row.mlp_test_mean]
        sds = [full.loc[row.task, "score_std"], row.mlp_test_std]
        upper = float(np.max(np.asarray(vals)+np.asarray(sds)))
        limits = [0, upper*1.12]
        for j, (value, sd) in enumerate(zip(vals, sds)):
            assert value-sd >= 0 and value+sd < limits[1]
            child.barh(
                .72 if j == 0 else .28, value, height=.28, left=0,
                color=model_colors[j], edgecolor="#777777", linewidth=.35,
                xerr=sd, error_kw={"ecolor": "#555555", "elinewidth": .65,
                                 "capsize": 1.1, "capthick": .65}, zorder=3)
            entry = {"task": row.task, "metric": "MAE",
                     "method": "Full" if j == 0 else "MLP", "mean": value, "sd": sd}
            export_rows.append(entry)
            geometry.append({**entry, "bar_origin": 0,
                             "axis_min": limits[0], "axis_max": limits[1]})
        child.set_xlim(*limits)
        child.set_ylim(0, 1)
        child.set_yticks([])
        child.spines["left"].set_visible(False)
        child.spines["right"].set_visible(False)
        child.spines["top"].set_visible(False)
        child.xaxis.set_major_locator(MaxNLocator(nbins=2, steps=[1, 2, 2.5, 5, 10]))
        child.tick_params(axis="x", length=2, labelsize=5.5, pad=1)
        child.text(-.10, .5, names[row.task], transform=child.transAxes,
                   ha="right", va="center", fontsize=5.9)
        child.grid(False, which="both")
    ax.text(.015, -.82,
            "Original means ± SD. † Historical family-transfer endpoint. S: substrate; I: inhibition.",
            transform=ax.transAxes, fontsize=6.1, color="#444444")
    pd.DataFrame(export_rows).to_csv(FIGURES / "Figure3e_plot_data.csv", index=False)
    pd.DataFrame(geometry).to_csv(FIGURES / "PANEL_E_BAR_GEOMETRY.csv", index=False)
    AXIS_CHECKS["MLP_control"] = {
        "tasks": 22, "means": 44, "standard_deviations": 44,
        "plot": "paired horizontal bars with SD",
        "all_bars_start_at_zero": True, "all_error_bars_within_axes": True,
        "independent_MAE_axes": 5, "cross_metric_aggregation": False,
        "method_colors": {"Full": model_colors[0], "MLP": model_colors[1]},
    }


def main() -> None:
    setup_style()
    long, summary = load_ablation()
    mlp = load_mlp()

    fig = plt.figure(figsize=(12.0, 8.65), dpi=300)
    gs = fig.add_gridspec(3, 2, height_ratios=[1.0, 1.0, 0.96], hspace=0.78, wspace=0.30)

    ax_a = fig.add_subplot(gs[0, 0])
    ax_b = fig.add_subplot(gs[0, 1])
    ax_c = fig.add_subplot(gs[1, 0])
    ax_d = fig.add_subplot(gs[1, 1])
    ax_e = fig.add_subplot(gs[2, :])

    panel_a(ax_a, long)
    panel_b(ax_b, long)
    panel_c(ax_c, long)
    panel_d(ax_d, summary)
    panel_e(ax_e, mlp)

    fig.subplots_adjust(left=0.12, right=0.95, top=0.94, bottom=0.16)

    for ext in ["pdf", "svg", "png"]:
        fig.savefig(FIGURES / f"Figure3.{ext}", dpi=600 if ext == "png" else None)
    plt.close(fig)
    import json
    (FIGURES / "AXIS_CHECKS.json").write_text(json.dumps(AXIS_CHECKS, indent=2))
    print(FIGURES / "Figure3.pdf")


if __name__ == "__main__":
    main()
