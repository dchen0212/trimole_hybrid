"""Make the requested label-position adjustment without altering the panels."""
from pathlib import Path
import hashlib
import json
import shutil

OUT = Path(__file__).resolve().parent
BASE = OUT.parent / "figure3_e_paired_bars_20261021_v11"
source = (BASE / "make_figure3_v11.py").read_text()
anchor = "    fig.subplots_adjust(left=0.12, right=0.95, top=0.94, bottom=0.16)\n"
addition = '''
    # Shift only the category labels in a-d by five points to the right.
    from matplotlib.transforms import ScaledTranslation
    horizontal_shift = ScaledTranslation(5/72, 0, fig.dpi_scale_trans)
    label_counts = {}
    for name, axis in [("a", ax_a), ("b", ax_b), ("c", ax_c), ("d", ax_d)]:
        labels = axis.get_xticklabels()
        label_counts[name] = len(labels)
        for label in labels:
            label.set_transform(label.get_transform() + horizontal_shift)
    assert label_counts == {"a": 5, "b": 5, "c": 5, "d": 6}
    AXIS_CHECKS["label_layout"] = {
        "changed": "x tick label positions only",
        "horizontal_shift_points": 5, "vertical_shift_points": 0,
        "label_counts": label_counts, "panel_e_unchanged": True,
    }
'''
assert source.count(anchor) == 1
updated = source.replace(anchor, anchor + addition, 1)
assert updated.replace(addition, "", 1) == source
shutil.copytree(BASE / "source_data", OUT / "source_data")
shutil.copy2(BASE / "make_figure3_v11.py", OUT / "base_script_v11.py")
shutil.copy2(BASE / "CAPTION_EN.md", OUT / "CAPTION_EN.md")
(OUT / "make_figure3_v12.py").write_text(updated)
(OUT / "CHANGELOG_CN.md").write_text("""# Figure 3 v12

- a、b、c、d 的 21 个横轴分类标签统一向右移动 5 pt（约 1.8 mm）。
- 标签旋转角度、字号、纵向位置、刻度线、坐标轴和图形均不变。
- e 不变；所有数据、误差线和图注不变。
- 旧版本不覆盖，另存 PDF、SVG 和 600 dpi PNG。
""")
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
(OUT / "SOURCE_HASHES_BEFORE.json").write_text(json.dumps({
    str(p): sha(p) for p in BASE.rglob("*") if p.is_file()
}, indent=2))
print(OUT)
