"""Read-only replay of completed searches. No training or prediction calls."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,json,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr,rankdata
from sklearn.metrics import roc_auc_score

R=Path(sys.argv[1]).resolve()
def read(p): return json.loads(Path(p).read_text())
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def score(t,y,p): return float(spearmanr(y,p).statistic if 'hepatocyte' in t else roc_auc_score(y,p))
def same(a,b): assert np.allclose(a,b,rtol=0,atol=1e-12),(a,b)
assert (R/'RESULTS.json').exists(),'Search has not finished: do not read test labels.'
state=read(R/'SEARCH_STATUS.json')
assert state['status']=='FINISHED_REQUIRES_REVIEW',state['status']
for p,h in read(R/'SEARCH_CODE_FREEZE.json')['code'].items(): assert sha(R/p)==h
selection=read(R/'SELECTION_FREEZE.json')
sealed=read(R/'ALL_PREDICTIONS_FROZEN.json')
assert len(sealed)==5*len(selection)
for p,h in sealed.items(): assert sha(R/p)==h
summary={'status':'PASS','root':str(R),'tasks':{},'nonzero_jobs':[j for j in state['completed'] if j['returncode']],
         'limits':['Development CV was used for model selection, not an independent assessment.',
                   'Official test has historical exposure; benchmark reuse.',
                   'Public pretrained representations do not exclude pretraining structure overlap.']}
reported=read(R/'RESULTS.json')['rows']
for task,s in selection.items():
 d=R/task; f=read(d/'FOLDS.json'); binding=read(R/'INPUT_BINDING.json')[task]
 assert sha(d/'ROWS.json')==f['row_binding_sha256']
 for name in ['development','evaluation']: assert sha(d/(name+'_features.npz'))==f[name+'_features_sha256']
 assert sha(d/'development_labels.npz')==binding['development_labels_sha256']
 assert sha(binding['development_path'])==binding['development_sha256']
 with np.load(d/'development_labels.npz') as z:y=z['y']
 coverage=np.zeros(len(y),int)
 for fold in f['folds']:
  a,b=fold['fit'],fold['validation'];assert not set(a)&set(b)
  assert set(a)|set(b)==set(range(len(y)));coverage[b]+=1
 assert (coverage==1).all()
 records=[read(p) for p in (d/'candidates').glob('*/RESULT.json')]
 good=sorted([x for x in records if x['status']=='SUCCESS'],key=lambda x:(-x['cv_score'],x['candidate']['id']))
 oofs={}
 for rec in good:
  cid=rec['candidate']['id'];p=d/'candidates'/cid/'OOF.npz';assert sha(p)==rec['oof_sha256']
  with np.load(p) as z:pred=z['prediction']
  scores=[score(task,y[fold['validation']],pred[fold['validation']]) for fold in f['folds']]
  same(scores,rec['fold_scores']);same(np.mean(scores),rec['cv_score']);oofs[cid]=pred
 assert len(good)==s['successful']
 diverse=[];seen=set()
 transformed=any('target_transform' in r['candidate'] for r in good)
 for rec in good:
  c=rec['candidate'];key=(c['kind'],c['feature'])+((c['target_transform'],) if transformed else ())
  if key not in seen:diverse.append(c['id']);seen.add(key)
 expected=[('single',[good[0]['candidate']['id']])]
 for n in [3,5]:
  if len(good)>=n:expected.append((f'rank_top{n}',[x['candidate']['id'] for x in good[:n]]))
  if len(diverse)>=n:expected.append((f'rank_diverse{n}',diverse[:n]))
 assert [(x['name'],x['members']) for x in s['options']]==expected
 for option in s['options']:
  scores=[]
  for fold in f['folds']:
   ix=np.array(fold['validation']);ps=[oofs[c][ix] for c in option['members']]
   p=ps[0] if len(ps)==1 else np.mean([rankdata(x,method='average')/len(x) for x in ps],axis=0)
   scores.append(score(task,y[ix],p))
  same(scores,option['fold_scores']);same(np.mean(scores),option['cv_score'])
 assert max(enumerate(s['options']),key=lambda v:(v[1]['cv_score'],-v[0]))[1]==s['selected']
 rows=read(d/'ROWS.json');ev=[r for r in rows if r['region']=='evaluation']
 test_path=Path(binding['development_path']).with_name('test.csv');test=pd.read_csv(test_path)
 ix=[r['source_row'] for r in ev];assert sorted(ix)==list(range(len(test)))
 assert [r['raw_smiles'] for r in ev]==test.iloc[ix].Drug.astype(str).tolist()
 values=[]
 for seed in [101,202,303,404,505]:
  dest=d/f'final_seed{seed}';seal=read(dest/'SEAL.json')
  assert sha(dest/'models.pkl')==seal['models_sha256']
  assert sha(dest/'predictions.npz')==seal['prediction_sha256']
  assert sha(R/'SELECTION_FREEZE.json')==seal['selection_sha256']
  assert seal['fit_rows']==len(y) and seal['prediction_rows']==len(test)
  assert seal['cross_task_supervised_rows']==0 and seal['test_labels_used_in_fit'] is False
  with np.load(dest/'predictions.npz') as z:pred=z['prediction'];members=z['member_predictions']
  reconstructed=members[0] if len(members)==1 else np.mean([rankdata(x,method='average')/len(x) for x in members],axis=0)
  same(pred,reconstructed);value=score(task,test.iloc[ix].Y.to_numpy(float),pred)
  record=next(x for x in reported if x['task']==task and x['seed']==seed)
  same(value,record['score']);assert record['test_sha256']==sha(test_path);values.append(value)
 summary['tasks'][task]={'successful_candidates':len(good),'recorded_failures':[x for x in records if x['status']!='SUCCESS'],
  'selected':s['selected'],'seed_scores':values,'mean':float(np.mean(values)),'population_sd':float(np.std(values)),
  'distinct_prediction_hashes':len({read(p)['prediction_sha256'] for p in d.glob('final_seed*/SEAL.json')}),
  'source_test_rows':len(test),'fit_rows':len(y),'anchor_cv':next((x['cv_score'] for x in good if x['candidate']['kind']=='anchor'),None)}
print(json.dumps(summary,indent=2,allow_nan=False))
