import json,os,subprocess,time,hashlib,traceback
from pathlib import Path
R=Path(__file__).resolve().parent
e=json.loads((R/'ENVIRONMENT.json').read_text());env={**os.environ,**e['environment']}
def write(p,d):
    q=p.with_suffix('.pending');q.write_text(json.dumps(d,indent=2));os.replace(q,p)
state={'status':'RUNNING','started_unix':time.time(),'stages':[]}
assert not (R/'FEATURE_STATUS.json').exists()
write(R/'FEATURE_STATUS.json',state)
try:
    for mode,cap in [('prepare',600),('C',900),('K',1800)]:
        start=time.time()
        with (R/f'features_{mode}.log').open('x') as log:
            p=subprocess.run([e['python'],'-B',str(R/'features.py'),mode],env=env,stdout=log,stderr=subprocess.STDOUT,timeout=cap)
        state['stages'].append({'stage':mode,'returncode':p.returncode,'seconds':time.time()-start});write(R/'FEATURE_STATUS.json',state)
        if p.returncode:raise RuntimeError('feature stage failed: '+mode)
    state['status']='COMPLETE'
except Exception as err:state.update(status='FAILED',error=repr(err),traceback=traceback.format_exc())
state['ended_unix']=time.time();write(R/'FEATURE_STATUS.json',state)
