"""Fresh, keyed, label-free C/K and chemical features for two target tasks."""
import os
for n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[n]='1'
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import json,hashlib,sys,time
from pathlib import Path
import numpy as np
R=Path(__file__).resolve().parent
SOURCE=Path('/mnt/data/projects/trimole_hybrid_revision_20260915')
TASKS=['clearance_hepatocyte_az','cyp3a4_substrate_carbonmangels']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,x):
    with Path(p).open('x') as f:json.dump(x,f,indent=2,allow_nan=False)
def guard(event,args):
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)) and Path(os.fsdecode(args[0])).name=='test.csv':
        raise PermissionError('No target test CSV in feature extraction')
sys.addaudithook(guard)

def prepare():
    import pandas as pd
    from rdkit import Chem,RDLogger
    from rdkit.Chem import rdFingerprintGenerator,Descriptors
    RDLogger.DisableLog('rdApp.warning')
    allrows=[];bindings={}
    for task in TASKS:
        p=SOURCE/'data/admet_group'/task/'train_val.csv';f=pd.read_csv(p)
        s=Path('/mnt/data/projects/trimole_dual3090_transfer_20261011_v01/staging/structures')/(task+'.json');hold=read(s)
        assert hold['labels_present'] is False
        rows=[{'row_id':f'{task}:development:{i}','task':task,'region':'development','source_row':i,'raw_smiles':str(sm)} for i,sm in enumerate(f.Drug)]
        rows +=[{'row_id':f'{task}:evaluation:{x["source_row"]}','task':task,'region':'evaluation','source_row':x['source_row'],'raw_smiles':x['raw_smiles']} for x in hold['rows']]
        d=R/task;d.mkdir();write(d/'ROWS.json',rows)
        np.savez_compressed(d/'development_labels.npz',y=f.Y.to_numpy(float))
        generators={'fp2':rdFingerprintGenerator.GetMorganGenerator(radius=2,fpSize=2048),
                    'fp3':rdFingerprintGenerator.GetMorganGenerator(radius=3,fpSize=2048),
                    'rdk':rdFingerprintGenerator.GetRDKitFPGenerator(fpSize=2048),
                    'ap':rdFingerprintGenerator.GetAtomPairGenerator(fpSize=2048)}
        feats={n:[] for n in ['fp2','fp3','rdk','ap','cnt2','cnt3','desc']}
        for row in rows:
            m=Chem.MolFromSmiles(row['raw_smiles']);assert m is not None,'No invalid row deletion'
            for name,g in generators.items():feats[name].append(g.GetFingerprintAsNumPy(m).astype(np.float32))
            for name,g in [('cnt2',generators['fp2']),('cnt3',generators['fp3'])]:
                feats[name].append(g.GetCountFingerprintAsNumPy(m).astype(np.float32))
            desc=[]
            for n,fn in Descriptors._descList:
                try:v=float(fn(m))
                except Exception:v=float('nan')
                desc.append(v if np.isfinite(v) else np.nan)
            feats['desc'].append(desc)
        feats={k:np.asarray(v,dtype=np.float32) for k,v in feats.items()}
        np.savez_compressed(d/'chemical.npz',row_ids=np.asarray([x['row_id'] for x in rows]),**feats)
        bindings[task]={'development_path':str(p),'development_sha256':sha(p),'structure_export':str(s),'structure_export_sha256':sha(s),
                       'development_rows':len(f),'evaluation_rows':len(hold['rows']),'rows_sha256':sha(d/'ROWS.json'),
                       'chemical_sha256':sha(d/'chemical.npz'),'development_labels_sha256':sha(d/'development_labels.npz'),
                       'descriptor_names':[n for n,_ in Descriptors._descList],'endpoint_supervision':'target task only'}
        allrows+=rows
    write(R/'STRUCTURES.json',{'labels_present':False,'rows':allrows})
    write(R/'INPUT_BINDING.json',bindings)
    print('FEATURE_INPUTS_READY',len(allrows),flush=True)

def export(kind):
    import importlib
    import extract_chemberta as c
    pins={'extract_chemberta.py':'8b03de704bc6cc6f9a249755c85eae29c19ece44fdd9d8c7164614d3852d5e37',
          'extract_kpgt_v02.py':'9261fdbfbb4a25c3f89a62b29e8372f1fe2a39856ea4d51a7ee494ab1b9b957c'}
    for p,h in pins.items():assert sha(R/p)==h
    structures=read(R/'STRUCTURES.json');assert structures['labels_present'] is False
    def loader(_):
        return ([{'row_id':x['row_id'],'task':x['task'],'split':x['region'],'canonical_isomeric_smiles':x['raw_smiles']} for x in structures['rows']],
                {'structures_sha256':sha(R/'STRUCTURES.json')})
    c.load_structures=loader
    out=R/('encoder_'+kind)
    args=['export','--input',str(R),'--out',str(out),'--device','cuda:0','--batch-size','16']
    if kind=='C':
        model=SOURCE/'_dependencies/local_hf_models/ChemBERTa-zinc-base-v1'
        assert sha(model/'pytorch_model.bin')=='bf8a23d93cca196c3712c94ec379494a74be64c83d86a63b08f03e26db547267'
        m=c;args+=['--model',str(model)]
    else:
        source=SOURCE/'_dependencies/KPGT';checkpoint=source/'models/base.pth'
        assert sha(checkpoint)=='8811c117cfedddff5ef2a512290d1a7a73d3d9560773860bc3b06942c597d15d'
        m=importlib.import_module('extract_kpgt_v02');args+=['--source',str(source),'--checkpoint',str(checkpoint)]
    sys.argv=args;m.main()
    done=read(out/'completion.json');pieces=[];ids=[]
    for entry in done['batches']:
        p=out/entry['file'];assert sha(p)==entry['npz_sha256']
        with np.load(p) as z:pieces.append(z['features']);ids+=z['row_ids'].tolist()
    assert ids==[x['row_id'] for x in structures['rows']]
    features=np.concatenate(pieces);assert np.isfinite(features).all()
    np.savez_compressed(R/(kind+'.npz'),row_ids=np.asarray(ids),features=features)
    write(R/(kind+'_BINDING.json'),{'feature_sha256':sha(R/(kind+'.npz')),'structures_sha256':sha(R/'STRUCTURES.json'),
          'export_protocol_sha256':sha(out/'protocol.json'),'export_completion_sha256':sha(out/'completion.json'),
          'rows':len(ids),'labels_used':False,'fine_tuning':False,'pretraining_member_overlap_not_excluded':True})

if __name__=='__main__':
    if sys.argv[1]=='prepare':prepare()
    else:export(sys.argv[1])
