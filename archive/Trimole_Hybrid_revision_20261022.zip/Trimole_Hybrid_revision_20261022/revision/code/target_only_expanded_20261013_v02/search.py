"""Target-only model/representation search; freeze all recipes before scoring."""
import os
for n in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[n]='1'
os.environ['CUDA_VISIBLE_DEVICES']=''
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import json,hashlib,sys,time,copy,pickle,subprocess,traceback,concurrent.futures,signal,warnings
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr,rankdata
from sklearn.metrics import roc_auc_score
from sklearn.exceptions import ConvergenceWarning
R=Path(__file__).resolve().parent
OLD=Path('/mnt/data/projects/trimole_pool_automl_target_only_20261013_v01')
TASKS={'clearance_hepatocyte_az':'Spearman','cyp3a4_substrate_carbonmangels':'AUROC'}
SEEDS=[101,202,303,404,505]
DENY=False
def guard(event,args):
    if DENY and event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        if Path(os.fsdecode(args[0])).name in ['test.csv','evaluation_features.npz']:
            raise PermissionError('Test access forbidden during candidate CV')
sys.addaudithook(guard)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(d,f,indent=2,allow_nan=False)
def atomic(p,d):
    q=p.with_suffix('.pending');q.write_text(json.dumps(d,indent=2));os.replace(q,p)
def metric(task,y,p):
    z=float(roc_auc_score(y,p) if TASKS[task]=='AUROC' else spearmanr(y,p).statistic)
    assert np.isfinite(z);return z
def isclass(t):return TASKS[t]=='AUROC'
def catalog():
    out=[]
    def add(**kw):out.append(dict(id=f'c{len(out):03d}',**kw))
    for feature in ['C','K','CK','chemCK','desc','counts']:
        for v in [.0001,.001,.01,.1,1.,10.,100.]:add(kind='linear',feature=feature,value=v)
    for feature in ['C','K','CK','desc']:
        for c in [.1,1.,10.,100.]:
            for g in [.1,1.,10.]:add(kind='rbf',feature=feature,C=c,gamma_factor=g)
    for feature in ['CK','chemCK','counts','chem']:
        for leaf in [1,3,8]:
            for mf in [.3,.7]:add(kind='et',feature=feature,leaf=leaf,max_features=mf,trees=500)
        for depth in [2,4,6]:
            for reg in [1.,10.]:add(kind='xgb',feature=feature,depth=depth,reg_lambda=reg,trees=500)
    for feature in ['fp2','fp3','cnt2','cnt3','rdk','ap']:
        for c in [.01,.1,1.,10.,100.,1000.]:add(kind='tanimoto',feature=feature,C=c)
    # The preceding winners remain eligible under exactly their old settings.
    add(kind='anchor',feature='chem',trees=500)
    return out

def prepare():
    assert read(R/'FEATURE_STATUS.json')['status']=='COMPLETE'
    binding=read(R/'INPUT_BINDING.json')
    embeddings={}
    for kind in ['C','K']:
        assert sha(R/(kind+'.npz'))==read(R/(kind+'_BINDING.json'))['feature_sha256']
        with np.load(R/(kind+'.npz')) as z:embeddings[kind]={k:v for k,v in zip(z['row_ids'],z['features'])}
    for task in TASKS:
        d=R/task;rows=read(d/'ROWS.json');ids=[x['row_id'] for x in rows];n=binding[task]['development_rows']
        old=read(OLD/'target_only'/task/'INPUTS.json')
        assert sha(old['path'])==old['sha256']==binding[task]['development_sha256']
        assert sha(d/'development_labels.npz')==binding[task]['development_labels_sha256']
        assert sha(d/'chemical.npz')==binding[task]['chemical_sha256']
        assert sha(d/'ROWS.json')==binding[task]['rows_sha256']
        with np.load(d/'chemical.npz') as z:
            assert ids==z['row_ids'].tolist();x={k:z[k] for k in z.files if k!='row_ids'}
        x.update({k:np.asarray([embeddings[k][i] for i in ids],np.float32) for k in ['C','K']})
        x['chem']=np.column_stack([x['fp2'],x['desc']]);x['CK']=np.column_stack([x['C'],x['K']])
        x['chemCK']=np.column_stack([x['chem'],x['CK']])
        x['counts']=np.column_stack([np.log1p(x['cnt2']),x['desc']])
        np.savez_compressed(d/'development_features.npz',**{k:v[:n] for k,v in x.items()})
        np.savez_compressed(d/'evaluation_features.npz',**{k:v[n:] for k,v in x.items()})
        write(d/'FOLDS.json',{'folds':old['folds'],'source':str(OLD/'target_only'/task/'INPUTS.json'),
            'source_sha256':sha(OLD/'target_only'/task/'INPUTS.json'),'development_features_sha256':sha(d/'development_features.npz'),
            'evaluation_features_sha256':sha(d/'evaluation_features.npz'),'row_binding_sha256':sha(d/'ROWS.json'),
            'input_binding_sha256':sha(R/'INPUT_BINDING.json')})
    write(R/'CATALOG.json',catalog())

def tanimoto(a,b):
    dot=a@b.T;den=np.square(a).sum(1)[:,None]+np.square(b).sum(1)[None,:]-dot
    return np.divide(dot,den,out=np.zeros_like(dot),where=den>0)
def model(c,task,seed,width):
    from sklearn.pipeline import make_pipeline
    from sklearn.impute import SimpleImputer
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import Ridge,LogisticRegression
    from sklearn.ensemble import ExtraTreesClassifier,ExtraTreesRegressor
    from sklearn.svm import SVC,SVR
    from sklearn.kernel_ridge import KernelRidge
    from xgboost import XGBClassifier,XGBRegressor
    binary=isclass(task);k=c['kind']
    if k=='tanimoto':
        return SVC(C=c['C'],kernel='precomputed',class_weight='balanced',random_state=seed) if binary else KernelRidge(alpha=1/c['C'],kernel='precomputed')
    if k=='linear':
        m=LogisticRegression(C=c['value'],solver='liblinear',max_iter=3000,class_weight='balanced',random_state=seed) if binary else Ridge(alpha=1/c['value'])
    elif k=='rbf':
        kw=dict(C=c['C'],kernel='rbf',gamma=c['gamma_factor']/width)
        m=SVC(**kw,class_weight='balanced',random_state=seed) if binary else SVR(**kw,epsilon=.05)
    elif k in ['et','anchor']:
        leaf=(3 if binary else 8) if k=='anchor' else c['leaf']
        mf=('sqrt' if binary else .7) if k=='anchor' else c['max_features']
        klass=ExtraTreesClassifier if binary else ExtraTreesRegressor
        m=klass(n_estimators=c['trees'],min_samples_leaf=leaf,max_features=mf,n_jobs=1,random_state=seed,
                **({'class_weight':'balanced'} if binary else {}))
    elif k=='xgb':
        klass=XGBClassifier if binary else XGBRegressor
        m=klass(n_estimators=c['trees'],max_depth=c['depth'],learning_rate=.035,reg_lambda=c['reg_lambda'],
                subsample=.85,colsample_bytree=.8,n_jobs=1,tree_method='hist',random_state=seed,
                objective='binary:logistic' if binary else 'reg:squarederror')
    else:raise ValueError(k)
    pre=[SimpleImputer(strategy='median',keep_empty_features=True)]
    if k in ['linear','rbf']:pre.append(StandardScaler())
    return make_pipeline(*pre,m)
def predict(m,x,task):
    if isclass(task):
        if hasattr(m,'predict_proba'):return m.predict_proba(x)[:,list(m.classes_).index(1)]
        return m.decision_function(x)
    return m.predict(x)
def train_predict(c,task,seed,X,y,T):
    m=model(c,task,seed,X.shape[1]);a,b=X,T
    if c['kind']=='tanimoto':a,b=tanimoto(X,X),tanimoto(T,X)
    mu=float(y.mean());sd=float(y.std()) or 1.
    yy=y if isclass(task) else (y-mu)/sd
    with warnings.catch_warnings():
        warnings.simplefilter('error',ConvergenceWarning);m.fit(a,yy)
    pred=predict(m,b,task)
    if not isclass(task):pred=pred*sd+mu
    assert np.isfinite(pred).all()
    return m,pred,{'target_mean':mu,'target_sd':sd}

def fit(task,cid):
    global DENY
    DENY=True
    c=next(x for x in read(R/'CATALOG.json') if x['id']==cid);d=R/task
    out=d/'candidates'/cid;out.mkdir(parents=True,exist_ok=False)
    rec={'task':task,'candidate':c,'fold_scores':[]};start=time.time()
    try:
        f=read(d/'FOLDS.json');assert sha(d/'development_features.npz')==f['development_features_sha256']
        with np.load(d/'development_features.npz') as z:X=z[c['feature']]
        with np.load(d/'development_labels.npz') as z:y=z['y']
        oof=np.full(len(y),np.nan)
        for fold in f['folds']:
            a,b=np.asarray(fold['fit']),np.asarray(fold['validation'])
            _,p,_=train_predict(c,task,101,X[a],y[a],X[b]);oof[b]=p
            rec['fold_scores'].append(metric(task,y[b],p))
        assert np.isfinite(oof).all()
        np.savez_compressed(out/'OOF.npz',prediction=oof)
        rec.update(status='SUCCESS',cv_score=float(np.mean(rec['fold_scores'])),oof_sha256=sha(out/'OOF.npz'))
    except Exception as e:rec.update(status='FAILED',error=repr(e),traceback=traceback.format_exc())
    rec['seconds']=time.time()-start;write(out/'RESULT.json',rec)

def rankmean(preds):return np.mean([rankdata(x,method='average')/len(x) for x in preds],axis=0)
def freeze():
    result={}
    for task in TASKS:
        d=R/task;records=[read(p) for p in (d/'candidates').glob('*/RESULT.json')]
        good=sorted([x for x in records if x['status']=='SUCCESS'],key=lambda x:(-x['cv_score'],x['candidate']['id']))
        assert good
        by={x['candidate']['id']:x for x in good};folds=read(d/'FOLDS.json')['folds']
        with np.load(d/'development_labels.npz') as z:y=z['y']
        options=[{'name':'single','members':[good[0]['candidate']['id']]}]
        diverse=[];seen=set()
        for x in good:
            k=(x['candidate']['kind'],x['candidate']['feature'])
            if k not in seen:diverse.append(x['candidate']['id']);seen.add(k)
        for n in [3,5]:
            if len(good)>=n:options.append({'name':f'rank_top{n}','members':[x['candidate']['id'] for x in good[:n]]})
            if len(diverse)>=n:options.append({'name':f'rank_diverse{n}','members':diverse[:n]})
        for option in options:
            oofs=[]
            for cid in option['members']:
                p=d/'candidates'/cid/'OOF.npz';assert sha(p)==by[cid]['oof_sha256']
                with np.load(p) as z:oofs.append(z['prediction'])
            scores=[]
            for fold in folds:
                ix=np.asarray(fold['validation']);p=oofs[0][ix] if len(oofs)==1 else rankmean([x[ix] for x in oofs])
                scores.append(metric(task,y[ix],p))
            option.update(cv_score=float(np.mean(scores)),fold_scores=scores)
        chosen=max(enumerate(options),key=lambda v:(v[1]['cv_score'],-v[0]))[1]
        result[task]={'selected':chosen,'options':options,'successful':len(good),'recorded':len(records),
            'catalog_attempts':len(catalog()),'members':{cid:by[cid] for cid in chosen['members']},
            'selection':'mean development fold metric; fixed single/top3/top5/diverse3/diverse5 options',
            'test_used_for_this_recipe_selection':False,'historic_test_exposure':True}
    write(R/'SELECTION_FREEZE.json',result)

def final(task,seed):
    d=R/task;s=read(R/'SELECTION_FREEZE.json')[task];f=read(d/'FOLDS.json')
    for n in ['development','evaluation']:assert sha(d/(n+'_features.npz'))==f[n+'_features_sha256']
    with np.load(d/'development_labels.npz') as z:y=z['y']
    out=d/f'final_seed{seed}';out.mkdir(exist_ok=False)
    ps=[];models={};transforms={}
    for cid in s['selected']['members']:
        c=s['members'][cid]['candidate']
        with np.load(d/'development_features.npz') as z:X=z[c['feature']]
        with np.load(d/'evaluation_features.npz') as z:T=z[c['feature']]
        m,p,transform=train_predict(c,task,seed,X,y,T)
        ps.append(p);models[cid]=m;transforms[cid]=transform
    p=ps[0] if len(ps)==1 else rankmean(ps)
    with (out/'models.pkl').open('xb') as h:pickle.dump(models,h)
    np.savez_compressed(out/'predictions.npz',prediction=p,member_predictions=np.asarray(ps))
    write(out/'SEAL.json',{'task':task,'seed':seed,'selection_sha256':sha(R/'SELECTION_FREEZE.json'),
        'prediction_sha256':sha(out/'predictions.npz'),'models_sha256':sha(out/'models.pkl'),
        'transforms':transforms,'members':s['selected']['members'],'fit_rows':len(y),'prediction_rows':len(p),
        'test_labels_used_in_fit':False,'cross_task_supervised_rows':0})

def evaluate():
    seals={str(p.relative_to(R)):sha(p) for p in R.glob('*/final_seed*/SEAL.json')};assert len(seals)==10
    write(R/'ALL_PREDICTIONS_FROZEN.json',seals)
    results=[]
    for task in TASKS:
        d=R/task;rows=[x for x in read(d/'ROWS.json') if x['region']=='evaluation']
        source=Path(read(R/'INPUT_BINDING.json')[task]['development_path']).with_name('test.csv');test=pd.read_csv(source)
        ix=[x['source_row'] for x in rows];assert sorted(ix)==list(range(len(test)))
        assert [x['raw_smiles'] for x in rows]==test.iloc[ix].Drug.astype(str).tolist()
        for seed in SEEDS:
            dest=d/f'final_seed{seed}';seal=read(dest/'SEAL.json');assert sha(dest/'predictions.npz')==seal['prediction_sha256']
            with np.load(dest/'predictions.npz') as z:p=z['prediction']
            results.append({'task':task,'seed':seed,'metric':TASKS[task],'score':metric(task,test.iloc[ix].Y.to_numpy(float),p),'test_sha256':sha(source)})
    write(R/'RESULTS.json',{'rows':results,'scope':'expanded development-selected target-only fitting with frozen public C/K representations; historically reused benchmark test'})
    pd.DataFrame(results).to_csv(R/'SEED_SCORES.csv',index=False)

def job(args,cap):
    t=time.time();name='_'.join(args);log=R/'logs'/(name+'.log');log.parent.mkdir(exist_ok=True)
    with log.open('x') as h:
        p=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),*args],stdout=h,stderr=subprocess.STDOUT,start_new_session=True)
        try:rc=p.wait(timeout=cap)
        except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();rc=-9
    return {'command':args,'returncode':rc,'seconds':time.time()-t}
def controller():
    assert not (R/'SEARCH_STATUS.json').exists()
    pinned=read(R/'SEARCH_CODE_FREEZE.json')
    for p,h in pinned['code'].items():assert sha(R/p)==h
    state={'status':'PREPARING','started_unix':time.time(),'completed':[]};atomic(R/'SEARCH_STATUS.json',state)
    try:
        prepare();state['status']='CV_SEARCH';atomic(R/'SEARCH_STATUS.json',state)
        jobs=[['fit',t,c['id']] for t in TASKS for c in catalog()]
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as pool:
            fs=[pool.submit(job,j,600) for j in jobs]
            for f in concurrent.futures.as_completed(fs):state['completed'].append(f.result());atomic(R/'SEARCH_STATUS.json',state)
        freeze();state['status']='FINAL_REFIT';atomic(R/'SEARCH_STATUS.json',state)
        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as pool:
            fs=[pool.submit(job,['final',t,str(s)],1800) for t in TASKS for s in SEEDS]
            for f in concurrent.futures.as_completed(fs):state['completed'].append(f.result());atomic(R/'SEARCH_STATUS.json',state)
        evaluate();state['status']='FINISHED_REQUIRES_REVIEW'
    except Exception as e:state.update(status='FAILED',error=repr(e),traceback=traceback.format_exc())
    state['ended_unix']=time.time();atomic(R/'SEARCH_STATUS.json',state)

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='controller':controller()
    elif mode=='fit':fit(sys.argv[2],sys.argv[3])
    elif mode=='final':final(sys.argv[2],int(sys.argv[3]))
    elif mode=='catalog':print(json.dumps(catalog(),indent=2))
    else:raise ValueError(mode)
