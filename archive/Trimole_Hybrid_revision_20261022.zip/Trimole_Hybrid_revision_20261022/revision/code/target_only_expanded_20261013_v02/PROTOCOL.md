# Expanded target-only search — started 2026-10-13, continues 2026-10-14 Beijing

User authorized further optimization of hepatocyte clearance toward Spearman 0.552040 and CYP3A4 substrate toward AUROC 0.725249. These are goals, not guaranteed outcomes or fit stopping thresholds. Prior target-only test scores (0.471572 and 0.665981) and historical tests have already been seen. This is further development on reused benchmarks; no claim of an untouched confirmation dataset.

## Representation and supervision

Use each task's complete existing official train_val: 970 hepatocyte and 535 CYP3A4 rows. No other endpoint labels or historical endpoint-trained checkpoint is used. Fresh frozen ChemBERTa CLS (768) and KPGT (2304) features are extracted from keyed raw SMILES. C weight SHA256 bf8a23d93cca196c3712c94ec379494a74be64c83d86a63b08f03e26db547267; K weight SHA256 8811c117cfedddff5ef2a512290d1a7a73d3d9560773860bc3b06942c597d15d. C/K have public pretraining; membership overlap with benchmark structures is not excluded. They are not target-label-trained here. K uses the previously pinned upstream normalized-descriptor NaN-to-zero rule, with row/field audit; invalid structures and infinities fail.

Chemical features: radius-2/radius-3 2048-bit Morgan fingerprints and their count versions, 2048-bit RDKit-path and atom-pair fingerprints, and RDKit descriptors. Counts in ordinary heads use log1p; count kernels use the extended Tanimoto dot/(squared norm sum minus dot). Descriptor imputation and standardization, where applicable, are fitted on each fold's training rows. Regression target standardization is also fitted per fold.

Input feature extraction includes the 243+135 evaluation structures from an existing label-free export. No test labels enter extraction. Row IDs encode task, development/evaluation role and original source row; no test row is dropped. Complete feature batches, source hashes and weights are retained. GPU is bound to healthy UUID GPU-8dccd0a6-2c1e-0e9a-dda8-105662f17745. No old F controller is resumed.

## Fixed candidate search and combination

175 candidates per task, screening seed101:
- 42 linear heads (Ridge regression / balanced logistic classification) across six feature sets and seven regularization values.
- 48 RBF SVR/SVC heads across C, K, CK and descriptors, four C values and three bandwidth factors.
- 24 ExtraTrees and 24 XGBoost heads across CK, chemistry+CK, counts+descriptors and chemistry.
- 36 fingerprint/count-kernel heads across six fingerprint types and six regularization values (kernel ridge / balanced SVC).
- The exact preceding ExtraTrees winner configuration as one anchor.

Reuse the same three development scaffold-grouped folds as the preceding target-only run, after verifying the development CSV bytes. No outer test fold enters fitting or candidate selection. Each candidate gets a 600-second process cap for its three folds; timeouts, convergence failures and all other failures remain recorded and cannot win. Ten CPU workers, one numerical thread per job. There is no per-candidate early stopping. Tree counts are fixed at500.

Rank candidates by mean development-fold task metric, ties by candidate ID. Compare five fixed options: best single candidate, equal rank-average top3/top5, and equal rank-average of top3/top5 distinct (model kind, feature) pairs. Evaluate each combination inside the same held-out development fold, then average fold metrics. Rank aggregation uses within-batch prediction ranks (no labels); it is an ordinal score, not a calibrated probability. Select the highest mean CV option; exact ties prefer the earlier option (single first). These CV values guide selection and are not independent efficacy estimates.

Freeze both task recipes before this round's test scoring. Refit all selected components on all target train_val rows at seeds101/202/303/404/505. Use the same fixed chosen recipe for all seeds. Each final refit job has a1800-second cap; five parallel jobs. Seal all ten final prediction files before reading test labels. Test evaluation verifies exact ordered raw SMILES and full source-index coverage. Report mean metric and population SD, all failures, the prior round and gaps to the submitted scores. Do not select among rounds or seeds by favorable test performance while describing it as validation-only.

## Checks and scope

Before real heads: synthetic checks of six model pathways on regression/classification, rank aggregation, count-kernel algebra, denied test reads, and 175-item catalog count. After completion: score replay, model/prediction hashes, selected CV recipe replay, input identity and full evaluation-row coverage. No bootstrap, manuscript/reply edits, external data purchase, extra agents, leaderboard submission or old-output overwrite.
