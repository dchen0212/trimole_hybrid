from common import *
import traceback,time

def columns(f):
 return next(k for k in ['Drug','smiles','SMILES'] if k in f),next(k for k in ['Y','label','y','target'] if k in f)
def read_prediction(path,n,kind,ntrain,y=None):
 path=Path(path);head=pd.read_csv(path,nrows=0)
 pc=next(k for k in ['y_prob','y_pred','prediction'] if k in head)
 cols=[pc]+(['sample_idx'] if 'sample_idx' in head else [])
 if y is not None and 'y_true' in head:cols+=['y_true']
 f=pd.read_csv(path,usecols=cols)
 if 'sample_idx' in f:
  assert f.sample_idx.is_unique,str(path)
  f=f.sort_values('sample_idx').reset_index(drop=True)
  assert np.array_equal(f.sample_idx.to_numpy(),np.arange(len(f))),str(path)
 if kind=='trainval':
  assert len(f)==ntrain+n,(str(path),len(f),ntrain,n)
  f=f.iloc[ntrain:].reset_index(drop=True)
 assert len(f)==n,(str(path),len(f),n)
 if y is not None and 'y_true' in f:
  yy=f.y_true.to_numpy(float)
  if not np.allclose(yy,y,rtol=1e-5,atol=1e-5):
   meta=read(path.with_name('meta.json'))
   yy=yy*meta['label_std']+meta['label_mean']
   assert np.allclose(yy,y,rtol=1e-5,atol=1e-5),str(path)
 p=f[pc].to_numpy(float);assert np.isfinite(p).all()
 return p,{'path':str(path),'sha256':sha(path),'valid_source_kind':kind,'rows':len(f),'identity':'sample_idx plus source split order; inherited positional limitation'}

def prepare(task):
 plan=read(ROOT/'POOL_PLAN_v01.json');d=plan['tasks'][task];assert d['status']=='READY_TO_PREPARE'
 dest=ROOT/'prepared'/task;dest.mkdir(parents=True,exist_ok=False)
 data=Path(plan['historical_data_root'])/task
 tr=pd.read_csv(data/'train.csv');va=pd.read_csv(data/'valid.csv');sm,lab=columns(va)
 # Load structures only from historical test, never test labels here.
 te=pd.read_csv(data/'test.csv',usecols=[sm]);y=va[lab].to_numpy(float)
 groups=identity_keys(va[sm].astype(str));names=[];xs=[[] for _ in range(5)];ts=[[] for _ in range(5)];audit=[]
 if d['use_archived_nine']:
  core=plan['core_plan'];cdata=Path(core['candidate_split_root'])/task
  cv=pd.read_csv(cdata/'valid.csv');csm,clab=columns(cv);ct=pd.read_csv(cdata/'test.csv',usecols=[csm])
  assert va[sm].astype(str).tolist()==cv[csm].astype(str).tolist(),'VALID_ROW_ORDER_DIFFERENCE'
  assert te[sm].astype(str).tolist()==ct[csm].astype(str).tolist(),'TEST_ROW_ORDER_DIFFERENCE'
  assert np.allclose(y,cv[clab].to_numpy(float),rtol=1e-5,atol=1e-5)
  for name in core['candidate_pool']:
   names.append('archived_reference::'+name)
   for i,seed in enumerate(plan['search_seeds']):
    b=Path(core['candidate_root'])/name/task/f'seed_{seed}';vp=b/'valid_predictions.csv';tp=b/'test_predictions.csv'
    assert sha(vp)==core['validation_inputs'][str(vp)]
    v,a=read_prediction(vp,len(va),'valid',len(tr),y);t,binding=read_prediction(tp,len(te),'test',len(tr))
    xs[i].append(v);ts[i].append(t);audit.extend([a,binding])
 offset=len(names)
 for c in d['columns']:
  names.append('recipe_component::'+c['name'])
  for i,rs in enumerate(c['runs']):
   vs=[];tts=[]
   for r in rs:
    for split in ['valid','test']:
     p=Path(r[split+'_path']);expected=r.get(split+'_sha256')
     if expected:assert sha(p)==expected,(str(p),'HASH_MISMATCH')
    v,a=read_prediction(r['valid_path'],len(va),r['valid_source_kind'],len(tr),y)
    t,b=read_prediction(r['test_path'],len(te),'test',len(tr))
    vs.append(v);tts.append(t);audit.extend([a,b])
   xs[i].append(np.mean(vs,axis=0));ts[i].append(np.mean(tts,axis=0))
 for i in range(5):
  X=np.column_stack(xs[i]);T=np.column_stack(ts[i]);assert X.shape[1]==T.shape[1]==len(names)
  np.savez_compressed(dest/f'valid_run{i+1}.npz',X=X,y=y,groups=groups)
  np.savez_compressed(dest/f'test_inputs_run{i+1}.npz',X=T)
 write(dest/'ROWS.json',{'valid_smiles':va[sm].astype(str).tolist(),'test_smiles':te[sm].astype(str).tolist(),'source_split_hashes':{s:sha(data/(s+'.csv')) for s in ['train','valid','test']}})
 manual={**d['manual'],'indices':list(range(offset,len(names)))}
 write(dest/'READY.json',{'task':task,'metric':d['metric'],'names':names,'manual':manual,'runs':5,'valid_rows':len(va),'test_rows':len(te),'pool_plan_sha256':sha(ROOT/'POOL_PLAN_v01.json'),'task_plan':d,'source_audit':audit,'hashes':{p.name:sha(p) for p in dest.glob('*.npz')},'test_label_path':str(data/'test.csv'),'test_label_column':lab,'prior_test_exposure':True,'new_reconstruction':d.get('new_reconstruction',False),'test_labels_loaded_by_preparation':False,'time':time.time()})
 print(task,'READY',len(names),'columns',flush=True)

if __name__=='__main__':
 smoke();plan=read(ROOT/'POOL_PLAN_v01.json');results=[]
 tasks=sys.argv[1:] or [t for t,d in plan['tasks'].items() if d['status']=='READY_TO_PREPARE']
 for t in tasks:
  try:prepare(t);results.append({'task':t,'status':'READY'})
  except Exception as e:
   record={'task':t,'status':'FAILED','error':repr(e),'traceback':traceback.format_exc()};results.append(record)
   write(ROOT/'preparation_failures'/(t+'.json'),record);print(t,repr(e),flush=True)
 write(ROOT/'PREPARATION_SUMMARY.json',{'tasks':results})
