from common import *
import time,subprocess,concurrent.futures,signal

def job(task,run):
 p=ROOT/'logs';p.mkdir(exist_ok=True);tick=time.time()
 with (p/f'{task}_run{run}.log').open('xb') as f:
  child=subprocess.Popen([sys.executable,'-B',str(ROOT/'fit.py'),task,str(run)],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:code=child.wait(timeout=900)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait();code=-9
 return {'task':task,'run':run,'returncode':code,'seconds':time.time()-tick}

def main():
 smoke();plan=read(ROOT/'POOL_PLAN_v01.json');tasks=list(plan['tasks']);started=time.time()
 write(ROOT/'RUN_FREEZE.json',{'time':started,'code_hashes':{p.name:sha(p) for p in ROOT.glob('*.py')},'protocol_sha256':sha(ROOT/'PROTOCOL.md'),'pool_plan_sha256':sha(ROOT/'POOL_PLAN_v01.json'),'task_count':22,'CPU_workers':2,'GPU_used':False,'prior_test_exposure':True})
 state={'stage':'RUNNING','jobs':[],'evaluated':[],'evaluation_failures':[],'started':started};submitted=set();futures={}
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  while True:
   ready=[t for t in tasks if (ROOT/'prepared'/t/'READY.json').exists()]
   for t in ready:
    for run in range(1,6):
     key=(t,run)
     if key not in submitted:
      submitted.add(key)
      seal=ROOT/'fits'/t/f'run{run}'/'SEAL.json'
      if seal.exists():
       s=read(seal);assert s['prepared_sha256']==sha(ROOT/'prepared'/t/'READY.json')
       state['jobs'].append({'task':t,'run':run,'returncode':0,'reused_sealed_smoke':True})
      else:futures[pool.submit(job,t,run)]=key
   for fut in [f for f in futures if f.done()]:
    result=fut.result();state['jobs'].append(result);del futures[fut];print(result,flush=True)
   for t in ready:
    if t in state['evaluated'] or any(x['task']==t for x in state['evaluation_failures']):continue
    if all((ROOT/'fits'/t/f'run{i}'/'SEAL.json').exists() for i in range(1,6)):
     with (ROOT/'logs'/f'{t}_evaluation.log').open('xb') as f:
      p=subprocess.run([sys.executable,'-B',str(ROOT/'evaluate.py'),t],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT,timeout=120)
     if p.returncode==0:state['evaluated'].append(t)
     else:state['evaluation_failures'].append({'task':t,'returncode':p.returncode})
   state.update(prepared_tasks=ready,pending_inputs=[t for t in tasks if t not in ready],active_or_queued=len(futures),updated=time.time())
   if not futures:state['stage']='WAITING_FOR_INPUTS' if len(ready)<22 else 'FINISHED_WITH_FAILURES'
   else:state['stage']='RUNNING'
   if len(state['evaluated'])==22:state['stage']='COMPLETE'
   atomic(ROOT/'STATUS.json',state)
   summaries=[]
   for t in state['evaluated']:summaries+=read(ROOT/'evaluation'/t/'RESULTS.json')['summary']
   if summaries:pd.DataFrame(summaries).to_csv(ROOT/'LIVE_TASK_SUMMARY.csv',index=False)
   if state['stage'] in ['COMPLETE','FINISHED_WITH_FAILURES']:break
   time.sleep(10)
if __name__=='__main__':main()
