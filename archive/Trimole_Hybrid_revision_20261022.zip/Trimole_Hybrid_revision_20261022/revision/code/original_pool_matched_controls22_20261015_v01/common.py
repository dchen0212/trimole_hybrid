import os
for k in ['OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS']:os.environ[k]='1'
os.environ['CUDA_VISIBLE_DEVICES']=''
from pathlib import Path
import json,hashlib,sys
import numpy as np,pandas as pd
from scipy.stats import rankdata,spearmanr
from sklearn.metrics import roc_auc_score,average_precision_score,mean_absolute_error
from sklearn.model_selection import StratifiedGroupKFold,GroupKFold
ROOT=Path(__file__).resolve().parent
REFERENCE=Path('/mnt/data/projects/trimole_pool_automl_expanded120s_20261015_v01')
sys.path.append(str(REFERENCE))
from linear_adapter import logistic_factory,ridge_factory,register
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,o):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(o,f,indent=2,allow_nan=False,default=lambda x:x.item() if isinstance(x,np.generic) else str(x))
def atomic(p,o):
 p=Path(p);q=p.with_suffix('.pending');q.write_text(json.dumps(o,indent=2,default=str));os.replace(q,p)
def binary(metric):return metric in ['AUROC','AUPRC']
def score(metric,y,p):
 assert np.isfinite(p).all()
 v={'AUROC':roc_auc_score,'AUPRC':average_precision_score,'MAE':mean_absolute_error}.get(metric)
 x=float(v(y,p) if v else spearmanr(y,p).statistic)
 if not np.isfinite(x):raise ValueError('UNDEFINED_METRIC')
 return x
def utility(metric,s):return -s if metric=='MAE' else s
def predict(m,X,metric):
 if binary(metric):return np.asarray(m.predict_proba(X))[:,list(m.classes_).index(1)]
 return np.asarray(m.predict(X))
def transform(x,mode):
 x=np.asarray(x,float)
 if mode=='raw':return x
 if mode=='rank':return (rankdata(x,method='average')-1)/(len(x)-1) if len(x)>1 else np.zeros_like(x)
 if mode=='zscore':return (x-x.mean())/x.std() if x.std() else np.zeros_like(x)
 if mode=='logit':
  x=np.clip(x,1e-6,1-1e-6);return np.log(x/(1-x))
 raise ValueError(mode)
def identity_keys(smiles):
 from rdkit import Chem
 keys=[]
 for s in smiles:
  m=Chem.MolFromSmiles(s)
  if m is None:raise ValueError('INVALID_DEVELOPMENT_STRUCTURE')
  m=max(Chem.GetMolFrags(m,asMols=True,sanitizeFrags=True),key=lambda x:(x.GetNumHeavyAtoms(),Chem.MolToSmiles(x)))
  keys.append(Chem.MolToInchiKey(m).split('-')[0])
 return np.asarray(keys)
def folds(metric,y,g,seed):
 cv=StratifiedGroupKFold(3,shuffle=True,random_state=seed) if binary(metric) else GroupKFold(3)
 fs=list(cv.split(np.zeros((len(y),1)),y,g))
 for tr,va in fs:
  assert not set(g[tr])&set(g[va])
  if binary(metric):assert set(y[tr])==set(y[va])=={0,1},'INVALID_FOLD_CLASSES'
 return fs,cv
def smoke():
 # Metric direction and legacy blend transforms are independent contract checks.
 y=np.array([0,0,1,1]);p=np.array([.1,.4,.6,.9]);assert score('AUROC',y,p)==1
 assert utility('MAE',.2)>utility('MAE',.3)
 assert np.allclose(transform(np.array([2,2,5]),'rank'),[.25,.25,1])
 assert np.allclose(transform(np.array([.2,.8]),'logit'),[-np.log(4),np.log(4)])
 assert np.allclose(transform(np.ones(4),'zscore'),0)
