from common import *
import pickle,time

def evaluate(task):
 src=ROOT/'prepared'/task;info=read(src/'READY.json');metric=info['metric']
 dest=ROOT/'evaluation'/task;dest.mkdir(parents=True,exist_ok=False)
 seals={};allpred=[]
 for run in range(1,6):
  d=ROOT/'fits'/task/f'run{run}';s=read(d/'SEAL.json')
  assert s['prepared_sha256']==sha(src/'READY.json');assert s['model_sha256']==sha(d/'models.pkl')
  path=src/f'test_inputs_run{run}.npz';assert sha(path)==info['hashes'][path.name]
  X=np.load(path)['X'];assert X.shape[1]==len(s['names'])
  A=np.column_stack([transform(X[:,i],'rank') for i in range(X.shape[1])]) if metric=='Spearman' else X
  manual=s['manual'];P=np.column_stack([transform(X[:,i],manual['mode']) for i in manual['indices']])
  preds={'fixed_recipe':P@np.asarray(manual['weights']),
         'single_valid':X[:,s['ordering'][0]],'uniform':A.mean(axis=1),
         'top3_valid':A[:,s['ordering'][:3]].mean(axis=1)}
  with (d/'models.pkl').open('rb') as f:models=pickle.load(f)
  preds.update({name:predict(m,X,metric) for name,m in models.items()})
  assert len(preds)==7 and all(np.isfinite(p).all() for p in preds.values())
  np.savez_compressed(dest/f'predictions_run{run}.npz',**preds)
  seals[str(d/'SEAL.json')]=sha(d/'SEAL.json');allpred.append(preds)
 write(dest/'PREDICTIONS_FROZEN.json',{'time':time.time(),'model_seals':seals,'prediction_hashes':{p.name:sha(p) for p in dest.glob('*.npz')},'prior_test_exposure':True})
 write(dest/'TARGET_ACCESS_STARTED.json',{'time':time.time(),'path':info['test_label_path']})
 y=pd.read_csv(info['test_label_path'],usecols=[info['test_label_column']])[info['test_label_column']].to_numpy(float)
 assert len(y)==info['test_rows']
 rows=[]
 for run,preds in enumerate(allpred,1):
  for name,p in preds.items():rows.append({'task':task,'metric':metric,'run':run,'method':name,'score':score(metric,y,p)})
 df=pd.DataFrame(rows);df.to_csv(dest/'SEED_SCORES.csv',index=False)
 out=[]
 for name,g in df.groupby('method'):
  out.append({'task':task,'metric':metric,'method':name,'mean':float(g.score.mean()),'population_sd':float(g.score.std(ddof=0)),'runs':len(g)})
 write(dest/'RESULTS.json',{'task':task,'rows':rows,'summary':out,'new_reconstruction':info['new_reconstruction'],
                         'scope':'common prediction inputs; archived/fixed recipe arm is not independently selected; historical main table remains separately identified'})
 print(json.dumps(out),flush=True)
if __name__=='__main__':evaluate(sys.argv[1])
