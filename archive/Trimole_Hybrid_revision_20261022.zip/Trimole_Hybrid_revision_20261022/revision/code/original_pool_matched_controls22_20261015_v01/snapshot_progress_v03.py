"""Read-only server snapshot; write a new local timestamped report each call."""
from pathlib import Path
import json,subprocess,datetime,csv
ROOT=Path(__file__).resolve().parent
remote=r'''
import json,pathlib,time,subprocess
m=pathlib.Path('/mnt/data/projects/trimole_original_pool_matched_controls22_20261015_v01');c=pathlib.Path('/mnt/data/projects/trimole_chemprop22_20261015_v01')
read=lambda p:json.loads(p.read_text())
s={'unix':time.time(),'matched_status':read(m/'STATUS.json'),'chemprop_status':read(c/'STATUS.json'),'chemprop_controller':read(c/'CONTROLLER_STATUS.json'),'current_table':read(c/'current_table.json'),'matched_results':[read(p) for p in m.glob('evaluation/*/RESULTS.json')],'pools':[],'chemprop_results':[],'base_status':{},'failures':{}}
for p in m.glob('prepared/*/READY.json'):
 d=read(p);s['pools'].append({k:d.get(k) for k in ['task','metric','names','valid_rows','test_rows','new_reconstruction','task_plan']})
s['chemprop_results']=[read(p) for p in sorted((c/'chemprop').glob('*/evaluation/RESULTS.json'))]
overrides=read(m/'RESULT_OVERRIDES_v01.json') if (m/'RESULT_OVERRIDES_v01.json').exists() else {}
s['result_overrides']=overrides;s['superseded_results']=[]
for t,rec in overrides.items():
 s['superseded_results'] += [x for x in s['matched_results'] if x['task']==t]
 s['matched_results']=[x for x in s['matched_results'] if x['task']!=t]
 s['pools']=[x for x in s['pools'] if x['task']!=t]
 r=pathlib.Path(rec['root']);p=r/'evaluation'/t/'RESULTS.json'
 if p.exists():s['matched_results'].append(read(p))
 p=r/'prepared'/t/'READY.json'
 if p.exists():
  d=read(p);s['pools'].append({k:d.get(k) for k in ['task','metric','names','valid_rows','test_rows','new_reconstruction','task_plan']})
 p=r/'ERROR.json'
 if p.exists():s['failures'][str(p)]=read(p)
 jobs=[x for x in s['matched_status']['jobs'] if x['task']!=t]
 jobs += [{'task':t,'run':int(p.parent.name.removeprefix('run')),'returncode':0,'correction':True} for p in r.glob('fits/*/*/SEAL.json')]
 s['matched_status']['jobs']=jobs
s['matched_status']['evaluated']=[x['task'] for x in s['matched_results']]
s['chemprop_log_tail']=(c/'training.log').read_text()[-2000:]
for p in m.glob('base_reconstruction_v02/*/STATUS.json'):s['base_status'][p.parent.name]=read(p)
for pat in ['failures/*.json','base_reconstruction_failures_v02/*.json','target_only_preparation_errors/*.json']:
 for p in m.glob(pat):s['failures'][str(p.relative_to(m))]=read(p)
s['processes']=subprocess.run(['ps','-eo','pid,ppid,etime,pcpu,args'],capture_output=True,text=True).stdout
s['processes']='\n'.join(x for x in s['processes'].splitlines() if ('trimole_original_pool_matched_controls22_20261015_v01' in x or 'trimole_chemprop22_20261015_v01' in x) and ('python' in x or 'nice' in x))
print(json.dumps(s))
'''
p=subprocess.run(['ssh','dachen-server','python3','-'],input=remote,capture_output=True,text=True,check=True,timeout=40)
s=json.loads(p.stdout);stamp=datetime.datetime.fromtimestamp(s['unix'],datetime.timezone(datetime.timedelta(hours=8))).strftime('%Y%m%d_%H%M%S')
d=ROOT/('progress_'+stamp);d.mkdir();(d/'SNAPSHOT.json').write_text(json.dumps(s,indent=2))
main={x['task']:x for x in s['current_table']['results']}
def save(name,rows):
 if not rows:return
 with (d/name).open('x',newline='') as f:
  w=csv.DictWriter(f,fieldnames=list(rows[0]));w.writeheader();w.writerows(rows)
rows=[]
for r in s['matched_results']:
 for x in r['summary']:
  t=main[x['task']];sign=-1 if x['metric']=='MAE' else 1
  rows.append({**x,'current_table_mean':t['current_mean'],'current_table_sd':t['current_sd'],'current_table_advantage':sign*(t['current_mean']-x['mean']),'new_reconstruction_in_pool':r['new_reconstruction'],'comparison_scope':r['scope']})
save('MATCHED_METHODS_VS_MAIN.csv',rows)
chem=[]
for x in s['chemprop_results']:
 chem.append({k:x[k] for k in ['task','metric','mean','population_sd','current_table_mean','current_table_sd','current_advantage','rows']})
save('CHEMPROP_VS_MAIN.csv',chem)
pools=[{'task':p['task'],'metric':p['metric'],'candidates':len(p['names']),'meta_rows':p['valid_rows'],'test_rows':p['test_rows'],'new_reconstruction':p['new_reconstruction'],'pool_names':' | '.join(p['names'])} for p in s['pools']]
save('POOL_COVERAGE.csv',pools)
st=s['matched_status'];print(json.dumps({'snapshot':str(d),'prepared':len(pools),'completed_tasks':len(st['evaluated']),'completed_fits':len([x for x in st['jobs'] if x['returncode']==0]),'pending_inputs':st['pending_inputs'],'chemprop_completed':len(s['chemprop_results']),'failures':list(s['failures'])},ensure_ascii=False,indent=2))
