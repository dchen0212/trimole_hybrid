from common import *
import time
source=ROOT/'collect_final_v03.py';s=source.read_text()
a=s.index(' started=time.time()');b=s.index(" dest=ROOT/'completed_comparison_v03'")
s=s[:a]+" s=read(ROOT/'STATUS.json')\n overrides=read(ROOT/'RESULT_OVERRIDES_v01.json')\n"+s[b:]
s=s.replace("'completed_comparison_v03'","'reporting_preview_v03'")
ns={'__name__':'preview','__file__':str(source)};exec(compile(s,str(source),'exec'),ns);ns['collect']()
p=ROOT/'reporting_preview_v03';write(p/'PREVIEW_SOURCE.json',{'source_sha256':sha(source),'note':'descriptive preview of current saved scores; missing task rows explicitly incomplete; no model evaluation','time':time.time()})
print(p)
