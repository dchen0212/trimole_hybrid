"""Publish a new, hash-bound task manifest without editing consumed manifests."""
from common import *
import types,hashlib

def prepare_addition(task,extension):
 path=ROOT/'task_additions'/(task+'.json');write(path,extension)
 source=(ROOT/'prepare.py').read_text()
 # A failed preparation can have created an empty directory. Preserve its
 # separate failure receipt and allow only an empty, unpublished destination.
 source=source.replace("dest.mkdir(parents=True,exist_ok=False)","dest.mkdir(parents=True,exist_ok=True);assert not any(dest.iterdir()),'PREPARED_OUTPUT_ALREADY_EXISTS'")
 namespace={'__name__':'prepare_addition_library','__file__':str(ROOT/'prepare.py')}
 exec(compile(source,str(ROOT/'prepare.py'),'exec'),namespace)
 original=namespace['read']
 def read_extended(p):
  o=original(p)
  if Path(p)==ROOT/'POOL_PLAN_v01.json':
   d={**extension,'extension_path':str(path),'extension_sha256':sha(path)}
   o['tasks'][task]=d
  return o
 namespace['read']=read_extended
 namespace['prepare'](task)
if __name__=='__main__':
 task=sys.argv[1];extension=read(sys.argv[2]);prepare_addition(task,extension)
