"""New fixed-recipe reconstructions; no performance search or test labels."""
from common import *
import time,joblib,traceback,subprocess,concurrent.futures,copy,importlib.metadata
from types import SimpleNamespace
SNAP=Path('/mnt/data/projects/trimole_original_pool_completion22_20261015_v01/source_snapshot')
sys.path.insert(0,str(SNAP))
import descriptor_sidecar_official_v1 as base
import official_sidecar_nested_refit_v1 as nested
import paper_main_chem_select_multibackend_v3 as v3
import paper_main_chemical_prior_xl_v4 as v4
from rdkit import Chem
from prepare_addition import prepare_addition
E=Path('/mnt/data/projects/trimole_hybrid_revision_20260915/_dependencies/trimole_ept_swap_v1')
SEEDS=[101,202,303,404,505]
TASKS=['caco2_wang','bioavailability_ma','cyp2c9_substrate_carbonmangels','ld50_zhu','herg','cyp2c9_veith']
CHEM={'caco2_wang','bioavailability_ma','cyp2c9_veith'}
def run(task):
 out=ROOT/'base_reconstruction'/task;out.mkdir(parents=True,exist_ok=False);tick=time.monotonic()
 folder='top1_method_transfer_chem_lite_v1' if task in CHEM else 'paper_main_chemical_prior_xl_v4_all22_32core'
 source=E/'results_strict/fixed_chemical_endpoint_5run_v1'/folder/task/'summary.json';r=read(source)
 assert float(r['weight_sidecar'])==1.0 and not r['selected_variant'].endswith('_base_pred')
 data=E/'data/data_benchmark_official_v1'/task
 tr=pd.read_csv(data/'train.csv');va=pd.read_csv(data/'valid.csv');sc=nested.get_smiles_col(tr);lc=base.find_label_col(tr)
 te=pd.read_csv(data/'test.csv',usecols=[sc]);frames=[tr,va,te]
 for f in frames:assert all(Chem.MolFromSmiles(s) is not None for s in f[sc].astype(str))
 variant=r['selected_variant'];embedding=variant.startswith('embed_chem_');block=variant[len('embed_chem_') if embedding else len('chem_'):]
 v3.XL_FP_BITS=2048;chem=v3.chemv2.extra_chemical_blocks if task in CHEM else v4.extra_chemical_blocks_xl
 backend=v3.fit_backend if task in CHEM else v4.fit_backend_xl
 args=SimpleNamespace(tree_estimators=900,xgb_estimators=600,cat_estimators=700,n_jobs=1)
 embedding_paths=[]
 write(out/'RUN_FREEZE.json',{'task':task,'source_recipe':r,'source_recipe_sha256':sha(source),'parameters':'saved writer defaults: ET900/XGB600, three scaffold folds, topk/variant/backend from archived recipe; historical CLI unconfirmed','helper_hashes':{m.__name__:sha(m.__file__) for m in [base,nested,v3,v4]},'versions':{n:importlib.metadata.version(n) for n in ['numpy','scikit-learn','rdkit','xgboost']},'source_split_hashes':{s:sha(data/(s+'.csv')) for s in ['train','valid','test']},'embedding_used':embedding,'upstream_embedding_boundary':'inherited historical cache; not asserted fold-specific or leakage-free','test_labels_used':False,'seed101_caco_reuse':task=='caco2_wang'})
 atomic(out/'STATUS.json',{'stage':'FEATURES','time':time.time()})
 blocks=[chem(f[sc])[block] for f in frames]
 if embedding:
  candidate=r['candidate'].removeprefix('xl_v4_')
  if candidate=='kpgt':
   p=data/'embeddings/kpgt.npy';arr=np.load(p);assert len(arr)==sum(map(len,frames));emb=list(base.split_concat(arr,*map(len,frames)));embedding_paths=[p]
  elif candidate=='ept':
   embedding_paths=[data/'embeddings_ept'/(s+'_ept.npy') for s in ['train','valid','test']];emb=[np.load(p) for p in embedding_paths]
  else:raise ValueError('UNEXPECTED_FIXED_EMBEDDING:'+candidate)
  blocks=[np.concatenate([a,b],axis=1) for a,b in zip(emb,blocks)]
 write(out/'EMBEDDING_BINDING.json',{'files':{str(p):sha(p) for p in embedding_paths},'row_counts':[len(f) for f in frames]})
 Xtr,Xva,T=[base.sanitize_features(b.astype(np.float32)) for b in blocks];X=np.concatenate([Xtr,Xva]);y=np.concatenate([tr[lc].to_numpy(),va[lc].to_numpy()]);smiles=pd.concat([tr[sc],va[sc]],ignore_index=True).astype(str).tolist()
 kind=base.infer_task_type(y);topk=0 if str(r['selected_topk']).lower()=='all' else int(r['selected_topk'])
 rows=[]
 for run_index,seed in enumerate(SEEDS,1):
  d=out/f'seed{seed}';d.mkdir();atomic(out/'STATUS.json',{'stage':'FITTING','seed':seed,'time':time.time()})
  if task=='caco2_wang' and seed==101:
   old=Path('/mnt/data/projects/trimole_original_pool_completion22_20261015_v01/caco2_seed101_replay_v01');z=np.load(old/'predictions.npz');oof=z['oof'];pred=z['test_prediction']
   assert len(oof)==len(y) and len(pred)==len(T)
   write(d/'REUSE.json',{'source':str(old),'source_sha256':sha(old/'predictions.npz'),'recipe_matches':'chem_core_pair_torsion/ET900/topk512/seed101/three scaffold folds','new_historical_replay_mismatch_retained':True})
  else:
   fs=nested.build_scaffold_folds(smiles,3,seed);oof=np.zeros(len(y),np.float32);tp=[]
   write(d/'FOLDS.json',{'folds':[a.tolist() for a in fs],'seed':seed})
   for j,ho in enumerate(fs):
    mask=np.ones(len(y),bool);mask[ho]=False;idx=np.where(mask)[0]
    sel=v3.fit_selector(X[idx],y[idx],kind,topk);m=backend(r['selected_backend'],X[idx][:,sel],y[idx],kind,r['metric'],seed+j,args)
    oof[ho]=v3.predict_backend(m,X[ho][:,sel],kind);tp.append(v3.predict_backend(m,T[:,sel],kind))
    joblib.dump({'model':m,'selected_features':sel,'fit_rows':idx,'holdout_rows':ho},d/f'fold{j}.joblib')
   pred=np.mean(tp,axis=0).astype(np.float32)
  assert np.isfinite(oof).all() and np.isfinite(pred).all()
  pd.DataFrame({'sample_idx':np.arange(len(va)),'y_true':va[lc].to_numpy(),'y_pred':oof[len(tr):]}).to_csv(d/'valid_predictions.csv',index=False)
  pd.DataFrame({'sample_idx':np.arange(len(te)),'y_pred':pred}).to_csv(d/'test_predictions.csv',index=False)
  np.savez_compressed(d/'oof_predictions.npz',prediction=oof)
  rows.append({'valid_path':str(d/'valid_predictions.csv'),'test_path':str(d/'test_predictions.csv'),'valid_sha256':sha(d/'valid_predictions.csv'),'test_sha256':sha(d/'test_predictions.csv'),'valid_source_kind':'valid','seed_or_run':str(seed),'new_reconstruction':True})
  print(task,seed,'PREDICTIONS_SAVED',flush=True)
 write(out/'PREDICTIONS_FROZEN.json',{'rows':rows,'elapsed_seconds':time.monotonic()-tick,'test_labels_used':False})
 plan=read(ROOT/'POOL_PLAN_v01.json');ext=copy.deepcopy(plan['tasks'][task]);ext.update(status='READY_TO_PREPARE',new_reconstruction=True)
 ext['columns']=[{'name':'fixed_recipe_rebuilt','runs':[[a] for a in rows],'aggregation':'raw_mean','singleton_reused':False}]
 ext['manual']={'mode':'raw','weights':[1.]}
 # Additional archived original-family candidates are selected by file coverage,
 # never by their metric values. Their existing limitations are retained.
 extras=read(ROOT/'FIXED6_EXTRA_CANDIDATES.json').get(task,[])
 ext['columns']+=extras;ext['manual']['weights']+=[0.]*len(extras)
 cdata=Path(plan['core_plan']['candidate_split_root'])/task
 cv=pd.read_csv(cdata/'valid.csv');csm=next(k for k in ['Drug','smiles','SMILES'] if k in cv)
 oldsm=next(k for k in ['Drug','smiles','SMILES'] if k in va)
 if va[oldsm].astype(str).tolist()!=cv[csm].astype(str).tolist():
  ext['use_archived_nine']=False;ext['reference_exclusion_reason']='Different validation membership/order; no in-sample substitutes supplied'
 prepare_addition(task,ext)
 atomic(out/'STATUS.json',{'stage':'COMPLETE','time':time.time(),'seconds':time.monotonic()-tick})

if __name__=='__main__':
 if len(sys.argv)>1:
  try:run(sys.argv[1])
  except Exception as e:
   write(ROOT/'base_reconstruction_failures'/(sys.argv[1]+'.json'),{'error':repr(e),'traceback':traceback.format_exc()});raise
 else:
  def job(t):
   p=ROOT/'base_reconstruction_logs';p.mkdir(exist_ok=True)
   with (p/(t+'.log')).open('xb') as f:q=subprocess.run([sys.executable,'-B',__file__,t],cwd=ROOT,stdout=f,stderr=subprocess.STDOUT)
   return {'task':t,'returncode':q.returncode}
  with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
   for r in pool.map(job,TASKS):print(json.dumps(r),flush=True)
