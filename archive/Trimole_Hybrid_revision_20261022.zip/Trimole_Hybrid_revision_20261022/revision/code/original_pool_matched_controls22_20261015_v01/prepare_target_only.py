"""Recover current target-only component pools without accessing test labels."""
from common import *
import time,importlib.util,pickle,traceback
SEEDS=[101,202,303,404,505]
P=Path('/mnt/data/projects')
AUDIT=[]
def bound(path,expected=None):
 path=Path(path);h=sha(path)
 if expected:assert h==expected,(str(path),'HASH_MISMATCH')
 AUDIT.append({'path':str(path),'sha256':h});return path

def prediction(path,expected=None):
 return np.load(bound(path,expected),allow_pickle=False)['prediction'].copy()

def publish(task,metric,names,X,y,devrows,testrows,tests,manual,source,scope,new_reconstruction):
 dest=ROOT/'prepared'/task;dest.mkdir(parents=True,exist_ok=False)
 # Verify source row identity while explicitly excluding test labels.
 tp=Path(source).with_name('test.csv');frame=pd.read_csv(tp,usecols=['Drug'])
 ix=np.asarray([r['source_row'] for r in testrows]);assert sorted(ix.tolist())==list(range(len(frame)))
 assert frame.iloc[ix].Drug.astype(str).tolist()==[r['raw_smiles'] for r in testrows]
 order=np.argsort(ix);groups=identity_keys([r['raw_smiles'] for r in devrows])
 assert X.shape==(len(y),len(names)) and np.isfinite(X).all()
 for i,T in enumerate(tests,1):
  assert T.shape==(len(testrows),len(names)) and np.isfinite(T).all()
  np.savez_compressed(dest/f'valid_run{i}.npz',X=X,y=y,groups=groups)
  np.savez_compressed(dest/f'test_inputs_run{i}.npz',X=T[order])
 write(dest/'ROWS.json',{'development':devrows,'evaluation':testrows,'test_reordered_to_source':order.tolist(),'source_test_sha256':sha(tp)})
 write(dest/'READY.json',{'task':task,'metric':metric,'names':names,'manual':manual,'runs':5,'valid_rows':len(y),'test_rows':len(testrows),'pool_plan_sha256':sha(ROOT/'POOL_PLAN_v01.json'),'task_plan':scope,'source_audit':AUDIT,'hashes':{p.name:sha(p) for p in dest.glob('*.npz')},'test_label_path':str(tp),'test_label_column':'Y','prior_test_exposure':True,'new_reconstruction':new_reconstruction,'test_labels_loaded_by_preparation':False,'time':time.time(),'meta_training_rows':'one archived development OOF matrix reused across five final base fits; not five independent OOF constructions'})
 print(task,'READY',len(names),'columns',flush=True)

def cyp():
 task='cyp3a4_substrate_carbonmangels';root=P/'trimole_target_only_kernel_refine_20261014_v01';d=root/task
 spec=importlib.util.spec_from_file_location('target_kernel_source',bound(root/'search.py'));mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
 inp=read(bound(root/'INPUT_BINDING.json'))[task];folds=read(bound(d/'FOLDS.json'));chosen=read(bound(root/'SELECTION_FREEZE.json'))[task]
 cats=[c for c in read(bound(root/'CATALOG.json')) if c['task']==task];assert len(cats)==72
 ys=np.load(bound(d/'development_labels.npz',inp['development_labels_sha256']))['y']
 rows=read(bound(d/'ROWS.json',inp['rows_sha256']));dev=[r for r in rows if r['region']=='development'];ev=[r for r in rows if r['region']=='evaluation']
 Xs=dict(np.load(bound(d/'development_features.npz',folds['development_features_sha256'])))
 Ts=dict(np.load(bound(d/'evaluation_features.npz',folds['evaluation_features_sha256'])))
 names=[c['id'] for c in cats];oof=[]
 for c in cats:
  rec=read(bound(d/'candidates'/c['id']/'RESULT.json'));assert rec['status']=='SUCCESS' and rec['candidate']==c
  oof.append(prediction(d/'candidates'/c['id']/'OOF.npz',rec['oof_sha256']))
 out=ROOT/'target_only_pool_recovery'/task;out.mkdir(parents=True,exist_ok=False)
 write(out/'FREEZE.json',{'catalog':cats,'source_hashes':AUDIT,'reuse_selected':chosen['selected']['members'],'fit':'same archived hyperparameters, full target development, five seeds; no search','test_labels_used':False,'started':time.time()})
 tests=[];started=time.monotonic()
 for seed in SEEDS:
  sd=out/f'seed{seed}';sd.mkdir();old=d/f'final_seed{seed}';seal=read(bound(old/'SEAL.json'))
  oldp=bound(old/'predictions.npz',seal['prediction_sha256']);z=np.load(oldp);saved=dict(zip(seal['members'],z['member_predictions']));tp=[]
  for j,c in enumerate(cats):
   if c['id'] in saved:p=saved[c['id']]
   else:
    m,p,trans=mod.train_predict(c,task,seed,Xs[c['feature']],ys,Ts[c['feature']])
    with (sd/(c['id']+'.pkl')).open('xb') as f:pickle.dump({'model':m,'transform':trans,'candidate':c},f)
   tp.append(p)
   if (j+1)%12==0:atomic(out/'STATUS.json',{'stage':'REFIT','seed':seed,'completed_candidates':j+1,'total_candidates':72,'elapsed':time.monotonic()-started})
  T=np.column_stack(tp);tests.append(T)
  actual=z['prediction'];expected=np.mean([rankdata(T[:,names.index(cid)])/len(T) for cid in chosen['selected']['members']],axis=0)
  assert np.allclose(actual,expected,rtol=0,atol=1e-12)
  np.savez_compressed(sd/'predictions.npz',X=T)
  write(sd/'SEAL.json',{'prediction_sha256':sha(sd/'predictions.npz'),'reused_selected_prediction_sha256':sha(oldp),'new_fits':69,'reused_fits':3,'seed':seed,'test_labels_used':False})
  print(task,seed,'72 candidates available',round(time.monotonic()-started,1),flush=True)
 w=[1/3 if cid in chosen['selected']['members'] else 0 for cid in names]
 publish(task,'AUROC',names,np.column_stack(oof),ys,dev,ev,tests,{'mode':'rank','weights':w,'indices':list(range(72))},inp['development_path'],{'scope':'all 72 configurations in target-only kernel-refinement catalog; not every historical search branch','pool_size':72,'sources':'frozen C/K features, supervised heads fitted using target data only','new_test_predictions':69*5,'reused_test_predictions':3*5},True)
 atomic(out/'STATUS.json',{'stage':'COMPLETE','elapsed':time.monotonic()-started})

def hep():
 task='clearance_hepatocyte_az';B=P/'trimole_target_only_expanded_20261013_v02';C=P/'trimole_hepatocyte_kpgt_finetune_20261014_v02';D=P/'trimole_hepatocyte_staged_kpgt_20261014_v03';U=P/'trimole_hepatocyte_unimol_refined_geometry_20261014_v02'
 dev=read(bound(U/'development.json'));ev=read(bound(U/'evaluation.json'))['rows'];folds=read(bound(U/'FOLDS.json'))['folds'];y=np.asarray(dev['y'])
 for r in [C,D]:
  assert read(bound(r/'FOLDS.json'))['folds']==folds
  for name,rs in [('development',dev['rows']),('evaluation',ev)]:assert [x['row_id'] for x in read(bound(r/(name+'.json')))['rows']]==[x['row_id'] for x in rs]
 br=read(bound(B/task/'ROWS.json'));assert [x['row_id'] for x in br if x['region']=='development']==[x['row_id'] for x in dev['rows']]
 assert read(bound(B/task/'FOLDS.json'))['folds']==folds
 bs=read(bound(B/'SELECTION_FREEZE.json'))[task];ids=bs['selected']['members'];old=[prediction(B/task/'candidates'/cid/'OOF.npz',bs['members'][cid]['oof_sha256']) for cid in ids]
 models=[];sels=[]
 for r in [C,D,U]:
  s=read(bound(r/'SELECTION_FREEZE.json'))['selected'];sels.append(s);models.append(prediction(r/'selection_oof'/f"{s['config']['id']}_epoch{s['epochs']:02d}.npz",s['oof_sha256']))
 cb=read(bound(C/'BLEND_SELECTION_FREEZE.json'))['selected'];db=read(bound(D/'BLEND_SELECTION_FREEZE.json'))['selected'];ub=read(bound(U/'BLEND_SELECTION_FREEZE.json'))['selected']
 assert db['anchor']=='prior_fused' and ub['anchor']=='staged_fused';pw=cb['fine_tune_weight'];sw=db['fine_tune_weight'];uw=ub['new_model_weight']
 rank=lambda a:rankdata(a)/len(a)
 anchor=np.full(len(y),np.nan)
 for f in folds:
  ix=np.asarray(f['validation']);base=np.mean([rank(z[ix]) for z in old],axis=0);canon=(1-pw)*rank(base)+pw*rank(models[0][ix]);anchor[ix]=(1-sw)*rank(canon)+sw*rank(models[1][ix])
 X=np.column_stack(old+models+[anchor]);names=ids+['canonical_KPGT','staged_KPGT','UniMol','staged_fused_anchor'];assert len(names)==7
 tests=[]
 for seed in SEEDS:
  p=B/task/f'final_seed{seed}'/'predictions.npz';seal=read(bound(p.parent/'SEAL.json'));bound(p,seal['prediction_sha256']);bz=np.load(p);tp=list(bz['member_predictions']);assert len(tp)==3
  for r,s in zip([C,D,U],sels):
   p=r/'final'/f'seed{seed}'/f"epoch{s['epochs']:02d}"/'predictions.npz';seal=read(bound(p.parent/'SEAL.json'));tp.append(prediction(p,seal['prediction_sha256']))
  dr=next(x for x in read(bound(D/'BLEND_PREDICTIONS_FROZEN.json')) if x['seed']==seed);ap=prediction(D/dr['path'],dr['sha256']);tp.append(ap)
  rec=next(x for x in read(bound(U/'BLEND_PREDICTIONS_FROZEN.json')) if x['seed']==seed);actual=prediction(U/rec['path'],rec['sha256']);expected=(1-uw)*rank(ap)+uw*rank(tp[5]);assert np.allclose(expected,actual,atol=1e-12,rtol=0)
  tests.append(np.column_stack(tp))
 inp=read(bound(U/'INPUT_BINDING.json'))['source'];weights=[0,0,0,0,0,uw,1-uw]
 publish(task,'Spearman',names,X,y,dev['rows'],ev,tests,{'mode':'rank','weights':weights,'indices':list(range(7))},inp['development_path'],{'scope':'six selected leaf components plus existing recursively fused anchor; all arms receive all seven inputs; not full historical encoder search space','recursive_weights_preserved':True,'weights':{'canonical':pw,'staged':sw,'final':uw},'pool_size':7,'old_legacy_nine_excluded':True},False)

if __name__=='__main__':
 try:{'cyp':cyp,'hep':hep}[sys.argv[1]]()
 except Exception as e:
  write(ROOT/'target_only_preparation_errors'/(sys.argv[1]+'.json'),{'error':repr(e),'traceback':traceback.format_exc()});raise
