import pathlib,json,os,subprocess,time,signal
R=pathlib.Path(__file__).resolve().parent
old=1007624
cmd=pathlib.Path(f'/proc/{old}/cmdline').read_bytes();assert str(R/'controller.py').encode() in cmd
receipt={'old_controller':old,'time':time.time(),'method':'pause dispatch, let active fits/evaluations finish, replace dispatcher only','fit_or_gpu_processes_interrupted':False}
def children():
 rows=subprocess.check_output(['ps','-eo','pid=,ppid=,stat=,args='],text=True).splitlines();out=[]
 for line in rows:
  a=line.split(None,3)
  if len(a)==4 and int(a[1])==old and not a[2].startswith('Z'):out.append({'pid':int(a[0]),'state':a[2],'command':a[3]})
 return out
os.kill(old,signal.SIGSTOP)
try:
 receipt['draining_children']=children();deadline=time.time()+240
 for child in receipt['draining_children']:
  assert str(R/'fit.py') in child['command'] or str(R/'evaluate.py') in child['command'],child
 while children():
  if time.time()>deadline:raise TimeoutError('dispatch pause timed out; restore old controller')
  time.sleep(5)
 for child in receipt['draining_children']:
  a=child['command'].split()
  if str(R/'fit.py') in a:
   ix=a.index(str(R/'fit.py'));t=a[ix+1];n=a[ix+2];assert (R/'fits'/t/f'run{n}'/'SEAL.json').exists(),(t,n)
  else:
   ix=a.index(str(R/'evaluate.py'));t=a[ix+1];assert (R/'evaluation'/t/'RESULTS.json').exists(),t
 receipt['drained_at']=time.time()
 # All model/evaluation subprocesses have finished; only the stopped dispatcher is replaced.
 os.kill(old,signal.SIGKILL)
 e=json.loads((R/'ENVIRONMENT.json').read_text());env={**os.environ,**e['environment']}
 p=subprocess.Popen(['nice','-n','10',e['python'],'-B',str(R/'controller_v02.py')],cwd=R,env=env,stdout=(R/'controller_v02.log').open('xb'),stderr=subprocess.STDOUT,start_new_session=True)
 receipt.update(new_controller=p.pid,new_CPU_workers=4)
 with (R/'RESUME_FOUR_WORKERS_v02.json').open('x') as f:json.dump(receipt,f,indent=2)
 print(json.dumps(receipt),flush=True)
except Exception:
 try:os.kill(old,signal.SIGCONT)
 except ProcessLookupError:pass
 raise
