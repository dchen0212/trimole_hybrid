"""Descriptive reporting metadata; no model fitting or test-label reads."""
from common import *
def metadata():
 overrides=read(ROOT/'RESULT_OVERRIDES_v01.json') if (ROOT/'RESULT_OVERRIDES_v01.json').exists() else {}
 out={}
 for task in read(ROOT/'POOL_PLAN_v01.json')['tasks']:
  tr=Path(overrides[task]['root']) if task in overrides else ROOT
  ip=tr/'prepared'/task/'READY.json'
  if not ip.exists():continue
  info=read(ip);yp=ip.parent/'valid_run1.npz';assert sha(yp)==info['hashes'][yp.name];z=np.load(yp);y=z['y'];groups=z['groups']
  oof=task in ['clearance_hepatocyte_az','cyp3a4_substrate_carbonmangels']
  md={'task':task,'n_meta':len(y),'meta_positive_count':int(sum(y==1)) if binary(info['metric']) else None,'meta_positive_rate':float(np.mean(y==1)) if binary(info['metric']) else None,'meta_unique_groups':len(set(groups)),'meta_source':'development OOF (one shared matrix across five final fits)' if oof else 'archived validation rows; some reconstructed components use OOF on these rows','new_base_reconstruction':info['new_reconstruction'],'recipe_status':'newly reconstructed components; not exact submitted-run replay' if info['new_reconstruction'] else 'recovered component inputs; not a blanket exact-replay certification','candidate_count':len(info['names']),'test_rows':info['test_rows'],'earlier_test_exposure':True,'regression_meta_folds':'GroupKFold, unshuffled and identical across five runs' if not binary(info['metric']) else 'StratifiedGroupKFold, separately seeded','source_root':str(tr),'READY_sha256':sha(ip),'fold_class_counts':[]}
  for p in sorted((tr/'fits'/task).glob('run*/FOLDS.json')):
   for i,f in enumerate(read(p)['folds']):
    ix=np.asarray(f['validation']);md['fold_class_counts'].append({'run':int(p.parent.name[3:]),'fold':i,'n_validation':len(ix),'positive_count':int(sum(y[ix]==1)) if binary(info['metric']) else None})
  out[task]=md
 return out
if __name__=='__main__':
 print(json.dumps(metadata()))
