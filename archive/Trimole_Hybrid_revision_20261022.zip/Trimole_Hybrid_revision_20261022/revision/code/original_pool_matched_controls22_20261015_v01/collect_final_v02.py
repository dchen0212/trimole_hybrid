"""Read saved metrics only; create final comparison tables after the controller ends."""
from common import *
import time,traceback

def collect():
 started=time.time()
 while True:
  s=read(ROOT/'STATUS.json')
  if s['stage'] in ['COMPLETE','FINISHED_WITH_FAILURES']:
   overrides=read(ROOT/'RESULT_OVERRIDES_v01.json')
   if all((Path(v['root'])/'COMPLETE.json').exists() or (Path(v['root'])/'ERROR.json').exists() for v in overrides.values()):break
  if time.time()-started>24*3600:raise TimeoutError('Controller did not finish within 24 hours')
  time.sleep(30)
 dest=ROOT/'completed_comparison_v02';dest.mkdir(exist_ok=False)
 table_path=Path('/mnt/data/projects/trimole_chemprop22_20261015_v01/current_table.json');table=read(table_path)['results'];main={x['task']:x for x in table}
 methods=['fixed_recipe','single_valid','uniform','top3_valid','stacking_fixed','stacking_tuned','flaml_expanded120s'];wide=[];long=[];inputs=[]
 for task in read(ROOT/'POOL_PLAN_v01.json')['tasks']:
  task_root=Path(overrides[task]['root']) if task in overrides else ROOT
  info_path=task_root/'prepared'/task/'READY.json';info=read(info_path) if info_path.exists() else None
  p=task_root/'evaluation'/task/'RESULTS.json';r=read(p) if p.exists() else None
  t=main[task];w={'task':task,'metric':t['metric'],'current_table_mean':t['current_mean'],'current_table_sd':t['current_sd'],'status':'COMPLETE' if r else 'INCOMPLETE','candidate_count':len(info['names']) if info else None,'test_rows':info['test_rows'] if info else None,'new_reconstruction':info['new_reconstruction'] if info else None}
  by={x['method']:x for x in r['summary']} if r else {}
  for method in methods:
   x=by.get(method);w[method+'_mean']=x['mean'] if x else None;w[method+'_sd']=x['population_sd'] if x else None
   if x:long.append({**x,'current_table_mean':t['current_mean'],'current_table_advantage':utility(t['metric'],t['current_mean'])-utility(t['metric'],x['mean']),'test_rows':info['test_rows'],'new_reconstruction':info['new_reconstruction']})
  wide.append(w)
  if info:inputs.append({'task':task,'READY_sha256':sha(info_path),'candidate_names':info['names'],'task_plan':info['task_plan'],'meta_rows':info['valid_rows'],'test_rows':info['test_rows'],'new_reconstruction':info['new_reconstruction']})
 pd.DataFrame(wide).to_csv(dest/'BENCHMARK22_WIDE.csv',index=False);pd.DataFrame(long).to_csv(dest/'BENCHMARK_METHODS_LONG.csv',index=False)
 write(dest/'POOL_AND_ROW_COVERAGE.json',inputs)
 write(dest/'RECEIPT.json',{'status':s['stage'],'evaluated_tasks':len([x for x in wide if x['status']=='COMPLETE']),'result_overrides':overrides,'controller_status':s,'main_table_sha256':sha(table_path),'files':{p.name:sha(p) for p in dest.iterdir()},'scope':'retrospective common-input comparison; main-table reference kept separate from rebuilt fixed recipe; solubility historical 1995-row subset; no new metric computation in collector','time':time.time()})
if __name__=='__main__':
 try:collect()
 except Exception as e:write(ROOT/'FINAL_COLLECTION_ERROR_v02.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
