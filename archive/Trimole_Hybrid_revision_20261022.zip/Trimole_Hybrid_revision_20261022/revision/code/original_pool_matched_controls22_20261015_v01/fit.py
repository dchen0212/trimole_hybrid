from common import *
import pickle,copy,time,warnings,traceback

def deny_test(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  s=os.fsdecode(args[0]);name=Path(s).name
  if name=='test.csv' or 'test_inputs_run' in name or 'test_predictions' in name or name=='current_table.json':
   raise PermissionError('TEST_OR_REFERENCE_ACCESS_FORBIDDEN_DURING_META_FIT:'+s)

def fit(task,run):
 sys.addaudithook(deny_test)
 seed=[101,202,303,404,505][run-1];src=ROOT/'prepared'/task;info=read(src/'READY.json');metric=info['metric']
 path=src/f'valid_run{run}.npz';assert sha(path)==info['hashes'][path.name]
 z=np.load(path);X=z['X'];y=z['y'];g=z['groups'];names=info['names']
 dest=ROOT/'fits'/task/f'run{run}';dest.mkdir(parents=True,exist_ok=False);start=time.monotonic()
 fs,cv=folds(metric,y,g,seed);write(dest/'FOLDS.json',{'folds':[{'fit':a.tolist(),'validation':b.tolist()} for a,b in fs],'grouping':'parent connectivity groups; not scaffold groups'})
 ordering=sorted(range(len(names)),key=lambda i:(-utility(metric,score(metric,y,X[:,i])),names[i]))
 maker=logistic_factory if binary(metric) else ridge_factory
 grid=[1e-4,1e-3,.01,.1,1.,10.,100.,1000.,10000.];trace=[]
 with warnings.catch_warnings(record=True) as warns:
  warnings.simplefilter('always')
  for value in grid:
   cfg={'C':value,'random_state':seed} if binary(metric) else {'alpha':value}
   scores=[]
   for tr,va in fs:
    m=maker(**cfg);m.fit(X[tr],y[tr]);scores.append(score(metric,y[va],predict(m,X[va],metric)))
   trace.append({'config':cfg,'cv_score':float(np.mean(scores))})
  best=max(trace,key=lambda r:utility(metric,r['cv_score']))
  tuned=maker(**best['config']);tuned.fit(X,y)
  fixed=maker(random_state=seed);fixed.fit(X,y)
 control_seconds=time.monotonic()-start
 import flaml
 from flaml import AutoML
 assert flaml.__version__=='2.7.0'
 a=AutoML();register(a)
 learners=['rf','extra_tree','xgboost','lgbm','catboost','linear_cls' if binary(metric) else 'ridge_scaled']
 loss_calls=[]
 def loss(X_val,y_val,estimator,labels,X_train,y_train,*args,**kw):
  try:s=score(metric,y_val,predict(estimator,X_val,metric));v=s if metric=='MAE' else 1-s
  except ValueError:s=None;v=float('inf')
  loss_calls.append({'score':s,'fit_rows':len(y_train),'validation_rows':len(y_val)})
  return v,{'score':s if s is not None else 0.0}
 tick=time.monotonic()
 a.fit(X_train=X,y_train=y,groups=g,task='classification' if binary(metric) else 'regression',
       metric=loss,estimator_list=learners,time_budget=120,max_iter=100000,n_jobs=1,seed=seed,
       n_concurrent_trials=1,eval_method='cv',split_type=cv,n_splits=3,sample=False,auto_augment=False,
       retrain_full=False,ensemble=False,skip_transform=True,keep_search_state=True,
       log_file_name=str(dest/'search.log'),log_type='all',verbose=0,mlflow_logging=False,
       early_stop=False,hpo_method='cfo',custom_hp={n:{('random_seed' if n=='catboost' else 'random_state'):{'domain':seed,'init_value':seed}} for n in learners})
 search_seconds=time.monotonic()-tick
 assert a.model is not None and np.isfinite(a.best_loss)
 m=copy.deepcopy(a.model);m.cleanup();m.params['thread_count' if a.best_estimator=='catboost' else 'n_jobs']=1
 params=copy.deepcopy(m.params);tick=time.monotonic();m.fit(X,y,budget=None);refit_seconds=time.monotonic()-tick
 assert params==m.params
 with (dest/'models.pkl').open('xb') as f:pickle.dump({'stacking_fixed':fixed,'stacking_tuned':tuned,'flaml_expanded120s':m},f)
 logs=[json.loads(s) for s in (dest/'search.log').read_text().splitlines()]
 write(dest/'SEAL.json',{'task':task,'run':run,'meta_seed':seed,'metric':metric,'prepared_sha256':sha(src/'READY.json'),
  'valid_sha256':sha(path),'model_sha256':sha(dest/'models.pkl'),'names':names,'ordering':ordering,'manual':info['manual'],
  'stacking_grid':trace,'stacking_choice':best,'best_estimator':a.best_estimator,'best_config':a.best_config,
  'attempted_learners':sorted({r['learner'] for r in logs if 'learner' in r}),'cv_loss':float(a.best_loss),'selected_params':params,
  'control_seconds':control_seconds,'search_seconds':search_seconds,'refit_seconds':refit_seconds,
  'elapsed_seconds':time.monotonic()-start,'loss_calls':loss_calls,'warnings':sorted(set(str(w.message) for w in warns)),
  'code_hashes':{p.name:sha(p) for p in ROOT.glob('*.py')},'test_labels_used_for_meta_selection':False,
  'interpretation':'retrospective common-input comparison with inherited historical candidate selection/exposure; not independent validation'})
 print(task,run,'SEALED',a.best_estimator,flush=True)

if __name__=='__main__':
 try:fit(sys.argv[1],int(sys.argv[2]))
 except Exception as e:
  p=ROOT/'failures'/f'{sys.argv[1]}_run{sys.argv[2]}.json'
  write(p,{'error':repr(e),'traceback':traceback.format_exc()});raise
