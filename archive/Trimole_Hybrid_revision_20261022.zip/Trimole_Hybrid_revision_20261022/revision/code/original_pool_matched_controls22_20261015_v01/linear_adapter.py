from flaml import tune
from flaml.automl.model import SKLearnEstimator
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression,Ridge

def logistic_factory(C=1.,random_state=101,**kwargs):
    return make_pipeline(StandardScaler(),LogisticRegression(C=C,solver='lbfgs',max_iter=5000,random_state=random_state))
def ridge_factory(alpha=1.,**kwargs):
    return make_pipeline(StandardScaler(),Ridge(alpha=alpha))
class LinearClassifier(SKLearnEstimator):
    @classmethod
    def search_space(cls,**kwargs):return {'C':{'domain':tune.loguniform(1e-4,1e4),'init_value':1.}}
    @classmethod
    def cost_relative2lgbm(cls):return 1.
    def __init__(self,task='classification',**config):
        super().__init__(task,**config);self.estimator_class=logistic_factory
class RidgeScaled(SKLearnEstimator):
    @classmethod
    def search_space(cls,**kwargs):return {'alpha':{'domain':tune.loguniform(1e-4,1e4),'init_value':1.}}
    @classmethod
    def cost_relative2lgbm(cls):return 1.
    def __init__(self,task='regression',**config):
        super().__init__(task,**config);self.estimator_class=ridge_factory

def register(a):
    a.add_learner(learner_name='linear_cls',learner_class=LinearClassifier)
    a.add_learner(learner_name='ridge_scaled',learner_class=RidgeScaled)
