from pathlib import Path
import ast,csv,json,shutil
P=Path(__file__).resolve().parent;PROJECT=P.parent.parent
A=PROJECT/'outputs/original_candidate_pool_recovery_20261015_v01'
OLD=PROJECT/'outputs/original_pool_completion22_20261015_v01'
NEW='/mnt/data/projects/trimole_original_pool_completion22_20261015_v01'
E='/mnt/data/projects/trimole_hybrid_revision_20260915/_dependencies/trimole_ept_swap_v1'
components=json.loads((A/'FINAL_RECIPE_COMPONENT_MAP.json').read_text())
pairs=list(csv.DictReader((A/'PAIRED_PREDICTION_FILES_FINAL.csv').open(encoding='utf-8-sig')))
core=json.loads((PROJECT/'outputs/pool_automl_expanded120s_20261015_v01/S28_SOURCE_PLAN.json').read_text())
tree=ast.parse((A/'source_code/run_v29_exact_endpoint_5run_v1.py').read_text())
recipes=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.AnnAssign) and isinstance(n.target,ast.Name) and n.target.id=='RECIPES'))
def save(name,o):
 with (P/name).open('x') as f:json.dump(o,f,indent=2,ensure_ascii=False)
def select(task,root,contains=''):
 out=[dict(r) for r in pairs if r['task']==task and r['root']=='E' and r['root_name']==root and contains in r['valid_path']]
 assert out,(task,root,contains)
 return sorted(out,key=lambda r:int(r['seed_or_run']) if r['seed_or_run'].isdigit() else -1)
def col(name,rs):
 assert len(rs) in [1,5],(name,len(rs))
 return {'name':name,'runs':[[rs[i if len(rs)==5 else 0]] for i in range(5)],'aggregation':'raw_mean','singleton_reused':len(rs)==1}
def bagcols(task,roots,name):
 rs=[r for c in components if c['task']==task and c['root_name'] in roots for r in c['pairs']]
 assert len(rs)==25,(task,len(rs))
 groups=[]
 for i in range(5):
  if task=='ames':wanted=[11,22,33,44,55] if i==0 else [100*i+x for x in [11,22,33,44,55]]
  else:wanted=list(range(1+10*i,6+10*i))
  g=sorted([r for r in rs if int(r['seed_or_run']) in wanted],key=lambda x:int(x['seed_or_run']))
  assert len(g)==5,(task,i,wanted);groups.append(g)
 return {'name':name,'runs':groups,'aggregation':'raw_mean','singleton_reused':False}
plan={'schema':'recovered_recipe_component_union_v1','tasks':{},'run_indices':[1,2,3,4,5],'search_seeds':[101,202,303,404,505],
      'candidate_scope':'nine archived reference candidates plus fixed recipe inputs where roles and rows align; current target-only endpoints exclude legacy reference candidates',
      'scope':'retrospective matched-input comparison; not full historical search reconstruction, not independent benchmark validation',
      'core_plan':core,'historical_data_root':E+'/data/data_benchmark_official_v1'}
for t in core['tasks']:
 d={'task':t,'metric':core['task_metrics'][t],'use_archived_nine':t not in ['clearance_hepatocyte_az','cyp3a4_substrate_carbonmangels'],
    'columns':[],'manual':None,'status':'PENDING_COMPONENTS','row_source':'archived_valid_test','legacy_upstream_limitations_inherited':True}
 cs=[c for c in components if c['task']==t]
 if t in ['vdss_lombardo','cyp2d6_veith','cyp3a4_veith','lipophilicity_astrazeneca','dili','half_life_obach']:
  for c in cs:d['columns'].append(col(c['component'],c['pairs']))
  d['manual']={'mode':recipes[t]['mode'],'weights':recipes[t]['weights']}
 elif t=='pgp_broccatelli':
  d['columns']=[col(c['component'],sorted(c['pairs'],key=lambda x:int(x['seed_or_run']))) for c in cs]
  d['manual']={'mode':'logit','weights':[.65,.25,.10]}
 elif t in ['ames','clearance_microsome_az']:
  g=bagcols(t,{c['root_name'] for c in cs},'within_run_members')
  # Keep each of the five member predictions as a separate candidate.
  d['columns']=[{'name':f'member_position_{j+1}','runs':[[g['runs'][i][j]] for i in range(5)],'aggregation':'raw_mean','singleton_reused':False} for j in range(5)]
  d['manual']={'mode':'raw','weights':[.2]*5}
 elif t=='ppbr_az':
  d['columns']=[bagcols(t,{'ept_family_official_v1_5seed_runs','ppbr_kpgt_seedbag_endpoint_v1'},'kpgt_seedbag'),col('fp_only',cs[-1]['pairs'])]
  d['manual']={'mode':'raw','weights':[.7,.3]}
 elif t=='cyp2d6_substrate_carbonmangels':
  d['columns']=[bagcols(t,{c['root_name'] for c in cs[:3]},'ap_seedbag'),col('xl',cs[3]['pairs']),col('descriptor_v2',cs[4]['pairs'])]
  d['manual']={'mode':'zscore','weights':[.8,.1,.1]}
 elif t=='hia_hou':
  d['columns']=[col('selected_gated',select(t,'official_selected_5seed_materialize_v1','__chemberta_kpgt_ept_gated__')),col('bagged_sidecar',select(t,'official_sidecar_bagged_blend_v1'))]
  rs=[{'valid_path':f'{NEW}/hia_logreg_component_rebuild_v01/valid_predictions_seed_{i}.csv','test_path':f'{NEW}/hia_logreg_component_rebuild_v01/test_predictions_seed_{i}.csv','valid_source_kind':'valid','seed_or_run':str(i),'new_reconstruction':True} for i in range(1,6)]
  d['columns'].append(col('chem_logreg_rebuilt',rs));d['manual']={'mode':'rank','weights':[.1,.5,.4]};d['new_reconstruction']=True
 elif t=='bbb_martins':
  for b in ['extratrees','rf','gb','hgb','logreg']:
   rs=[{'valid_path':f'{NEW}/bbb_five_backend_rebuild_v01/{b}_seed{i}/valid.csv','test_path':f'{NEW}/bbb_five_backend_rebuild_v01/{b}_seed{i}/test_refit.csv','valid_source_kind':'valid','seed_or_run':str(i),'new_reconstruction':True} for i in range(1,6)]
   d['columns'].append(col(b+'_rebuilt',rs))
  d['manual']={'mode':'raw','weights':[1,0,0,0,0]};d['new_reconstruction']=True;d['refit_shift']='train-only validation predictions; all five candidates refitted on train+valid before test predictions'
 if d['manual'] is not None:
  assert len(d['manual']['weights'])==len(d['columns'])
  for c in d['columns']:
   # Resolve run ordering before freezing; singleton copies have the same source.
   if all(len(g)==1 for g in c['runs']) and not c['singleton_reused'] and all(g[0]['seed_or_run'].isdigit() for g in c['runs']):
    c['runs'].sort(key=lambda g:int(g[0]['seed_or_run']))
  d['status']='READY_TO_PREPARE'
 plan['tasks'][t]=d
save('POOL_PLAN_v01.json',plan)
print('READY',sum(t['status']=='READY_TO_PREPARE' for t in plan['tasks'].values()),'of',len(plan['tasks']))
