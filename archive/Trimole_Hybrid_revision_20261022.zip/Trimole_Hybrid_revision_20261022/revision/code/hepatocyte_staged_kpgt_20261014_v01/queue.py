from pathlib import Path
import json,time,subprocess,os,traceback
R=Path(__file__).resolve().parent
B=Path('/mnt/data/projects/trimole_hepatocyte_kpgt_finetune_20261014_v02')
A=Path('/mnt/data/projects/trimole_hepatocyte_adapted_readout_20261014_v01')
def read(p):return json.loads(p.read_text())
def write(name,data):
 with (R/name).open('x') as f:json.dump(data,f,indent=2)
try:
 write('QUEUE_STARTED.json',{'unix':time.time()})
 while True:
  if (B/'REVIEW_ERROR.json').exists() or read(B/'STATUS.json')['status']=='FAILED' or read(A/'STATUS.json')['status']=='FAILED':raise RuntimeError('Earlier experiment needs repair; queue will not compete or silently resume')
  if (B/'REVIEW_COMPLETE.json').exists() and read(A/'STATUS.json')['status']=='COMPLETE_REVIEWED' and (B/'BLEND_RESULTS.json').exists():break
  time.sleep(15)
 previous=[read(B/'RESULTS.json')['mean'],read(B/'BLEND_RESULTS.json')['mean'],read(A/'RESULTS.json')['mean']]
 if max(previous)>.536:
  write('NOT_STARTED_TARGET_ALREADY_EXCEEDED.json',{'means':previous,'unix':time.time()})
 else:
  e=read(R/'ENVIRONMENT.json');env={**os.environ,**e['environment']}
  with (R/'smoke.log').open('x') as f:subprocess.run([e['python'],'-B',str(R/'run.py'),'smoke'],env=env,cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=1200)
  assert read(R/'SELFTEST.json')['status']=='PASS'
  with (R/'controller.log').open('x') as f:subprocess.run([e['python'],'-B',str(R/'run.py'),'controller'],env=env,cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
  with (R/'review_after.log').open('x') as f:subprocess.run([e['python'],'-B',str(R/'review_after.py')],env=env,cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
except Exception as e:
 write('QUEUE_ERROR.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
