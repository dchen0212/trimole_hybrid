import os
os.environ['CUDA_VISIBLE_DEVICES']='GPU-8dccd0a6-2c1e-0e9a-dda8-105662f17745'
os.environ['CUBLAS_WORKSPACE_CONFIG']=':4096:8'
os.environ['TOKENIZERS_PARALLELISM']='false'
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import sys,json,hashlib,time,random,subprocess,traceback,math
from pathlib import Path
import numpy as np
import torch
import dgl
from rdkit import Chem
from scipy.stats import spearmanr
R=Path(__file__).resolve().parent
P=Path('/mnt/data/projects/trimole_target_only_expanded_20261013_v02')
MODEL=Path('/mnt/data/projects/trimole_hybrid_revision_20260915/_dependencies/KPGT')
sys.path.insert(0,str(MODEL))
from src.data.featurizer import smiles_to_graph_tune,Vocab,N_ATOM_TYPES,N_BOND_TYPES
from src.data.descriptors.rdNormalizedDescriptors import RDKit2DNormalized
from src.data.collator import Collator_tune
from src.model.light import LiGhTPredictor
from src.model_config import config_dict
TASK='clearance_hepatocyte_az'
EPOCHS=[4,8,16]
SEEDS=[101,202,303,404,505]
MODE=sys.argv[1] if len(sys.argv)>1 else 'import'
def guard(event,args):
    if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        name=Path(os.fsdecode(args[0])).name
        if MODE in ['cv','final','smoke'] and name=='test.csv':raise PermissionError('No test labels in training worker')
        if MODE in ['cv','smoke'] and name=='evaluation.json':raise PermissionError('No evaluation structures in CV worker')
sys.addaudithook(guard)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(d,f,indent=2,allow_nan=False)
def atomic(p,d):
    q=p.with_suffix('.pending');q.write_text(json.dumps(d,indent=2));os.replace(q,p)
def metric(y,p):
    s=float(spearmanr(y,p).statistic);assert np.isfinite(s);return s
def catalog():
    values=[('top2',1e-6,0.),('top2',1e-5,0.),('all',1e-6,0.),('all',1e-5,0.),('all',1e-5,.001),('all',1e-5,.01)]
    return [dict(id=f's{i}',scope=scope,lr=lr,loss='log',l2sp=l2sp) for i,(scope,lr,l2sp) in enumerate(values)]
def verify():
    for p,h in read(R/'FREEZE.json')['files'].items():assert sha(R/p)==h,p
    for p,h in read(R/'INPUT_BINDING.json')['model_files'].items():assert sha(MODEL/p)==h,p
def prepare():
    import shutil
    old=Path('/mnt/data/projects/trimole_hepatocyte_encoder_finetune_20261014_v01')
    for name in ['development.json','evaluation.json','FOLDS.json']:shutil.copy2(old/name,R/name)
    source=read(old/'INPUT_BINDING.json')['source']
    weights={'models/base.pth':sha(MODEL/'models/base.pth')}
    assert weights['models/base.pth']=='8811c117cfedddff5ef2a512290d1a7a73d3d9560773860bc3b06942c597d15d'
    weights.update({str(p.relative_to(MODEL)):sha(p) for p in sorted((MODEL/'src').rglob('*.py'))})
    write(R/'INPUT_BINDING.json',{'source':source,'model_files':weights,'development_sha256':sha(R/'development.json'),
        'evaluation_sha256':sha(R/'evaluation.json'),'folds_sha256':sha(R/'FOLDS.json')})
    write(R/'CATALOG.json',catalog())
def cache_inputs(part):
    rows=read(R/('development.json' if part=='development' else 'evaluation.json'))['rows']
    gen=RDKit2DNormalized(); graphs=[];fps=[];mds=[];audit=[]
    for i,row in enumerate(rows):
        mol=Chem.MolFromSmiles(row['raw_smiles']);assert mol is not None
        smi=Chem.MolToSmiles(mol,isomericSmiles=True)
        g=smiles_to_graph_tune(smi,max_length=5,n_virtual_nodes=2);assert g is not None
        fp=np.asarray(Chem.RDKFingerprint(mol,minPath=1,maxPath=7,fpSize=512),dtype=np.float32)
        desc=gen.process(smi);assert desc is not None and desc[0]
        md=np.asarray(desc[1:],dtype=np.float32);assert md.shape==(200,)
        mask=np.isnan(md);md=np.where(mask,np.float32(0),md);assert np.isfinite(md).all()
        graphs.append(g);fps.append(fp);mds.append(md)
        audit.append({'row_id':row['row_id'],'smiles':smi,'nan_indices':np.flatnonzero(mask).tolist()})
        if (i+1)%100==0:print('cache',part,i+1,flush=True)
    dgl.save_graphs(str(R/f'{part}_graphs.bin'),graphs)
    np.savez_compressed(R/f'{part}_inputs.npz',fps=np.array(fps),mds=np.array(mds),row_ids=np.array([r['row_id'] for r in rows]))
    write(R/f'{part}_cache.json',{'graphs_sha256':sha(R/f'{part}_graphs.bin'),'inputs_sha256':sha(R/f'{part}_inputs.npz'),
        'source_json_sha256':sha(R/f'{part}.json'),'rows':audit,'policy':'upstream normalized float32 NaN to zero; infinity rejected; no labels'})
_CACHE={}
def encode_inputs(tokenizer,rows):
    prefix='development' if rows[0]['region']=='development' else 'evaluation'
    if prefix not in _CACHE:
        receipt=read(R/f'{prefix}_cache.json')
        assert sha(R/f'{prefix}_graphs.bin')==receipt['graphs_sha256']
        assert sha(R/f'{prefix}_inputs.npz')==receipt['inputs_sha256']
        graphs,_=dgl.load_graphs(str(R/f'{prefix}_graphs.bin'))
        z=np.load(R/f'{prefix}_inputs.npz',allow_pickle=False)
        _CACHE[prefix]={str(rid):(receipt['rows'][i]['smiles'],graphs[i],torch.from_numpy(z['fps'][i]),torch.from_numpy(z['mds'][i]),torch.zeros(1)) for i,rid in enumerate(z['row_ids'])}
    return [_CACHE[prefix][r['row_id']] for r in rows],[]

def seed_all(seed):
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
    torch.set_num_threads(2);torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True
    torch.use_deterministic_algorithms(False) # DGL GPU sparse reductions; seeded but not bitwise deterministic
class FitNormalizer(torch.nn.Module):
    def __init__(self):
        super().__init__();self.register_buffer('mean',torch.zeros(2304));self.register_buffer('scale',torch.ones(2304))
    def forward(self,x):return (x-self.mean)/self.scale

def make_model(c):
    config=config_dict['base'];keys=('d_node_feats','d_edge_feats','d_g_feats','d_hpath_ratio','n_mol_layers','path_length','n_heads','n_ffn_dense_layers')
    encoder=LiGhTPredictor(**{k:config[k] for k in keys},input_drop=0.,attn_drop=0.,feat_drop=0.,n_node_types=Vocab(N_ATOM_TYPES,N_BOND_TYPES).vocab_size)
    state=torch.load(MODEL/'models/base.pth',map_location='cpu',weights_only=True)
    encoder.load_state_dict({k.removeprefix('module.'):v for k,v in state.items()},strict=True)
    del encoder.md_predictor;del encoder.fp_predictor;del encoder.node_predictor
    for n,p in encoder.named_parameters():
        p.requires_grad_(n!='mask_emb.weight' and (c['scope']=='all' or n.startswith(('model.mol_T_layers.10.','model.mol_T_layers.11.'))))
    head=torch.nn.Sequential(FitNormalizer(),torch.nn.Linear(2304,128),torch.nn.GELU(),torch.nn.Dropout(.1),torch.nn.Linear(128,1))
    return encoder.cuda(),head.cuda(),{'strict_load':True,'checkpoint_sha256':sha(MODEL/'models/base.pth')}
def batch(seqs,indices):
    _,g,fp,md,_=Collator_tune(5)([seqs[i] for i in indices])
    return g.to('cuda'),(fp.cuda(),md.cuda())
def forward(encoder,head,g,inputs):
    return head(encoder.generate_fps(g,*inputs)).flatten()
def predict(encoder,head,seqs):
    encoder.eval();head.eval();out=[]
    with torch.inference_mode():
        for start in range(0,len(seqs),8):
            ids,mask=batch(seqs,list(range(start,min(start+8,len(seqs)))))
            out.extend(forward(encoder,head,ids,mask).float().cpu().tolist())
    out=np.asarray(out);assert np.isfinite(out).all();return out

def train(c,seed,fit_rows,y,score_rows,max_epochs,output,checkpoint_epochs):
    seed_all(seed);encoder,head,loading=make_model(c)
    tokenizer=None
    a,ta=encode_inputs(tokenizer,fit_rows);b,tb=encode_inputs(tokenizer,score_rows)
    yy=np.log1p(y);mu=float(yy.mean());sd=float(yy.std()) or 1.;yy=(yy-mu)/sd
    target=torch.as_tensor(yy,dtype=torch.float32,device='cuda')
    names=[n for n,p in encoder.named_parameters() if p.requires_grad]
    probe=next(n for n in names if n.endswith('weight') and '.mol_T_layers.' in n)
    initial=dict(encoder.named_parameters())[probe].detach().cpu().clone()
    frozen_probe=next(n for n,p in encoder.named_parameters() if n.startswith('node_emb.') and n.endswith('weight'));frozen_initial=dict(encoder.named_parameters())[frozen_probe].detach().cpu().clone()
    opt=torch.optim.AdamW([{'params':[p for p in encoder.parameters() if p.requires_grad],'lr':c['lr']},
                          {'params':head.parameters(),'lr':1e-4}],weight_decay=.01)
    horizon=16*math.ceil(len(a)/8);warmup=max(1,int(.1*horizon))
    def schedule(step):return (step+1)/warmup if step<warmup else max(0.,(horizon-step)/(horizon-warmup))
    scheduler=torch.optim.lr_scheduler.LambdaLR(opt,schedule)
    records=[];updates=0;start=time.time();rng=np.random.RandomState(seed)
    output.mkdir(parents=True,exist_ok=False)
    write(output/'START.json',{'config':c,'seed':seed,'fit_row_ids':[x['row_id'] for x in fit_rows],
        'score_row_ids':[x['row_id'] for x in score_rows],'loading':loading,'encoder_trainable_parameters':sum(p.numel() for p in encoder.parameters() if p.requires_grad),
        'encoder_trainable_names':names,'probe':probe,'truncated_fit_rows':ta,'truncated_score_rows':tb,
        'target_log_mean':mu,'target_log_sd':sd,'initial_checkpoint_sha256':sha(MODEL/'models/base.pth'),
        'cross_task_supervised_rows':0,'test_labels_used':False})
    # Fixed head warmup on the exact fold-fit rows, using bound initial K representations.
    frozen_root=P/TASK;fb=read(frozen_root/'FOLDS.json')
    assert sha(frozen_root/'development_features.npz')==fb['development_features_sha256']
    assert sha(frozen_root/'ROWS.json')==fb['row_binding_sha256']
    ids=[r['row_id'] for r in read(frozen_root/'ROWS.json') if r['region']=='development'];lookup={rid:i for i,rid in enumerate(ids)}
    with np.load(frozen_root/'development_features.npz') as z:xx=z['K'][[lookup[r['row_id']] for r in fit_rows]].astype(np.float64)
    x=torch.as_tensor(xx,dtype=torch.float32,device='cuda');encoder.eval()
    with torch.inference_mode():
        g,inp=batch(a,list(range(min(8,len(a)))));fresh=encoder.generate_fps(g,*inp)
        parity=float((fresh-x[:len(fresh)]).abs().max());assert torch.allclose(fresh,x[:len(fresh)],atol=1e-4,rtol=1e-4),parity
    mean=xx.mean(0);scale=xx.std(0);scale[scale<1e-6]=1.
    head[0].mean.copy_(torch.as_tensor(mean,dtype=torch.float32,device='cuda'));head[0].scale.copy_(torch.as_tensor(scale,dtype=torch.float32,device='cuda'))
    warmopt=torch.optim.AdamW(head.parameters(),lr=.001,weight_decay=.01);warm_records=[]
    for warm_epoch in range(40):
        head.train();order=rng.permutation(len(x));total=0.
        for pos in range(0,len(x),64):
            ix=order[pos:pos+64].tolist();warmopt.zero_grad(set_to_none=True)
            pred=head(x[ix]).flatten();loss=torch.nn.functional.smooth_l1_loss(pred,target[ix]);assert torch.isfinite(loss)
            loss.backward();torch.nn.utils.clip_grad_norm_(head.parameters(),1.,error_if_nonfinite=True);warmopt.step();total+=float(loss.detach().cpu())*len(ix)
        warm_records.append({'epoch':warm_epoch+1,'loss':total/len(x)})
    write(output/'WARMUP.json',{'epochs':warm_records,'feature_source_sha256':fb['development_features_sha256'],'initial_encoder_feature_parity_max_abs_diff':parity,'rows':len(x),'encoder_updates_during_warmup':0,'normalization_fit_rows_only':True})
    origin={n:p.detach().clone() for n,p in encoder.named_parameters() if p.requires_grad} if c['l2sp'] else {}
    for epoch in range(1,max_epochs+1):
        encoder.train();head.train();order=rng.permutation(len(a));loss_sum=0.
        for start_ix in range(0,len(a),8):
            ix=order[start_ix:start_ix+8].tolist();ids,mask=batch(a,ix);opt.zero_grad(set_to_none=True)
            pred=forward(encoder,head,ids,mask);loss=torch.nn.functional.smooth_l1_loss(pred,target[ix])
            if c['loss']=='pair':
                delta=target[ix][:,None]-target[ix][None,:];valid=torch.triu(torch.ones_like(delta,dtype=torch.bool),diagonal=1)&(delta!=0)
                rankloss=torch.nn.functional.softplus(-(pred[:,None]-pred[None,:])*delta.sign())[valid].mean() if valid.any() else pred.sum()*0
                loss=rankloss+.25*loss
            if c['l2sp']:
                penalty=sum((p-origin[n]).square().sum() for n,p in encoder.named_parameters() if p.requires_grad)
                loss=loss+c['l2sp']*penalty
            assert torch.isfinite(loss);loss.backward()
            torch.nn.utils.clip_grad_norm_(list(encoder.parameters())+list(head.parameters()),1.,error_if_nonfinite=True)
            opt.step();scheduler.step();updates+=1;loss_sum+=float(loss.detach().cpu())*len(ix)
        row={'epoch':epoch,'loss':loss_sum/len(a),'updates':updates,'seconds':time.time()-start}
        print(json.dumps(row),flush=True)
        if epoch in checkpoint_epochs:
            pred=predict(encoder,head,b);dest=output/f'epoch{epoch:02d}';dest.mkdir()
            np.savez_compressed(dest/'predictions.npz',prediction=pred)
            state={f'encoder.{k}':v.detach().cpu() for k,v in encoder.state_dict().items()}
            state.update({f'head.{k}':v.detach().cpu() for k,v in head.state_dict().items()})
            torch.save(state,dest/'checkpoint.pt')
            diff=float((state['encoder.'+probe]-initial).abs().max())
            frozen_diff=float((state['encoder.'+frozen_probe]-frozen_initial).abs().max())
            assert diff>0,'Encoder did not update'
            if c['scope']=='top2':assert frozen_diff==0,'Frozen embedding changed'
            write(dest/'SEAL.json',{'epoch':epoch,'config':c,'seed':seed,'fit_rows':len(a),'prediction_rows':len(b),
                'prediction_sha256':sha(dest/'predictions.npz'),'checkpoint_sha256':sha(dest/'checkpoint.pt'),
                'encoder_probe':probe,'encoder_probe_max_abs_change':diff,'embedding_max_abs_change':frozen_diff,
                'updates':updates,'input_binding_sha256':sha(R/'INPUT_BINDING.json'),'code_freeze_sha256':sha(R/'FREEZE.json')})
        records.append(row);atomic(output/'PROGRESS.json',{'epoch':epoch,'max_epochs':max_epochs,'seconds':time.time()-start})
    write(output/'COMPLETE.json',{'epochs':records,'status':'COMPLETE','seconds':time.time()-start})

def cv(cid,fold_id):
    verify();d=read(R/'development.json');assert sha(R/'development.json')==read(R/'INPUT_BINDING.json')['development_sha256']
    f=read(R/'FOLDS.json')['folds'][fold_id];a,b=f['fit'],f['validation'];assert not set(a)&set(b)
    c=next(x for x in catalog() if x['id']==cid)
    train(c,101,[d['rows'][i] for i in a],np.array(d['y'])[a],[d['rows'][i] for i in b],16,R/'cv'/cid/f'fold{fold_id}',EPOCHS)
def select():
    d=read(R/'development.json');y=np.array(d['y']);folds=read(R/'FOLDS.json')['folds'];rows=[]
    for c in catalog():
        for epoch in EPOCHS:
            oof=np.full(len(y),np.nan);scores=[];bindings=[]
            for fi,f in enumerate(folds):
                p=R/'cv'/c['id']/f'fold{fi}'/f'epoch{epoch:02d}';seal=read(p/'SEAL.json')
                assert sha(p/'predictions.npz')==seal['prediction_sha256']
                with np.load(p/'predictions.npz') as z:pred=z['prediction']
                ix=f['validation'];oof[ix]=pred;scores.append(metric(y[ix],pred));bindings.append(sha(p/'SEAL.json'))
            assert np.isfinite(oof).all()
            path=R/'selection_oof'/f"{c['id']}_epoch{epoch:02d}.npz";path.parent.mkdir(exist_ok=True)
            np.savez_compressed(path,prediction=oof)
            rows.append({'config':c,'epochs':epoch,'fold_scores':scores,'cv_score':float(np.mean(scores)),
                         'oof_sha256':sha(path),'fold_seal_sha256':bindings})
    selected=sorted(rows,key=lambda x:(-x['cv_score'],x['config']['id'],x['epochs']))[0]
    write(R/'SELECTION_FREEZE.json',{'selected':selected,'all_candidates':rows,'test_used_for_selection':False,'historical_test_exposure':True})
def final(seed):
    verify();d=read(R/'development.json');ev=read(R/'evaluation.json');binding=read(R/'INPUT_BINDING.json')
    assert sha(R/'development.json')==binding['development_sha256'] and sha(R/'evaluation.json')==binding['evaluation_sha256']
    assert ev['labels_present'] is False
    s=read(R/'SELECTION_FREEZE.json')['selected']
    train(s['config'],seed,d['rows'],np.array(d['y']),ev['rows'],s['epochs'],R/'final'/f'seed{seed}',[s['epochs']])
def evaluate():
    import pandas as pd
    s=read(R/'SELECTION_FREEZE.json')['selected'];paths=[R/'final'/f'seed{seed}'/f"epoch{s['epochs']:02d}" for seed in SEEDS]
    seals={str(p.relative_to(R)):sha(p/'SEAL.json') for p in paths};assert len(seals)==5
    write(R/'ALL_PREDICTIONS_FROZEN.json',seals)
    source=Path(read(R/'INPUT_BINDING.json')['source']['development_path']).with_name('test.csv')
    write(R/'TEST_ACCESS_STARTED.json',{'unix':time.time(),'selection_sha256':sha(R/'SELECTION_FREEZE.json'),'all_seals_sha256':sha(R/'ALL_PREDICTIONS_FROZEN.json')})
    assert sha(source)=='23e061c3fdc2627707c099be6a3082a55fd928a1f19e555f6f4f4b734ed8d314'
    data=pd.read_csv(source);rows=read(R/'evaluation.json')['rows'];ix=[x['source_row'] for x in rows]
    assert sorted(ix)==list(range(len(data))) and [x['raw_smiles'] for x in rows]==data.iloc[ix].Drug.astype(str).tolist()
    results=[]
    for seed,p in zip(SEEDS,paths):
        assert sha(p/'predictions.npz')==read(p/'SEAL.json')['prediction_sha256']
        with np.load(p/'predictions.npz') as z:pred=z['prediction']
        results.append({'seed':seed,'spearman':metric(data.iloc[ix].Y.to_numpy(),pred)})
    vals=[x['spearman'] for x in results]
    write(R/'RESULTS.json',{'task':TASK,'method':'target-only staged normalized KPGT fine-tuning with head warmup','rows':results,
        'mean':float(np.mean(vals)),'population_sd':float(np.std(vals)),'test_sha256':sha(source),'test_rows':len(rows),'benchmark_reuse':True})
def worker(args,cap):
    pth=R/'logs'/('_'.join(args)+'.log');pth.parent.mkdir(exist_ok=True)
    with pth.open('x') as h:
        p=subprocess.Popen([sys.executable,'-B',str(R/'run.py'),*args],stdout=h,stderr=subprocess.STDOUT,start_new_session=True)
        try:rc=p.wait(timeout=cap)
        except subprocess.TimeoutExpired:
            import signal
            os.killpg(p.pid,signal.SIGKILL);p.wait();rc=-9
    assert rc==0,(args,rc,str(pth))
def controller():
    status={'status':'CV_RUNNING','started_unix':time.time(),'completed':[]};atomic(R/'STATUS.json',status)
    try:
        for c in catalog():
            for fi in range(3):
                args=['cv',c['id'],str(fi)];worker(args,7200);status['completed'].append(args);atomic(R/'STATUS.json',status)
        select();status['status']='FINAL_REFIT';atomic(R/'STATUS.json',status)
        for seed in SEEDS:
            args=['final',str(seed)];worker(args,7200);status['completed'].append(args);atomic(R/'STATUS.json',status)
        evaluate();status['status']='FINISHED_REQUIRES_REVIEW'
    except Exception as e:status.update(status='FAILED',error=repr(e),traceback=traceback.format_exc())
    status['ended_unix']=time.time();atomic(R/'STATUS.json',status)
def smoke():
    verify();d=read(R/'development.json');rows=d['rows'][:48];y=np.array(d['y'][:48]);c=catalog()[0]
    train(c,7,rows[:32],y[:32],rows[32:],1,R/'smoke',[1])
    write(R/'SELFTEST.json',{'status':'PASS','checks':['official model load','real encoder gradient update','frozen embedding unchanged','one epoch fit and predict','checkpoint and prediction seals']})
if __name__=='__main__':
    if MODE=='prepare':prepare()
    elif MODE=='cache':cache_inputs(sys.argv[2])
    elif MODE=='smoke':smoke()
    elif MODE=='cv':cv(sys.argv[2],int(sys.argv[3]))
    elif MODE=='final':final(int(sys.argv[2]))
    elif MODE=='controller':controller()
