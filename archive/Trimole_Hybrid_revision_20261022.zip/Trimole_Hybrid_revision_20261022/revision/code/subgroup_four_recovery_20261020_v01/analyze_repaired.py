"""Paired scaffold bootstrap of saved predictions; no model inference or fitting."""
import os
for k in ["OMP_NUM_THREADS","OPENBLAS_NUM_THREADS","MKL_NUM_THREADS"]:
    os.environ[k]="1"
from pathlib import Path
import json,hashlib,warnings
import numpy as np,pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score,average_precision_score,mean_absolute_error
R=Path(__file__).resolve().parent
B=2000;METHODS=["trimole","minimol","chemprop"]
BINS=[("MW",300,"<"),("MW",300,">="),("cLogP",3,"<"),("cLogP",3,">="),("TPSA",75,"<"),("TPSA",75,">=")]
def plain(metric,y,p):
    if metric in ["AUROC","AUPRC"] and len(np.unique(y))<2:return np.nan
    if metric=="Spearman":
        if len(np.unique(y))<2 or len(np.unique(p))<2:return np.nan
        return float(spearmanr(y,p).statistic)
    return float({"AUROC":roc_auc_score,"AUPRC":average_precision_score,"MAE":mean_absolute_error}[metric](y,p))
def grouped(x,w):
    order=np.argsort(x,kind="stable")
    sx=x[order];starts=np.r_[0,np.flatnonzero(np.diff(sx)!=0)+1]
    counts=np.add.reduceat(w[:,order],starts,axis=1)
    groups=np.cumsum(np.r_[0,np.diff(sx)!=0])
    inverse=np.empty(len(x),int);inverse[order]=groups
    return counts,inverse,order,starts
def ranks(x,w):
    counts,inverse,_,_=grouped(x,w)
    return (np.cumsum(counts,axis=1)-.5*counts+.5)[:,inverse]
def weighted(metric,y,p,w):
    total=w.sum(axis=1)
    with np.errstate(divide="ignore",invalid="ignore"):
        if metric=="MAE":return (w*np.abs(y-p)).sum(axis=1)/total
        if metric=="Spearman":
            ry=ranks(y,w);rp=ranks(p,w)
            cy=ry-(ry*w).sum(axis=1)[:,None]/total[:,None]
            cp=rp-(rp*w).sum(axis=1)[:,None]/total[:,None]
            return (w*cy*cp).sum(axis=1)/np.sqrt((w*cy**2).sum(axis=1)*(w*cp**2).sum(axis=1))
        counts,_,order,starts=grouped(p,w)
        pos=np.add.reduceat((w*y)[:,order],starts,axis=1)
        npos=pos.sum(axis=1);nneg=total-npos
        if metric=="AUROC":
            neg=counts-pos;below=np.cumsum(neg,axis=1)-neg
            out=(pos*(below+.5*neg)).sum(axis=1)/(npos*nneg)
        else:
            pos=pos[:,::-1];counts=counts[:,::-1]
            pp=np.cumsum(pos,axis=1);nn=np.cumsum(counts,axis=1)
            out=np.nansum(pos*np.divide(pp,nn,out=np.zeros_like(pp),where=nn>0),axis=1)/npos
        out[(npos==0)|(nneg==0)]=np.nan
        return out
def verify():
    rng=np.random.default_rng(42)
    for met in ["AUROC","AUPRC","Spearman","MAE"]:
        y=np.array([0,1,0,1,1,0,1,0.]) if met in ["AUROC","AUPRC"] else np.array([0,0,1,1,2,4,4,6.])
        p=np.array([.2,.7,.5,.7,.2,.1,.9,.5])
        w=rng.multinomial(len(y),np.ones(len(y))/len(y),size=30).astype(float)
        fast=weighted(met,y,p,w)
        for i in range(len(w)):
            idx=np.repeat(np.arange(len(y)),w[i].astype(int))
            ref=plain(met,y[idx],p[idx])
            assert np.isclose(fast[i],ref,atol=1e-12,equal_nan=True),(met,fast[i],ref)
    return "120 weighted bootstrap metric checks matched sklearn/scipy using explicitly repeated rows"
check=verify()
coverage=json.loads((R/"COVERAGE_v02.json").read_text())
results=[];counts=[];runpoints=[];overall=[]
for ti,info in enumerate(coverage):
    if info["task"] not in ["bbb_martins","vdss_lombardo","cyp2d6_veith","solubility_aqsoldb"]: continue
    task=info["task"];metric=info["metric"]
    f=pd.read_csv(R/"data_v02"/f"{task}_rows.csv",keep_default_na=False)
    z=np.load(R/"data_v02"/f"{task}_predictions.npz")
    for bi,(prop,cut,op) in enumerate(BINS):
        propv=pd.to_numeric(f[prop],errors="coerce").to_numpy(float)
        idx=np.flatnonzero(np.isfinite(propv)&((propv<cut) if op=="<" else (propv>=cut)))
        y=f.target.to_numpy(float)[idx]
        groups=f.cluster.to_numpy()[idx];_,inverse=np.unique(groups,return_inverse=True)
        n=len(idx);nc=len(np.unique(groups))
        classifier=metric in ["AUROC","AUPRC"]
        pos=int((y==1).sum()) if classifier else None
        neg=int((y==0).sum()) if classifier else None
        code=f"{prop}{op}{cut}"
        count={"task":task,"metric":metric,"bin":code,"n":n,"clusters":nc,
               "positive":pos,"negative":neg,"prevalence":pos/n if classifier and n else None,
               "unassigned_structure_rows":int((~np.isfinite(propv)).sum()),
               "main_table_prediction_eligible":info["comparison_eligible"]}
        counts.append(count)
        predictions={k:z[k][:,idx] for k in z.files}
        points={}
        for k,a in predictions.items():
            vals=[plain(metric,y,p) if n else np.nan for p in a]
            points[k]=float(np.mean(vals))
            for ri,v in enumerate(vals):runpoints.append({**count,"method":k,"run_position":ri+1,"score":v})
        if not info["comparison_eligible"]:
            for comparator in ["minimol","chemprop"]:
                results.append({**count,"comparator":comparator,"status":"source_unresolved",
                                "reason":info["trimole"].get("reason","source not eligible"),
                                "trimole_score":points.get("trimole"),"baseline_score":points.get(comparator)})
            print(task,code,"source unresolved",flush=True)
            continue
        reason=""
        if n<30:reason="fewer than 30 rows"
        elif nc<30:reason="fewer than 30 scaffold clusters"
        elif classifier and min(pos,neg)<5:reason="fewer than 5 rows in one class"
        elif not classifier and len(np.unique(y))<2:reason="constant targets"
        boots={k:np.full(B,np.nan) for k in METHODS}
        if not reason:
            rng=np.random.default_rng(20261020+ti*100+bi)
            for start in range(0,B,100):
                mult=rng.multinomial(nc,np.full(nc,1/nc),size=min(100,B-start))
                w=mult[:,inverse].astype(float)
                for k in METHODS:
                    run_scores=np.stack([weighted(metric,y,p,w) for p in predictions[k]])
                    boots[k][start:start+w.shape[0]]=np.mean(run_scores,axis=0)
        direction=-1 if metric=="MAE" else 1
        for comparator in ["minimol","chemprop"]:
            delta=direction*(points["trimole"]-points[comparator])
            diff=direction*(boots["trimole"]-boots[comparator])
            valid=np.isfinite(diff)
            local_reason=reason
            if not np.isfinite(delta):local_reason="undefined point metric"
            elif not reason and valid.sum()<1900:local_reason="fewer than 1900 valid bootstrap replicates"
            low,high=(float(v) for v in np.quantile(diff[valid],[.025,.975])) if not local_reason else (np.nan,np.nan)
            row={**count,"comparator":comparator,"trimole_score":points["trimole"],
                 "baseline_score":points[comparator],"delta_favors_trimole":delta,
                 "ci_low":low,"ci_high":high,"valid_bootstraps":int(valid.sum()),
                 "status":"interval" if not local_reason else "withheld","reason":local_reason}
            for method in ["trimole",comparator]:
                vv=boots[method][np.isfinite(boots[method])]
                lo,hi=np.quantile(vv,[.025,.975]) if not local_reason and len(vv)>=1900 else (np.nan,np.nan)
                row[method+"_ci_low"]=float(lo);row[method+"_ci_high"]=float(hi)
            results.append(row)
        print(task,code,"interval" if not reason else reason,flush=True)
# Preserve the 18 completed tasks; rerun only the four repaired tasks.
old=Path("/mnt/data/projects/trimole_subgroup_matched_20261020_v01")
changed={"bbb_martins","vdss_lombardo","cyp2d6_veith","solubility_aqsoldb"}
for filename,newrows in [("PAIRED_SUBGROUP_RESULTS.csv",results),("SUBGROUP_COUNTS.csv",counts),("PER_RUN_SUBGROUP_METRICS.csv",runpoints)]:
    previous=pd.read_csv(old/filename)
    untouched=previous[~previous.task.isin(changed)]
    merged=pd.concat([untouched,pd.DataFrame(newrows)],ignore_index=True)
    order={x["task"]:i for i,x in enumerate(coverage)}
    merged["_order"]=merged.task.map(order)
    merged=merged.sort_values("_order",kind="stable").drop(columns="_order")
    assert len(merged.task.unique())==22
    merged.to_csv(R/filename,index=False)
    pd.testing.assert_frame_equal(merged[~merged.task.isin(changed)].reset_index(drop=True),untouched.reset_index(drop=True),check_dtype=False)
res=pd.read_csv(R/"PAIRED_SUBGROUP_RESULTS.csv")
summary={"tasks_inventoried":22,"eligible_tasks":22,"recomputed_tasks":sorted(changed),
         "other_18_tasks_unchanged":True,"planned_comparisons":len(res),"statuses":res.status.value_counts().to_dict(),
         "bootstrap_replicates":B,"resampling_unit":"within-bin Murcko scaffold; canonical molecule for acyclic",
         "metric_verification":check,"point_statistic":"mean of five run metrics, except BBB: metric of five-run mean prediction for all three methods",
         "limitations":["Conditional on saved fitted predictions; no retraining/selection uncertainty",
                        "Intervals unadjusted for multiplicity; exploratory benchmark reuse",
                        "Historical source digest mismatches and positional/reconstruction provenance remain",
                        "BBB five individual archived vectors not recovered; ensemble scoring instead",
                        "Solubility 1995/1997 rows; two invalid structures unassigned with no imputed prediction"],
         "code_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(R/"ANALYSIS_RECEIPT.json").write_text(json.dumps(summary,indent=2))
print(json.dumps(summary),flush=True)
