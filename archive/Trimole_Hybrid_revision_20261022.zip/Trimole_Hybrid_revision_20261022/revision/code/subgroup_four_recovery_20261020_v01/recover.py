"""Recover declared source predictions; never select a source by its test score."""
from pathlib import Path
import hashlib,json,shutil
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import average_precision_score,roc_auc_score,mean_absolute_error

R=Path(__file__).resolve().parent
OLD=Path("/mnt/data/projects/trimole_subgroup_matched_20261020_v01")
S=Path("/mnt/data/projects/trimole_hybrid_revision_20260915")
D=S/"_dependencies/trimole_ept_swap_v1"
TASKS=["bbb_martins","vdss_lombardo","cyp2d6_veith","solubility_aqsoldb"]
hashes={}
def record(p):
    hashes[str(p)]=hashlib.sha256(p.read_bytes()).hexdigest()
    return p
def read(p,roundtrip=True):
    return pd.read_csv(record(p),float_precision="round_trip" if roundtrip else None)
def score(task,y,p):
    return float({"bbb_martins":roc_auc_score,"vdss_lombardo":lambda y,p:spearmanr(y,p).statistic,
                  "cyp2d6_veith":average_precision_score,"solubility_aqsoldb":mean_absolute_error}[task](y,p))
coverage=json.loads(record(OLD/"COVERAGE_v02.json").read_text())
(R/"data_v02").mkdir(exist_ok=True)
for p in (OLD/"data_v02").iterdir():
    if p.is_file():shutil.copy2(record(p),R/"data_v02"/p.name)
for n in ["INPUT_HASHES_v02.json","PROTOCOL.md"]:
    shutil.copy2(record(OLD/n),R/n)
audit=[]
for task in TASKS:
    info=next(x for x in coverage if x["task"]==task)
    f=read(OLD/"data_v02"/f"{task}_rows.csv")
    y=f.target.to_numpy(float)
    official=read(S/"data/admet_group"/task/"test.csv")
    assert len(f)==len(official)
    assert (f.smiles.to_numpy()==official.Drug.to_numpy()).all()
    assert np.allclose(y,official.Y,rtol=0,atol=1e-12)
    z=np.load(OLD/"data_v02"/f"{task}_predictions.npz")
    arrays={k:z[k] for k in z.files}
    note={"task":task,"previous_status":info["trimole"],"official_rows":len(f)}
    if task in ["vdss_lombardo","cyp2d6_veith"]:
        if task=="vdss_lombardo":
            paths=[S/f"results_strict/case_study_v36_exact_full/full_predictions/{task}/test_predictions_run_seed_index_{s}.csv" for s in range(1,6)]
        else:
            paths=[S/f"results_strict/revision_20260917_v29_formula_predictions_v3/predictions/{task}/test_predictions_seed_group_{s}.csv" for s in range(1,6)]
        ps=[];default=[]
        for p in paths:
            a=read(p);b=read(p,False)
            assert np.array_equal(a.sample_idx,np.arange(len(f)))
            assert np.allclose(a.y_true,y,rtol=0,atol=1e-12)
            col=next(k for k in ["y_pred","y_prob","prediction"] if k in a)
            ps.append(a[col].to_numpy(float));default.append(score(task,y,b[col]))
        arrays["trimole"]=np.stack(ps)
        values=[score(task,y,p) for p in ps]
        assert abs(np.mean(values)-info["trimole"]["expected_mean"])<1e-6
        note.update(recovery="Original CSV parsed with round_trip; original floating-point ties preserved",
                    source_paths=[str(p) for p in paths],scores_default_parser=default,scores_round_trip=values,
                    mean_round_trip=float(np.mean(values)),statistic="mean_of_five_run_metrics")
    elif task=="solubility_aqsoldb":
        source=read(D/"data/data_benchmark_official_v1"/task/"test.csv")
        source["archive_row"]=np.arange(len(source));official["official_row"]=np.arange(len(official))
        keys=["Drug_ID","Drug"]
        assert not source.duplicated(keys).any() and not official.duplicated(keys).any()
        mapping=source.merge(official,on=keys,how="left",suffixes=("_archive","_official"),validate="one_to_one")
        assert mapping.official_row.notna().all()
        assert np.allclose(mapping.Y_archive,mapping.Y_official,rtol=0,atol=1e-12)
        idx=mapping.official_row.to_numpy(int)
        missing=official[~official.official_row.isin(idx)]
        assert missing.official_row.tolist()==[1159,1160]
        assert not f.iloc[missing.official_row].structure_valid.any()
        mapping.to_csv(R/"SOLUBILITY_ROW_MAP.csv",index=False)
        missing.to_csv(R/"SOLUBILITY_UNASSIGNED_ROWS.csv",index=False)
        ps=[];paths=[]
        for seed in range(1,6):
            sources=[
                (D/f"results_strict/formal_repeated_fp_xgb_5run_audit_v1/{task}/formal_seed_{seed}/test_predictions.csv",.3),
                (D/f"results_strict/official_metric_loss_push_all22_v1/{task}__metric_auto__seed_42/test_predictions.csv",.3),
                (D/f"results_strict/paper_main_chemical_prior_xl_v4_remaining4_32core/{task}/test_predictions.csv",.4)]
            prediction=np.zeros(len(source))
            for p,weight in sources:
                a=read(p);paths.append(str(p))
                assert np.array_equal(a.sample_idx,np.arange(len(source)))
                expected_y=source.Y.to_numpy()
                if "official_metric_loss_push_all22_v1" in str(p):
                    expected_y=expected_y.astype(np.float32).astype(float)
                assert np.allclose(a.y_true,expected_y,rtol=0,atol=1e-12)
                col=next(k for k in ["y_pred","y_prob","prediction"] if k in a)
                prediction+=weight*a[col].to_numpy(float)
            archive=read(S/f"manuscript_revision/trimole_prediction_manifest_20260917/predictions/{task}/seed_{seed}.csv")
            assert np.allclose(prediction,archive.prediction,rtol=0,atol=1e-12)
            pred=np.full(len(f),np.nan)
            pred[idx]=prediction;ps.append(pred)
        arrays["trimole"]=np.stack(ps)
        values=[score(task,y[idx],p[idx]) for p in ps]
        assert abs(np.mean(values)-info["trimole"]["expected_mean"])<1e-6
        note.update(recovery="Identity mapping of archived 1995 rows to official 1997 rows by Drug_ID and raw SMILES, labels verified after mapping",
                    source_paths=paths,matched_rows=len(idx),unassigned_rows=missing.official_row.tolist(),
                    missing_prediction_fill="NaN; never target labels",
                    label_check="Metric-auto source stores exact float32-cast labels; other sources equal full-precision labels; all scoring uses official labels",
                    scores_round_trip=values,
                    mean_round_trip=float(np.mean(values)),statistic="mean_of_five_run_metrics")
    else:
        p=D/"results_strict/pure_chem_multibackend_endpoint_v1/bbb_martins/test_ensemble_predictions.csv"
        a=read(p)
        legacy=read(D/"data/data_benchmark_official_v1"/task/"test.csv")
        assert len(a)==len(f)==len(legacy)
        assert (legacy.Drug.to_numpy()==official.Drug.to_numpy()).all()
        assert np.array_equal(a.sample_idx,np.arange(len(f)))
        assert np.allclose(a.y_true,y,rtol=0,atol=1e-12)
        result=json.loads(record(p.parent/"result.json").read_text())
        # BBB's archived ensemble is real; five separate vectors were not saved.
        # Score ensemble predictions for all three methods, without duplicating runs.
        arrays={k:v.mean(axis=0,keepdims=True) for k,v in arrays.items()}
        arrays["trimole"]=a.y_prob.to_numpy(float)[None,:]
        value=score(task,y,arrays["trimole"][0])
        assert abs(value-result["test_ensemble"])<1e-12
        note.update(recovery="Archived five-run prediction ensemble; all three BBB methods use prediction-ensemble scoring",
                    source_paths=[str(p)],statistic="metric_of_five_run_mean_prediction",
                    ensemble_score=value,main_table_mean=result["test_mean_refit"],
                    main_table_sd=result["test_std_refit"],
                    main_table_five_separate_vectors_recovered=False,
                    rejected_reconstruction=json.loads(record(S/"results_strict/bbb_v36_saved_models/model_save_summary.json").read_text()))
    for k,v in arrays.items():
        assert np.isfinite(v[:,f.structure_valid.to_numpy(bool)]).all(),(task,k)
    np.savez_compressed(R/"data_v02"/f"{task}_predictions.npz",**arrays)
    info["comparison_eligible"]=True
    info["subgroup_statistic"]=note["statistic"]
    info["trimole"]={**info["trimole"],"status":"RECOVERED_FOR_SUBGROUP_COMPARISON",
                     "recovery":note["recovery"],"source_paths":note["source_paths"],
                     "runs":1 if task=="bbb_martins" else 5,
                     "main_table_five_run_eligible":task!="bbb_martins"}
    info["trimole"].pop("reason",None)
    st=info["trimole"]
    st["underlying_runs"]=5
    st["stored_prediction_vectors"]=1 if task=="bbb_martins" else 5
    st["recomputed_mean"]=note["ensemble_score"] if task=="bbb_martins" else note["mean_round_trip"]
    st["per_run_scores"]=[] if task=="bbb_martins" else note["scores_round_trip"]
    st["statistic"]="metric_of_five_run_mean_prediction; not mean of five metrics" if task=="bbb_martins" else "mean_of_five_run_metrics"
    if task=="bbb_martins":st["unique_prediction_vectors"]=1
    st["comparison_scope"]="property-assigned rows; solubility excludes two unparseable rows" if task=="solubility_aqsoldb" else "all official rows"
    audit.append(note)
    print(task,note["recovery"],flush=True)
(R/"COVERAGE_v02.json").write_text(json.dumps(coverage,indent=2))
with (R/"PROTOCOL.md").open("a") as out:
    out.write("\n## Recovery amendment, 2026-10-20\n\nOnly four previously unresolved tasks are recomputed; the other 18 analysis rows are preserved. "
              "VDss and CYP2D6 inhibition use round-trip parsing of their declared original CSVs. "
              "Solubility uses identity-mapped archived predictions on 1995 valid structures; two invalid structures have no prediction assigned. "
              "BBB uses the archived five-run prediction ensemble. All three BBB models are scored after averaging predictions; "
              "this is not the main table's mean of five separate AUROCs. BBB's missing five individual archived vectors are not claimed recovered. "
              "Bootstrap uncertainty is conditional on the stored ensemble, with the same scaffold resampling as for the other tasks. "
              "These recovery choices are fixed before subgroup scoring and are not chosen by subgroup performance.\n")
(R/"RECOVERY_RECEIPT.json").write_text(json.dumps({"tasks":audit,"source_sha256":hashes,
    "coverage_metadata_updated":True,"recovery_code_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "training":False,"inference":False,"new_model_selection":False,"original_files_overwritten":False},indent=2))
assert all(hashlib.sha256(Path(p).read_bytes()).hexdigest()==h for p,h in hashes.items())
