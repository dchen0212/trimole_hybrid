# Matched subgroup comparison: fixed analysis specification

Scope: reuse saved predictions only. No fitting, model/seed selection, checkpoint changes or new inference. All 22 task rows are inventoried; missing or incompatible predictions remain visible.

Comparators: current Trimole-Hybrid table (20 historical + two October target-only endpoints), October MiniMol and Chemprop. Use the recorded HIA Chemprop correction and validation-selected half-life log-MSE arm, as in Figure 2c. Do not substitute the rebuilt common-pool fixed recipe for the main table.

Source checks precede subgroup scoring. Check saved seals where available, prediction lengths, row identifiers or archived sample indices, source labels/structures and whole-task scores. Whole-task score agreement is a consistency check, not proof of provenance. Historical positional/reconstruction limits must be reported. Require five saved runs and agreement with the main-table mean to its reported precision (absolute tolerance 1e-6) for a comparison labeled as the current main table. No source is chosen by nearest score. Record other recovered predictions separately, without silently replacing the main-table comparator.

Original property boundaries: MW <300 versus >=300; cLogP <3 versus >=3; TPSA <75 versus >=75. Compute RDKit molecular weight, MolLogP and TPSA from official test SMILES. Keep invalid structures as an explicit unassigned category; no label-based repair. Use all tasks, not just the historical top-1 subset.

Each point estimate is the mean of the five per-run metrics on the same subgroup rows; do not score the average prediction as if it were the main-table statistic. Paired deltas are Trimole minus comparator for AUROC, AUPRC and Spearman, and comparator minus Trimole for MAE. Positive always favors Trimole. Report subgroup N, positive/negative counts and prevalence, scaffold-cluster count, raw per-method metrics, and deltas.

Uncertainty: 2,000 paired bootstrap draws of within-subgroup Bemis–Murcko scaffold clusters, using the same sampled rows for every method and every saved run. Acyclic molecules use canonical isomeric identity as their cluster. Seed 20261020 plus deterministic task/bin offsets. Percentile 95% intervals conditional on saved fitted models; no independent-run assumption and no refitting. Withhold intervals below 30 rows or 30 clusters, below five rows in either class, constant regression targets, or fewer than 1,900 valid replicates. Report undefined metrics and reasons separately. Intervals are exploratory and unadjusted for multiplicity; no definitive superiority or robustness claim from interval direction.

The proposed Figure 2d will show matched within-subgroup comparisons, replacing subgroup-versus-overall ratios. Exact effects and intervals are retained in companion tables. Previously exposed benchmark labels and historical recipe selection are not made independent by this analysis.

## Recovery amendment, 2026-10-20

Only four previously unresolved tasks are recomputed; the other 18 analysis rows are preserved. VDss and CYP2D6 inhibition use round-trip parsing of their declared original CSVs. Solubility uses identity-mapped archived predictions on 1995 valid structures; two invalid structures have no prediction assigned. BBB uses the archived five-run prediction ensemble. All three BBB models are scored after averaging predictions; this is not the main table's mean of five separate AUROCs. BBB's missing five individual archived vectors are not claimed recovered. Bootstrap uncertainty is conditional on the stored ensemble, with the same scaffold resampling as for the other tasks. These recovery choices are fixed before subgroup scoring and are not chosen by subgroup performance.
