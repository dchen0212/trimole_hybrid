from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from lxml import etree as E
import hashlib,json,re,sys
P=Path('/Users/huangdachen/Documents/New project/BIOINF-2026-2212_revision');D=Path(__file__).resolve().parent
source=P/'deliverables/response_no_figure_notes_20261021_v27/Response_to_Reviewers_v27_figures_only.docx'
out=D/'Response_to_Reviewers_v28_HIA_refs.docx'
ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
with ZipFile(source) as z:parts={n:z.read(n) for n in z.namelist()}
root=E.fromstring(parts['word/document.xml']);body=root.find('w:body',ns)
changes=[]
def replace_text(el,old,new):
 nodes=el.xpath('.//w:t',namespaces=ns);text=''.join(n.text or '' for n in nodes);assert text.count(old)==1
 start=text.index(old);end=start+len(old);pos=0;inserted=False
 for n in nodes:
  s=n.text or '';a,b=pos,pos+len(s);pos=b
  if b<=start or a>=end:continue
  prefix=s[:max(0,start-a)];suffix=s[max(0,end-a):]
  n.text=prefix+(new if not inserted else '')+suffix;inserted=True
 assert ''.join(n.text or '' for n in nodes)==text.replace(old,new)
for idx,old,new in [(58,'Supplementary Table S4','Supplementary Table S37c'),(65,'Supplementary Figure S1b and Supplementary Table S4','Supplementary Table S37c')]:
 before=E.tostring(body[idx]);replace_text(body[idx],old,new);changes.append({'body_index':idx,'old':old,'new':new})
newxml=E.tostring(root,xml_declaration=True,encoding='UTF-8',standalone=True)
oldroot=E.fromstring(parts['word/document.xml']);oldbody=oldroot.find('w:body',ns)
assert len(body)==len(oldbody)
assert all(E.tostring(a)==E.tostring(b) for i,(a,b) in enumerate(zip(oldbody,body)) if i not in {58,65})
parts['word/document.xml']=newxml;parts['word/media/image3.png']=(D/'new_pdf_render.png').read_bytes()
with ZipFile(out,'w',ZIP_DEFLATED) as z:
 for n,data in parts.items():z.writestr(n,data)
with ZipFile(source) as a,ZipFile(out) as b:
 changed=[n for n in a.namelist() if a.read(n)!=b.read(n)]
assert changed==['word/document.xml','word/media/image3.png'] or set(changed)=={'word/document.xml','word/media/image3.png'}
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
qa={'source':str(source),'source_sha256':sha(source),'output_sha256':sha(out),'changed_zip_entries':changed,'reference_replacements':changes,'all_other_body_elements_byte_identical':True,'other_65_plot_rows_unchanged':True,'visible_image_difference_bbox':[625,272,683,421],'axis_limits_layout_and_colors_unchanged':True,'figure_footers_still_hidden':True,'training_evaluation_bootstrap_executed':False}
(D/'QA_RECEIPT.json').write_text(json.dumps(qa,ensure_ascii=False,indent=2))
# Confirm figure/table locations against the compiled supplement, including CSV-only legacy ledgers.
sys.path.insert(0,str(P/'tmp/vector_export_runtime_20261021'));import pymupdf as fitz
supp=P/'deliverables/supplement_complete_results_20261021_v02';doc=fitz.open(supp/'Supplementary_Information_complete_results_20261021.pdf')
refs={}
for kind,num in [('Table','S19'),('Table','S31'),('Table','S34'),('Table','S37c'),('Table','S38'),('Table','S20'),('Figure','S6'),('Figure','S7'),('Figure','S8'),('Figure','S9')]:
 pattern=re.compile(r'Supplementary\s+'+kind+r'\s+'+num+r'(?![\da-z])')
 pages=[i+1 for i,p in enumerate(doc) if pattern.search(p.get_text())]
 assert pages,(kind,num)
 refs[kind+' '+num]={'pdf_pages':pages,'status':'exists; checked content against cited analysis'}
for num,filename in [('S2','Table_S2_selected_configurations.csv'),('S13','Table_S13_reproducibility_manifest.csv')]:
 matches=list((supp/'supplement_source/supplement/supplementary_tables').glob(f'Table_{num}_*.csv'))
 assert matches;refs['Table '+num]={'files':[str(x) for x in matches],'status':'legacy ledger exists; current prose claims not rewritten'}
refs['Table S__ / Table [S__]']={'status':'unresolved: no matching whole-task paired-interval result; placeholders retained; S38 is subgroup-only'}
refs['Supplementary Equations 1 and 8: [to be inserted]']={'status':'existing insertion placeholder retained; outside figure/table numbering edits'}
(D/'REFERENCE_CHECK.json').write_text(json.dumps(refs,ensure_ascii=False,indent=2))
(D/'CHANGELOG_CN.md').write_text('''# v28 局部修改

- 以 v27 为底稿，旧版未覆盖。
- 仅更新图 R2 的 Chemprop HIA：0.910453 ± 0.127088 → 0.981811 ± 0.013394（五次运行的均值及总体标准差）。原坐标尺度、尺寸、配色及其他 65 项均值/标准差不变；原绘图代码重新导出，Word 中可见像素差异只在 HIA 柱与误差线区域。
- 两处相对变化表的 S4 引用改为 S37c。第二处同时去掉不对应相对变化的 S1b 引用；S1b 实际展示历史名次对比。
- 已核对 S19、S20、S31、S34、S37c、S38 和 S6–S9；旧 S2/S13 文件存在。附录 S7 和 S31 已使用最新 HIA，不需改动附录。
- 其余正文、审稿原文、R1、图表、格式及已隐藏的图下小字保持不变。
- 两处整任务配对区间表号仍无对应结果，未伪填。原有 Eq. 1/8 插入占位也没有改动；本次不是科学论断的全面修改。
''')
print(json.dumps({'output':str(out),'changed_parts':changed,'references':refs},ensure_ascii=False,indent=2))
