from pathlib import Path
import json,csv,ast,math,hashlib
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator
from PIL import Image
R=Path(__file__).resolve().parent;P=Path('/Users/huangdachen/Documents/New project/BIOINF-2026-2212_revision')
CP=R/'PLOT_DATA.csv';SP=P/'outputs/original_pool_matched_controls22_20261015_v01/completed_comparison_v03/BENCHMARK22_WIDE.csv'
source=list(csv.DictReader(CP.open(encoding='utf-8-sig')));same=list(csv.DictReader(SP.open()));tasks=list(dict.fromkeys(x['task'] for x in source));assert len(tasks)==22
ns=P/'outputs/minimol_figure22_20261014_v01/plot.py';names=ast.literal_eval(next(n.value for n in ast.parse(ns.read_text()).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='names' for t in n.targets)))
names['solubility_aqsoldb']='Solubility';names['half_life_obach']='Half-life*'
plt.rcParams.update({'font.family':'sans-serif','font.sans-serif':['Arial'],'font.size':8,'axes.linewidth':.7,'axes.spines.right':False,'axes.spines.top':False,'legend.frameon':False,'svg.fonttype':'none','pdf.fonttype':42})
colors=['#9CC8E2','#C9B7E8','#788AC5'];edges=['#6C8A9C','#8B7FA0','#4F5E92']
chem=[]
for task in tasks:
 pair=[next(x for x in source if x['task']==task and x['method']==m) for m in ['Trimole-Hybrid','MiniMol','Chemprop']]
 chem.append({'task':task,'metric':pair[0]['metric'],'v':[float(x['mean']) for x in pair],'e':[float(x['sd']) for x in pair]})
groups={m:[r for r in chem if r['metric']==m] for m in ['AUROC','AUPRC','Spearman','MAE']};assert [len(x) for x in groups.values()]==[8,5,4,5]
checks=[]
def limits(ax,vals,errs,key):
 lo=min(v-e for v,e in zip(vals,errs));hi=max(v+e for v,e in zip(vals,errs));pad=max((hi-lo)*.14,.002);bottom=max(0,lo-pad);top=hi+pad
 bottom,top={'AUROC': [0.5083659577003385, 1.1025265019382995], 'AUPRC': [0.29398205177244974, 0.9601939234665413], 'Spearman': [0.18242567035359267, 0.7250079352197343], 'caco2_wang': [0.2677889950496866, 0.3918393260239801], 'lipophilicity_astrazeneca': [0.4174810769390496, 0.48699734142853773], 'ppbr_az': [7.1217782623972825, 8.13008672047927], 'ld50_zhu': [0.5715811859136516, 0.6292610097812046], 'solubility_aqsoldb': [0.7222866950641545, 0.7869070048547444]}[key];ax.set_ylim(bottom,top);ax.yaxis.set_major_locator(MaxNLocator(4));ax.grid(axis='y',c='#E8E8EE',lw=.5);ax.set_axisbelow(True)
 if bottom>0:
  for d in [-.012,.012]:ax.plot([-.014,.014],[d-.01,d+.01],transform=ax.transAxes,c='#444444',lw=.65,clip_on=False)
 checks.append({'panel':key,'ylim':[bottom,top],'all_mean_sd_inside':bottom<=lo and hi<=top})
def save(fig,stem):
 for ext in ['pdf','svg','png']:fig.savefig(R/f'{stem}.{ext}',dpi=300)
 plt.close(fig);im=Image.open(R/f'{stem}.png');im.thumbnail((1300,1800));im.save(R/f'{stem}_preview.png')
fig=plt.figure(figsize=(180/25.4,236/25.4));gs=fig.add_gridspec(4,1,left=.10,right=.98,top=.915,bottom=.15,height_ratios=[1,1,1,.85],hspace=.85)
fig.legend(handles=[Patch(facecolor=c,edgecolor=e,label=l) for c,e,l in zip(colors,edges,['Trimole-Hybrid','MiniMol','Chemprop'])],loc='upper center',bbox_to_anchor=(.55,.98),ncol=3,fontsize=8.3)
for k,metric in enumerate(['AUROC','AUPRC','Spearman']):
 ax=fig.add_subplot(gs[k]);g=groups[metric];x=np.arange(len(g));w=.25
 for j in range(3):ax.bar(x+(j-1)*w,[r['v'][j] for r in g],width=w,yerr=[r['e'][j] for r in g],color=colors[j],edgecolor=edges[j],lw=.5,error_kw={'elinewidth':.8,'capsize':2,'capthick':.7,'ecolor':edges[j]},zorder=3)
 ax.set_xticks(x,[names[r['task']] for r in g],rotation=22,ha='right',rotation_mode='anchor',fontsize=7);ax.tick_params(axis='x',length=0);ax.tick_params(axis='y',labelsize=7);limits(ax,[v for r in g for v in r['v']],[e for r in g for e in r['e']],metric);ax.set_title(metric+' ↑',loc='left',fontsize=9,pad=10);ax.text(-.09,1.1,chr(97+k),transform=ax.transAxes,fontweight='bold',fontsize=11)
inner=gs[3].subgridspec(1,5,wspace=.6)
for j,r in enumerate(groups['MAE']):
 ax=fig.add_subplot(inner[j]);ax.bar([0,1,2],r['v'],width=.65,yerr=r['e'],color=colors,edgecolor=edges,lw=.5,error_kw={'elinewidth':.75,'capsize':2,'ecolor':'#51536B'},zorder=3);limits(ax,r['v'],r['e'],r['task']);ax.set_xticks([]);ax.tick_params(axis='y',labelsize=6.5);ax.set_title(names[r['task']],fontsize=7.2)
 if j==0:fig.text(.025,ax.get_position().y1+.03,'d',fontweight='bold',fontsize=11);fig.text(.10,ax.get_position().y1+.03,'MAE ↓',fontsize=9)
for y,t in zip([.098,.077,.056,.035],['Mean ± SD; five runs, all seeds retained. Y axes are zoomed and marked with breaks.','* Chemprop half-life uses the validation-selected log-target model, including seed 505.','† Trimole-Hybrid target-only retraining; other main-table entries are historical.','Baseline SD: population SD; main table: reported SD. Reused tests; budgets differ.']):fig.text(.07,y,t,fontsize=6.5,color='#46515D')
save(fig,'chemprop_minimol_trimole22_bars')

assert all(x['all_mean_sd_inside'] for x in checks)
with (R/'PLOT_DATA.csv').open('w',encoding='utf-8-sig',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(source[0]));w.writeheader();w.writerows(source)
(R/'QA.json').write_text(json.dumps({'tasks':22,'methods':3,'bars':66,'source_sha256':hashlib.sha256(CP.read_bytes()).hexdigest(),'all_SD_bars_retained':True,'axis_limits':checks,'half_life_all_five_seeds_included':True},indent=2))
(R/'CAPTION_EN.txt').write_text('Comparison of Trimole-Hybrid, MiniMol and Chemprop across22 ADMET tasks. Bars show means with standard deviations across five runs. Higher AUROC, AUPRC and Spearman are better; lower MAE is better. MAE panels use task-specific axes because endpoints have different units and scales. Non-zero axis origins are marked with breaks. Baseline SD is population SD; main-table SD is retained as reported. Chemprop half-life uses the log-target model selected by development validation, including all five seeds. Trimole-Hybrid contains20 historical results and two target-only retrained endpoints. These reused benchmark comparisons have different training/search budgets; no paired significance is implied.')
