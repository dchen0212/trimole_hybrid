import json,time,subprocess,sys,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
try:
 audit=json.loads((R/'FROZEN_COMPONENT_AUDIT.json').read_text());assert len(audit['tasks'])==21
 smoke=R/'kpgt_ft/bioavailability_ma/smoke_seed101/SMOKE_PASS.json'
 assert smoke.exists(),'Do not train before smoke passes'
 manifest={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in R.glob('*.py')};manifest['PROTOCOL.md']=hashlib.sha256((R/'PROTOCOL.md').read_bytes()).hexdigest()
 (R/'RUN_FREEZE.json').write_text(json.dumps({'code_sha256':manifest,'smoke':json.loads(smoke.read_text()),'created_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())},indent=2))
 (R/'CONTROLLER_STATUS.json').write_text(json.dumps({'stage':'TRAINING'}))
 with (R/'full_training.log').open('x') as f:subprocess.run([sys.executable,'-B',str(R/'run_finetune.py')],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
 with (R/'evaluation.log').open('x') as f:subprocess.run([sys.executable,'-B',str(R/'evaluate.py'),'kpgt_ft'],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
 (R/'CONTROLLER_STATUS.json').write_text(json.dumps({'stage':'FINISHED_WITH_TASK_DISPOSITIONS'}))
except Exception as e:
 (R/'CONTROLLER_STATUS.json').write_text(json.dumps({'stage':'FAILED','error':repr(e)}));raise
