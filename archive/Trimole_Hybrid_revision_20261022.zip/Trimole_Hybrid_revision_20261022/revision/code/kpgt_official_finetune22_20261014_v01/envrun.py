import os,json,subprocess,sys
from pathlib import Path
R=Path(__file__).resolve().parent
x=json.loads(Path('/mnt/data/projects/trimole_target_only_expanded_20261013_v02/ENVIRONMENT.json').read_text());env=os.environ.copy();env.update(x['environment'])
for k in ['CUDA_CACHE_PATH','DGLDOWNLOAD_DIR','MPLCONFIGDIR']:env[k]=str(R/'tmp'/k);Path(env[k]).mkdir(parents=True,exist_ok=True)
cmd=[x['python'],'-B',str(R/sys.argv[1]),*sys.argv[2:]]
if os.environ.get('DETACH')=='1':
 with (R/(sys.argv[1]+'.log')).open('x') as f:p=subprocess.Popen(cmd,env=env,stdout=f,stderr=subprocess.STDOUT,cwd=R,start_new_session=True,stdin=subprocess.DEVNULL)
 print(p.pid)
else:sys.exit(subprocess.run(cmd,env=env,cwd=R).returncode)
