# Official KPGT base fine-tuning protocol adapted to TDC 22 tasks

User authorized auditing the weak frozen-linear component and adding an official-method fine-tuned baseline. Keep frozen component outputs unchanged. MiniMol continues separately.

Official source: https://github.com/lihan97/KPGT, frozen checkout receipt. Pretrained base.pth SHA256 8811c117cfedddff5ef2a512290d1a7a73d3d9560773860bc3b06942c597d15d.

Full backbone and official 2-layer GELU predictor (hidden 256) updated. README base recipe LR 3e-5, weight decay/dropout 0; AdamW from transformers, official polynomial schedule and 10% warmup, gradient norm clipping 5; batch size32, 50 maximum epochs, validation metric patience20. Target labels normalized using training partition only for regression; SmoothL1 for Spearman, MSE for MAE, BCEWithLogits for classification. No FLAG/LLRD/L2SP/ReInit; no test-dependent tuning. Five seeds101/202/303/404/505, TDC default scaffold split within train_val at .875/.125. Best validation epoch saved; only then test predictions. No full-development refit (matches official fine-tuning recipe). Target-task supervision only.

Explicit necessary adaptations: TDC data and metrics instead of official MoleculeNet split files; keyed data adapter rejecting invalid rows; scipy renamed distribution gilbrat aliases gibrat; official trainer passes a fourth perturb argument but current forward_tune takes three, so adapter omits unused None; Spearman computed with scipy because upstream evaluator does not implement advertised spearman choice. Test evaluation removed from per-epoch loop. Graphs have no real test labels (constant collator placeholders). DataLoader workers0, GPU UUID binding; optimizer/model recipe preserved.

Before full queue: recompute 16 frozen embeddings/task using fresh official code; replay all saved frozen-head predictions; run one-epoch smoke check including real backbone parameter update and VRAM measurement. A failed numerical/row check is not bypassed. Preserve all blocked tasks. No claim of an exact previously published 22-task KPGT result or exhaustive hyperparameter optimization.

Report this arm separately from KPGT frozen+linear. Main table is historical20 + updated2, so score gaps are descriptive, not isolated causal gains. All tests already historically exposed.
