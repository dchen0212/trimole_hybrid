"""Official KPGT base fine-tuning recipe transferred to TDC; validation-only checkpoints."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='2'
import sys,json,csv,hashlib,time,traceback,ast,random,types,importlib.util
from pathlib import Path
import numpy as np,pandas as pd,torch,dgl
import scipy.stats as st
if not hasattr(st,'gilbrat'):st.gilbrat=st.gibrat
R=Path(__file__).resolve().parent;S=Path('/mnt/data/projects/trimole_hybrid_revision_20260915');SIDE=Path('/mnt/data/projects/trimole_dual3090_transfer_20261011_v01/staging/structures')
sys.path.insert(0,str(R/'official_source'))
from src.data.featurizer import Vocab,N_ATOM_TYPES,N_BOND_TYPES,smiles_to_graph_tune
from src.data.descriptors.rdNormalizedDescriptors import RDKit2DNormalized
from src.data.collator import Collator_tune
from src.model.light import LiGhTPredictor
from src.model_config import config_dict
from src.trainer.finetune_trainer import Trainer
from src.utils import set_random_seed
import transformers
from rdkit import Chem
from sklearn.metrics import roc_auc_score,average_precision_score,mean_absolute_error
from torch.utils.data import DataLoader

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(x,f,indent=2,allow_nan=False)
def guard(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)) and Path(os.fsdecode(args[0])).name=='test.csv':raise PermissionError('Test labels forbidden in fine-tuning')
sys.addaudithook(guard)
# Use official predictor factory and initialization, without invoking its dataset/test loader.
tree=ast.parse((R/'official_source/scripts/finetune.py').read_text());ns={'nn':torch.nn,'torch':torch}
exec(compile(ast.Module(body=[n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name in ['init_params','get_predictor']],type_ignores=[]),'official_factory','exec'),ns)
split_node=next(n for n in ast.parse((R/'tdc_split_reference.py').read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='create_scaffold_split');spns={'print_sys':print};exec(compile(ast.Module(body=[split_node],type_ignores=[]),'tdc_scaffold_split','exec'),spns)
CP=S/'_dependencies/KPGT/models/base.pth';c=config_dict['base'];SEEDS=[101,202,303,404,505]
assert sha(CP)=='8811c117cfedddff5ef2a512290d1a7a73d3d9560773860bc3b06942c597d15d'
class TrainOnly(Trainer):
 def _forward_epoch(self,model,batched_data,perturb=None):
  smiles,g,fp,md,y=batched_data
  # Official Trainer passes an unused perturb positional arg unsupported by current LiGhTPredictor.forward_tune.
  return model.forward_tune(g.to(self.device),fp.to(self.device),md.to(self.device)),y.to(self.device)

def prepare(task):
 d=R/'kpgt_ft'/task;d.mkdir(parents=True,exist_ok=True);df=pd.read_csv(S/'data/admet_group'/task/'train_val.csv');h=json.loads((SIDE/(task+'.json')).read_text());assert h['labels_present'] is False
 rows=[{'row_id':f'{task}:dev:{i}','canonical_isomeric_smiles':s} for i,s in enumerate(df.Drug)]+[{'row_id':f'{task}:test:{r["source_row"]}','canonical_isomeric_smiles':r['raw_smiles']} for r in h['rows']]
 if not (d/'ROWS.json').exists():write(d/'ROWS.json',rows)
 assert all(Chem.MolFromSmiles(r['canonical_isomeric_smiles']) is not None for r in rows),'INVALID_STRUCTURE_NO_DROP'
 cache=d/'graphs.bin';feat=d/'aux.npz'
 if cache.exists() and feat.exists():
  gs,_=dgl.load_graphs(str(cache));z=np.load(feat);fp=z['fp'];md=z['md'];assert z['row_ids'].tolist()==[r['row_id'] for r in rows]
 else:
  gs=[];fps=[];mds=[];gen=RDKit2DNormalized()
  for i,r in enumerate(rows):
   sm=r['canonical_isomeric_smiles'];g=smiles_to_graph_tune(sm,max_length=5,n_virtual_nodes=2);assert g is not None
   gs.append(g);fps.append(np.array(Chem.RDKFingerprint(Chem.MolFromSmiles(sm),minPath=1,maxPath=7,fpSize=512),dtype=np.float32));raw=gen.process(sm);assert raw[0]
   v=np.array(raw[1:],dtype=np.float32);v=np.where(np.isnan(v),0,v);assert v.shape==(200,) and np.isfinite(v).all();mds.append(v)
   if i%200==0:print(task,'PREPARE',i,len(rows),flush=True)
  fp=np.asarray(fps);md=np.asarray(mds);dgl.save_graphs(str(cache),gs);np.savez_compressed(feat,fp=fp,md=md,row_ids=np.array([r['row_id'] for r in rows]))
 assert len(gs)==len(rows)
 return d,df,rows,gs,torch.tensor(fp),torch.tensor(md)

def metric_value(metric,y,p):
 return float({'AUROC':roc_auc_score,'AUPRC':average_precision_score,'MAE':mean_absolute_error,'Spearman':lambda a,b:st.spearmanr(a,b).statistic}[metric](y,p))

def run_task(t,smoke=False):
 task=t['task'];metric=t['metric'];binary=metric in ['AUROC','AUPRC'];d,df,rows,gs,fp,md=prepare(task);n=len(df);df['_row']=np.arange(n);y=torch.tensor(df.Y.to_numpy(np.float32)).reshape(-1,1);records=[]
 for seed in SEEDS:
  o=d/(f'smoke_seed{seed}' if smoke else f'seed{seed}');o.mkdir(exist_ok=True)
  if (o/'FIT.json').exists():records.append(json.loads((o/'FIT.json').read_text()));continue
  set_random_seed(seed,2);torch.set_num_threads(2)
  split=spns['create_scaffold_split'](df,seed=seed,frac=[.875,.125,0.],entity='Drug');tr=split['train']['_row'].to_numpy();va=split['valid']['_row'].to_numpy()
  assert len(tr)+len(va)==n and not(set(tr)&set(va));assert len(tr)>=32 and len(va)>1
  if binary:assert set(y[tr].flatten().tolist())==set(y[va].flatten().tolist())=={0.,1.},'Invalid class support in official scaffold split'
  write(o/'SPLIT.json',{'train':tr.tolist(),'valid':va.tolist(),'seed':seed,'train_val_sha256':sha(S/'data/admet_group'/task/'train_val.csv')})
  def samples(ix):return [(rows[i]['canonical_isomeric_smiles'],gs[i],fp[i],md[i],y[i] if i<n else torch.zeros(1)) for i in ix]
  coll=Collator_tune(5);gen=torch.Generator().manual_seed(seed)
  train=DataLoader(samples(tr),batch_size=32,shuffle=True,generator=gen,drop_last=True,collate_fn=coll,num_workers=0)
  valid=DataLoader(samples(va),batch_size=32,shuffle=False,collate_fn=coll,num_workers=0)
  keys=['d_node_feats','d_edge_feats','d_g_feats','d_hpath_ratio','n_mol_layers','path_length','n_heads','n_ffn_dense_layers']
  model=LiGhTPredictor(**{k:c[k] for k in keys},input_drop=0,attn_drop=0,feat_drop=0,n_node_types=Vocab(N_ATOM_TYPES,N_BOND_TYPES).vocab_size)
  model.load_state_dict({k.removeprefix('module.'):v for k,v in torch.load(CP,map_location='cpu',weights_only=True).items()},strict=True)
  model.predictor=ns['get_predictor'](c['d_g_feats']*3,1,2,0,'cpu',256)
  del model.md_predictor;del model.fp_predictor;del model.node_predictor
  model.cuda();allparams=list(model.named_parameters());assert all(p.requires_grad for _,p in allparams)
  probe_name,probe=next((k,p) for k,p in allparams if 'model.mol_T_layers.0.' in k and p.ndim==2);before=probe.detach().clone()
  opt=transformers.AdamW(model.parameters(),lr=3e-5,weight_decay=0)
  sched=transformers.get_polynomial_decay_schedule_with_warmup(opt,50*len(tr)//32//10,50*len(tr)//32,1e-9)
  mean=y[tr].mean(0).cuda() if not binary else None;std=y[tr].std(0,unbiased=False).cuda() if not binary else None
  if std is not None:assert float(std)>1e-12
  loss=torch.nn.SmoothL1Loss(reduction='none') if metric=='Spearman' else (torch.nn.BCEWithLogitsLoss(reduction='none') if binary else torch.nn.MSELoss(reduction='none'))
  trainer=TrainOnly(types.SimpleNamespace(n_epochs=50),opt,sched,loss,None,None,None,torch.device('cuda'),mean,std)
  def predict(loader):
   model.eval();out=[]
   with torch.inference_mode():
    for batch in loader:
     p,_=trainer._forward_epoch(model,batch)
     if not binary:p=p*std+mean
     else:p=torch.sigmoid(p)
     out.extend(p.detach().cpu().numpy().reshape(-1))
   arr=np.asarray(out);assert np.isfinite(arr).all();return arr
  best=(-float('inf') if metric!='MAE' else float('inf'));bestepoch=0;history=[];start=time.monotonic()
  epochs=1 if smoke else 50
  for epoch in range(1,epochs+1):
   trainer.train_epoch(model,train,epoch);pred=predict(valid);v=metric_value(metric,y[va].numpy().flatten(),pred);assert np.isfinite(v)
   history.append({'epoch':epoch,'validation_metric':v,'elapsed':time.monotonic()-start})
   if (v<best if metric=='MAE' else v>best):best=v;bestepoch=epoch;torch.save({k:v.detach().cpu() for k,v in model.state_dict().items()},o/'best.pt')
   (o/'PROGRESS.json').write_text(json.dumps({'epoch':epoch,'best_epoch':bestepoch,'best_valid':best,'history':history},indent=2));print(task,seed,epoch,'VALID',v,flush=True)
   if epoch-bestepoch>=20:break
  change=float((probe-before).abs().max().item());assert change>0,'Backbone did not update'
  if smoke:
   write(o/'SMOKE_PASS.json',{'backbone_parameter':probe_name,'max_parameter_change':change,'cuda_peak_bytes':torch.cuda.max_memory_allocated(),'validation_metric':best,'seconds':time.monotonic()-start});return
  model.load_state_dict(torch.load(o/'best.pt',map_location='cpu',weights_only=True),strict=True)
  testloader=DataLoader(samples(range(n,len(rows))),batch_size=32,shuffle=False,collate_fn=coll,num_workers=0)
  pred=predict(testloader);np.savez_compressed(o/'predictions.npz',row_ids=np.array([r['row_id'] for r in rows[n:]]),prediction=pred)
  rec={'seed':seed,'task':task,'metric':metric,'best_epoch':bestepoch,'validation_metric':best,'epochs_run':len(history),'prediction_sha256':sha(o/'predictions.npz'),'model_sha256':sha(o/'best.pt'),'split_sha256':sha(o/'SPLIT.json'),'pretrained_sha256':sha(CP),'train_rows':len(tr),'valid_rows':len(va),'test_rows':len(pred),'backbone_changed':change,'seconds':time.monotonic()-start,'label_mean':mean.cpu().tolist() if mean is not None else None,'label_std':std.cpu().tolist() if std is not None else None}
  write(o/'FIT.json',rec);records.append(rec);del model,trainer,opt,sched,probe,before;torch.cuda.empty_cache()
 write(d/'PREDICTIONS_FROZEN.json',{'runs':records,'rows_sha256':sha(d/'ROWS.json'),'test_labels_used':False,'protocol_sha256':sha(R/'PROTOCOL.md')})

if __name__=='__main__':
 tasks=list(csv.DictReader((R/'SUBMITTED_TABLE1.csv').open()))
 if len(sys.argv)>1 and sys.argv[1]=='smoke':run_task(tasks[0],True);sys.exit()
 status={}
 for t in tasks:
  try:run_task(t);status[t['task']]='PREDICTIONS_FROZEN'
  except Exception as e:
   status[t['task']]='FAILED';traceback.print_exc();p=R/'kpgt_ft'/t['task']/'FAILURE.json'
   if not p.exists():write(p,{'error':repr(e),'traceback':traceback.format_exc()})
  (R/'STATUS.json').write_text(json.dumps(status,indent=2))
