import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import sys,json,hashlib,csv,importlib.util
from pathlib import Path
import numpy as np,pandas as pd,joblib
R=Path(__file__).resolve().parent;OLD=Path('/mnt/data/projects/trimole_minimol_kpgt22_20261014_v01');S=Path('/mnt/data/projects/trimole_hybrid_revision_20260915')
sys.path.insert(0,str(OLD));import s28_head_adapter
sys.path.insert(0,str(R/'official_source'))
from src.model.light import LiGhTPredictor
from src.model_config import config_dict
from src.data.featurizer import Vocab,N_ATOM_TYPES,N_BOND_TYPES,smiles_to_graph_tune
from src.data.collator import Collator_tune
from src.data.descriptors.rdNormalizedDescriptors import RDKit2DNormalized
import torch
from rdkit import Chem
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
cp=S/'_dependencies/KPGT/models/base.pth';assert sha(cp)=='8811c117cfedddff5ef2a512290d1a7a73d3d9560773860bc3b06942c597d15d'
c=config_dict['base'];keys=['d_node_feats','d_edge_feats','d_g_feats','d_hpath_ratio','n_mol_layers','path_length','n_heads','n_ffn_dense_layers']
m=LiGhTPredictor(**{k:c[k] for k in keys},input_drop=0,attn_drop=0,feat_drop=0,n_node_types=Vocab(N_ATOM_TYPES,N_BOND_TYPES).vocab_size)
m.load_state_dict({k.removeprefix('module.'):v for k,v in torch.load(cp,map_location='cpu',weights_only=True).items()},strict=True);m.eval().cuda();torch.set_num_threads(2)
gen=RDKit2DNormalized();col=Collator_tune(5);report=[]
for t in csv.DictReader((OLD/'SUBMITTED_TABLE1.csv').open()):
 d=OLD/'kpgt'/t['task']
 if not (d/'PREDICTIONS_FROZEN.json').exists():continue
 rows=json.loads((d/'ROWS.json').read_text());done=json.loads((d/'features/completion.json').read_text());xs=[];ids=[]
 for b in done['batches']:
  p=d/'features'/b['file'];assert sha(p)==b['npz_sha256']
  with np.load(p) as z:xs.append(z['features']);ids+=z['row_ids'].tolist()
 X=np.concatenate(xs);assert ids==[r['row_id'] for r in rows] and np.isfinite(X).all()
 n=sum(':dev:' in v for v in ids);maxdiff=0
 for seed in [101,202,303,404,505]:
  fit=json.loads((d/f'seed{seed}/FIT.json').read_text());mp=d/f'seed{seed}/model.joblib';assert sha(mp)==fit['model_sha256'];model=joblib.load(mp)
  with np.load(d/f'seed{seed}/predictions.npz') as z:p=z['prediction'];assert z['row_ids'].tolist()==ids[n:]
  diff=float(np.max(abs(model.predict(X[n:])-p)));assert diff<1e-10;maxdiff=max(maxdiff,diff)
 # Recompute the first 16 embeddings with freshly downloaded official code at identical batch size.
 samples=[]
 for r in rows[:16]:
  sm=r['canonical_isomeric_smiles'];mol=Chem.MolFromSmiles(sm);fp=np.array(Chem.RDKFingerprint(mol,minPath=1,maxPath=7,fpSize=512),dtype=np.float32);md=np.array(gen.process(sm)[1:],dtype=np.float32);md=np.where(np.isnan(md),0,md)
  samples.append((sm,smiles_to_graph_tune(sm,max_length=5,n_virtual_nodes=2),torch.from_numpy(fp),torch.from_numpy(md),torch.zeros(1)))
 _,g,fp,md,_=col(samples)
 with torch.inference_mode():fresh=m.generate_fps(g.to('cuda'),fp.cuda(),md.cuda()).cpu().numpy()
 diff=float(np.max(abs(fresh-X[:16])));assert np.allclose(fresh,X[:16],atol=1e-5,rtol=1e-5),(t['task'],diff)
 report.append({'task':t['task'],'rows':len(rows),'dimensions':X.shape[1],'feature_replay_max_abs':diff,'prediction_replay_max_abs':maxdiff,'nonconstant_feature_columns':int((X.std(axis=0)>1e-8).sum())})
 print(t['task'],'AUDIT_PASS',flush=True)
(R/'FROZEN_COMPONENT_AUDIT.json').write_text(json.dumps({'checkpoint_sha256':sha(cp),'tasks':report,'scope':'all saved head prediction replays and first16-row official-source feature replay per completed task; not proof of optimal head or full pretraining exposure','official_source_sha256':{str(p.relative_to(R/'official_source')):sha(p) for p in (R/'official_source/src').rglob('*.py')}},indent=2))
