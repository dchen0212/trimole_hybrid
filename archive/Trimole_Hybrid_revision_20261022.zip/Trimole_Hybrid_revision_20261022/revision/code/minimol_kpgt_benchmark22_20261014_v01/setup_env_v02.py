import subprocess,pathlib,json
R=pathlib.Path('/mnt/data/projects/trimole_minimol_kpgt22_20261014_v01')
(R/'constraints_v02.txt').write_text('torch==2.1.2\nnumpy==1.26.4\nscipy==1.11.4\ntorch-geometric==2.5.3\nlightning==2.2.5\npytorch-lightning==2.2.5\nwandb==0.16.6\ntorchmetrics==0.10.3\n')
cmd=[str(R/'minimol_env/bin/python'),'-m','pip','install','--timeout','120','-i','https://mirrors.aliyun.com/pypi/simple/','-f','https://data.pyg.org/whl/torch-2.1.0+cu121.html','--constraint',str(R/'constraints_v02.txt'),'graphium==2.4.7','hydra-core','setuptools<81']
with (R/'install_v02.log').open('x') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(R/'INSTALL_STATUS_v02.json').write_text(json.dumps({'returncode':p.returncode,'command':cmd},indent=2))
