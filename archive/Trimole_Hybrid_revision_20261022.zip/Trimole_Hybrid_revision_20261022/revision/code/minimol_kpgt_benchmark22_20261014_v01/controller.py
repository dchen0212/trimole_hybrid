"""Own-batch controller: dependency gate, sequential GPU stages, automatic report."""
import json,time,subprocess,os,traceback
from pathlib import Path
R=Path(__file__).resolve().parent
PY='/mnt/data/projects/trimole_clean_reproduction_20260927/ept_env/bin/python'
def status(stage,**kw):(R/'CONTROLLER_STATUS.json').write_text(json.dumps({'stage':stage,'utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),**kw},indent=2))
def run(cmd,log):
 with (R/log).open('x') as f:
  p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,cwd=R)
 return p.returncode
try:
 status('WAIT_KPGT')
 while True:
  p=R/'KPGT_STATUS.json'
  if p.exists() and len(json.loads(p.read_text()))==22:break
  pid=json.loads((R/'KPGT_LAUNCH.json').read_text())['pid']
  try:os.kill(pid,0)
  except ProcessLookupError:raise RuntimeError('KPGT worker stopped before all task dispositions')
  time.sleep(20)
 status('EVALUATE_KPGT')
 assert run([PY,str(R/'evaluate.py'),'kpgt'],'kpgt_evaluate.log')==0
 status('WAIT_MINIMOL_INSTALL')
 start=time.monotonic()
 while not (R/'INSTALL_STATUS_v02.json').exists():
  if time.monotonic()-start>7200:raise RuntimeError('Dependency installation timeout')
  time.sleep(20)
 assert json.loads((R/'INSTALL_STATUS_v02.json').read_text())['returncode']==0,'MiniMol dependency installation failed'
 status('LAUNCH_MINIMOL')
 assert run([PY,str(R/'launch_minimol.py')],'minimol_launch.log')==0
 while True:
  p=R/'MINIMOL_STATUS.json'
  if p.exists() and len(json.loads(p.read_text()))==22:break
  pid=json.loads((R/'MINIMOL_LAUNCH.json').read_text())['pid']
  try:os.kill(pid,0)
  except ProcessLookupError:raise RuntimeError('MiniMol stopped; inspect minimol.log')
  time.sleep(20)
 status('EVALUATE_MINIMOL')
 assert run([PY,str(R/'evaluate.py'),'minimol'],'minimol_evaluate.log')==0
 status('FINISHED_WITH_TASK_DISPOSITIONS')
except Exception as e:status('FAILED',error=repr(e),traceback=traceback.format_exc());raise
