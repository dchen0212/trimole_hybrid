import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import sys,json,csv,hashlib,time,traceback
from pathlib import Path
import numpy as np,pandas as pd
R=Path(__file__).resolve().parent
S=Path('/mnt/data/projects/trimole_hybrid_revision_20260915')
ST=Path('/mnt/data/projects/trimole_dual3090_transfer_20261011_v01/staging/structures')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(x,f,indent=2,allow_nan=False)
def guard(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)) and Path(os.fsdecode(args[0])).name=='test.csv':raise PermissionError('No test labels during features/fit')
sys.addaudithook(guard)
tasks=list(csv.DictReader((R/'SUBMITTED_TABLE1.csv').open()))

def run(t):
 task=t['task'];d=R/'kpgt'/task;d.mkdir(parents=True,exist_ok=True)
 if (d/'PREDICTIONS_FROZEN.json').exists():return
 df=pd.read_csv(S/'data/admet_group'/task/'train_val.csv');h=json.loads((ST/(task+'.json')).read_text());assert h['labels_present'] is False
 rows=[{'row_id':f'{task}:dev:{i}','task':task,'split':'train','canonical_isomeric_smiles':s} for i,s in enumerate(df.Drug)]
 rows +=[{'row_id':f'{task}:test:{r["source_row"]}','task':task,'split':'test','canonical_isomeric_smiles':r['raw_smiles']} for r in h['rows']]
 # Sidecar is label-free; explicit IDs preserve source row identity.
 if not (d/'ROWS.json').exists():write(d/'ROWS.json',rows)
 from rdkit import Chem
 bad=[r['row_id'] for r in rows if Chem.MolFromSmiles(r['canonical_isomeric_smiles']) is None]
 if bad:raise ValueError('STRUCTURE_PARSE_FAILURE: '+repr(bad))
 import extract_kpgt_v02 as e
 e.load_structures=lambda _:(rows,{'structures_sha256':sha(d/'ROWS.json')})
 cp=S/'_dependencies/KPGT/models/base.pth'
 assert sha(cp)=='8811c117cfedddff5ef2a512290d1a7a73d3d9560773860bc3b06942c597d15d'
 sys.argv=['extract','--input',str(d),'--out',str(d/'features'),'--source',str(S/'_dependencies/KPGT'),'--checkpoint',str(cp),'--device','cuda:0','--batch-size','16'];e.main()
 done=json.loads((d/'features/completion.json').read_text());xs=[];ids=[]
 for b in done['batches']:
  p=d/'features'/b['file'];assert sha(p)==b['npz_sha256']
  with np.load(p) as z:xs.append(z['features']);ids+=z['row_ids'].tolist()
 assert ids==[r['row_id'] for r in rows]
 X=np.concatenate(xs);n=len(df);y=df.Y.to_numpy(float)
 from s28_head_adapter import fit_e_head
 import joblib
 scores=[]
 for seed in [101,202,303,404,505]:
  out=d/f'seed{seed}';out.mkdir(exist_ok=True)
  if (out/'FIT.json').exists():scores.append(json.loads((out/'FIT.json').read_text()));continue
  start=time.monotonic();m=fit_e_head(X[:n],y,head='stable_linear',metric=t['metric'],seed=seed)
  pred=m.predict(X[n:]);assert len(pred)==len(h['rows'])
  joblib.dump(m,out/'model.joblib');np.savez_compressed(out/'predictions.npz',row_ids=np.array(ids[n:]),prediction=pred)
  rec={'seed':seed,'task':task,'metric':t['metric'],'fit_rows':n,'test_rows':len(pred),'train_val_sha256':sha(S/'data/admet_group'/task/'train_val.csv'),'rows_sha256':sha(d/'ROWS.json'),'checkpoint_sha256':sha(cp),'head_code_sha256':sha(R/'s28_head_adapter.py'),'model_sha256':sha(out/'model.joblib'),'prediction_sha256':sha(out/'predictions.npz'),'seconds':time.monotonic()-start}
  write(out/'FIT.json',rec);scores.append(rec)
 write(d/'PREDICTIONS_FROZEN.json',{'runs':scores,'feature_completion_sha256':sha(d/'features/completion.json'),'test_labels_used':False})

if __name__=='__main__':
 status={}
 for t in tasks:
  task=t['task'];print('START',task,flush=True)
  try:run(t);status[task]='PREDICTIONS_FROZEN'
  except Exception as e:
   status[task]='FAILED';traceback.print_exc();d=R/'kpgt'/task;d.mkdir(parents=True,exist_ok=True)
   p=d/'FAILURE.json'
   if not p.exists():write(p,{'error':repr(e),'traceback':traceback.format_exc()})
  (R/'KPGT_STATUS.json').write_text(json.dumps(status,indent=2));print(task,status[task],flush=True)
