import os,subprocess,json,hashlib
from pathlib import Path
R=Path(__file__).resolve().parent
assert json.loads((R/'INSTALL_STATUS_v02.json').read_text())['returncode']==0
# Verify official source/checkpoint archive against local manifest before imports.
manifest=json.loads((R/'SOURCE_FREEZE.json').read_text())
for rel,h in manifest['files'].items():assert hashlib.sha256((R/rel).read_bytes()).hexdigest()==h,rel
old=json.loads(Path('/mnt/data/projects/trimole_target_only_expanded_20261013_v02/ENVIRONMENT.json').read_text());env=os.environ.copy()
env['CUDA_VISIBLE_DEVICES']='GPU-8dccd0a6-2c1e-0e9a-dda8-105662f17745'
env['LD_LIBRARY_PATH']=old['environment']['LD_LIBRARY_PATH'];env['WANDB_MODE']='disabled';env['WANDB_DISABLED']='true';env['PYTHONDONTWRITEBYTECODE']='1'
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:env[k]='2'
# No inherited training project PYTHONPATH; MiniMol has an isolated dependency layer.
with (R/'minimol_smoke_v02.log').open('x') as f:
 subprocess.run([str(R/'minimol_env/bin/python'),'-B',str(R/'smoke_minimol_v02.py')],stdout=f,stderr=subprocess.STDOUT,env=env,cwd=R,check=True,timeout=600)
with (R/'minimol.log').open('x') as f:
 p=subprocess.Popen([str(R/'minimol_env/bin/python'),'-B',str(R/'run_minimol.py')],stdout=f,stderr=subprocess.STDOUT,env=env,cwd=R,stdin=subprocess.DEVNULL,start_new_session=True)
(R/'MINIMOL_LAUNCH.json').write_text(json.dumps({'pid':p.pid,'source_freeze_sha256':hashlib.sha256((R/'SOURCE_FREEZE.json').read_bytes()).hexdigest()},indent=2));print(p.pid)
