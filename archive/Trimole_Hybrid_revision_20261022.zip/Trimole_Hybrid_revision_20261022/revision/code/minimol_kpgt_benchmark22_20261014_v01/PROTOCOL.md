# MiniMol and KPGT 22-task benchmark, v01

User authorization: add MiniMol reproduction and standalone KPGT benchmark on the 22 tasks. No F; no historical batch resumed. Existing 20+2 Trimole-Hybrid scores are a descriptive reference, not a new matched independent evaluation.

## MiniMol
Use graphcore-research/minimol pinned source and shipped checkpoint, frozen encoder. Follow tdc_leaderboard_submission.py task-specific SWEEP_RESULTS, 25 epochs, batch 32, five repetitions each averaging five heads (logits before sigmoid), validation BCE/MSE checkpoint selection, TDC default scaffold train/valid split with Cantor-paired seeds (rep 1..5, member 6..10). Save keyed predictions and fit IDs. Make train/eval mode explicit, seed RNGs; record those reproducibility repairs, GPU execution and any dtype compatibility repairs as deviations. Infer task type from metric metadata, never test labels. No retuning using test performance. This reproduces the publicly available recipe, not necessarily every historical leaderboard submission.

## KPGT component
Use official byte-bound base.pth, frozen 2304-dimensional graph/fingerprint/descriptor representation, plus the existing standalone deep_kpgt_ridge_linear head from the nine-candidate catalog. Do not add ChemBERTa, EPT, chemical sidecar or F. Fixed head parameters copied from s28_head_adapter.py. Fit preprocessing and head on all official train_val rows; five seeds 101,202,303,404,505. No hyperparameter search or early stopping. Deterministic regression fits may have zero seed SD and must be reported as such. This is a standalone component benchmark, not a reproduction of end-to-end KPGT fine-tuning or exact historical submitted fits.

## Shared reporting
22 tasks, official metric per task, official fixed test rows with explicit row identities. Preserve all failures and report coverage; never silently delete invalid molecules or replace predictions with labels. Reject tasks whose structures cannot be processed; resolve structure issues separately before adding them back. Freeze all predictions for an arm/task before opening its evaluation labels. Test sets already have historical exposure: benchmark reuse. Report five-run mean and population SD, per-task signed difference vs current 20+2 table, and timing. Different training/search budgets disclosed. Pretraining corpus exposure is distinct from downstream target-only fitting and is not asserted absent.

## Figure 2
Current original Figure 2 mixes selected 10-task top-1 comparisons, rank coverage, normalized mixed-model summaries and subgroup plots. New comparisons should cover all 22 tasks, group native metrics, and distinguish public reported MiniMol numbers from reproduced MiniMol numbers. Do not replace existing figures before results are reviewed.
