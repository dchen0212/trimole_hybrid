"""New E-only S28 heads. No archived pipeline import or data loader.

Caller supplies E_fit only and label-free inference matrices. All nine heads
use exactly the recorded head parameters. Strict failure replaces historical
silent nonfinite substitution / decision-function fallback.
"""
from dataclasses import dataclass
import warnings
import numpy as np

LINEAR_CLASSIFICATION = dict(loss='modified_huber',penalty='elasticnet',alpha=1e-4,
    l1_ratio=.15,max_iter=3000,tol=1e-4,class_weight='balanced')
XGB = dict(n_estimators=350,max_depth=4,learning_rate=.035,min_child_weight=1,
    subsample=.85,colsample_bytree=.85,reg_lambda=1.,tree_method='hist',n_jobs=1)

def finite(a, ndim):
    a=np.asarray(a,dtype=float)
    if a.ndim!=ndim or not np.isfinite(a).all():
        raise ValueError('NONFINITE_OR_INVALID_INPUT_NO_IMPUTATION')
    return a

@dataclass
class Head:
    model: object
    binary: bool
    center: float=0.
    scale: float=1.
    bounds: object=None
    def predict(self,x):
        x=finite(x,2)
        p=self.model.predict_proba(x)[:,1] if self.binary else self.model.predict(x)*self.scale+self.center
        if self.bounds is not None: p=np.clip(p,*self.bounds)
        p=finite(p,1)
        if self.binary and np.any((p<0)|(p>1)):raise ValueError('INVALID_PROBABILITY')
        return p

def fit_e_head(x_e_fit,y_e_fit,*,head,metric,seed=101):
    from sklearn.pipeline import make_pipeline
    from sklearn.preprocessing import StandardScaler
    from sklearn.linear_model import SGDClassifier,Ridge
    from sklearn.exceptions import ConvergenceWarning
    x=finite(x_e_fit,2);y=finite(y_e_fit,1)
    if len(y)!=len(x):raise ValueError('ROW_MISMATCH')
    binary=metric.lower() in {'auroc','auprc'}
    if binary and set(y)!={0.,1.}:raise ValueError('E_FIT_REQUIRES_BOTH_CLASSES')
    if head=='xgb':
        from xgboost import XGBClassifier,XGBRegressor
        kwargs=dict(XGB,random_state=seed)
        model=(XGBClassifier(**kwargs,objective='binary:logistic',eval_metric='auc') if binary
               else XGBRegressor(**kwargs,objective='reg:squarederror',eval_metric='mae'))
        # Historical source has no early_stopping_rounds. Fixed 350 rounds;
        # removing the old valid eval_set does not introduce new tuning.
        model.fit(x,y,verbose=False)
        return Head(model,binary)
    if head!='stable_linear':raise ValueError('HEAD_NOT_IN_S28')
    if binary:
        model=make_pipeline(StandardScaler(),SGDClassifier(**LINEAR_CLASSIFICATION,random_state=seed))
        with warnings.catch_warnings():
            warnings.simplefilter('error',ConvergenceWarning)
            model.fit(x,y)
        return Head(model,True)
    center=float(y.mean());scale=float(y.std())
    if scale<1e-12:raise ValueError('CONSTANT_E_FIT_TARGET')
    model=make_pipeline(StandardScaler(),Ridge(alpha=10.,solver='lsqr',tol=1e-3,random_state=seed))
    model.fit(x,(y-center)/scale)
    pad=.1*max(float(np.ptp(y)),scale,1.)
    return Head(model,False,center,scale,(float(y.min())-pad,float(y.max())+pad))
