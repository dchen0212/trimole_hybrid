"""Extract fresh KPGT vectors from jointly keyed graph/fingerprint/descriptor rows."""
import argparse
import json
import os
from pathlib import Path
import sys
import time

import numpy as np
from extract_chemberta import atomic_json, load_structures, sha


NAN_LOADER_RULE = {
    "schema": "pinned_kpgt_normalized_nan_loader/v1",
    "operation": "float32 -> exact shape -> np.where(np.isnan(md), np.float32(0), md) -> finite check",
    "finetune_dataset_sha256": "084a58a3a4e990bcdc52a1be28e1923078f8de60315fe728f5930cdef817cda6",
    "pretrain_dataset_sha256": "68db109d98fa3c4042466755832176b909a466380ba4a2645fc344050c8f438f",
    "scope": "normalized descriptors only; mask audit only; Inf remains rejected"
}

NAN_POLICY_SHA256=__import__("hashlib").sha256(json.dumps(NAN_LOADER_RULE,sort_keys=True,separators=(",",":")).encode()).hexdigest()

def normalized_loader(md):
    a=np.asarray(md,dtype=np.float32)
    if a.shape!=(200,):raise ValueError("invalid normalized descriptor shape")
    mask=np.isnan(a)
    cleaned=np.where(mask,np.float32(0),a)
    if not np.isfinite(cleaned).all():raise ValueError("nonfinite normalized descriptor after pinned NaN rule; Inf forbidden")
    return cleaned,mask


def verify(path, receipt, ids, protocol_sha):
    audit=path.with_suffix(".nan_audit.json")
    if sha(audit)!=receipt["nan_audit_sha256"]:raise ValueError("NaN audit hash mismatch")
    records=json.loads(audit.read_text())["rows"]
    if [x["row_id"] for x in records]!=ids.tolist():raise ValueError("NaN audit row mismatch")
    if any(len(x["nan_mask"])!=200 or x["nan_count"]!=sum(x["nan_mask"]) for x in records):raise ValueError("NaN audit mask/count mismatch")
    if receipt["protocol_sha256"] != protocol_sha or receipt["npz_sha256"] != sha(path):
        raise ValueError("checkpoint hash mismatch")
    with np.load(path, allow_pickle=False) as data:
        if not np.array_equal(data["row_ids"], ids):
            raise ValueError("row order mismatch")
        if data["features"].shape != (len(ids), 2304) or not np.isfinite(data["features"]).all():
            raise ValueError("invalid KPGT vectors")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--source", type=Path, required=True)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda:0"), default="cuda:0")
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--stop-after-batches", type=int)
    args = parser.parse_args()
    if args.batch_size < 1:
        raise ValueError("invalid batch size")
    import fcntl
    import torch
    import dgl
    import dgllife
    import scipy
    from rdkit import Chem, rdBase

    sys.path.insert(0, str(args.source.resolve()))
    from src.data.featurizer import smiles_to_graph_tune, Vocab, N_ATOM_TYPES, N_BOND_TYPES
    from src.data.descriptors.rdNormalizedDescriptors import RDKit2DNormalized
    from src.data.collator import Collator_tune
    from src.model.light import LiGhTPredictor
    from src.model_config import config_dict

    source_hashes = {str(p.relative_to(args.source)): sha(p) for p in sorted((args.source / "src").rglob("*.py"))}
    rows, sidecar = load_structures(args.input)
    protocol = {"scope": "fresh_development_kpgt", "script_sha256": sha(Path(__file__)),
        "helper_sha256": sha(Path(__file__).with_name("extract_chemberta.py")),
        "source_sha256": source_hashes, "checkpoint_sha256": sha(args.checkpoint),
        "structures_sha256": sidecar["structures_sha256"], "rows": len(rows),
        "batch_size": args.batch_size, "device": args.device, "configuration": config_dict["base"],
        "versions": {"torch": torch.__version__, "dgl": dgl.__version__, "dgllife": dgllife.__version__,
                     "rdkit": rdBase.rdkitVersion, "numpy": np.__version__, "scipy": scipy.__version__},
        "dropout": 0.0, "mode": "eval/inference", "seed": 22,
        "inputs": ["atom-bond graph", "RDKFingerprint paths 1-7 512 bits", "RDKit2DNormalized"],
        "nonfinite_policy": "pinned upstream normalized float32 NaN->0; Inf and failed/invalid input reject",
        "nan_loader_rule": NAN_LOADER_RULE,"nan_policy_sha256":NAN_POLICY_SHA256,
        "descriptor_limit": "Upstream normalized descriptor functions can return zero for unsupported or failed calculations; source is pinned and this behavior is not rewritten.",
        "labels_in_input": False, "fine_tuning": False}
    args.out.mkdir(parents=True, exist_ok=True)
    lock = (args.out / "extract.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    frozen = args.out / "protocol.json"
    if frozen.exists():
        if json.loads(frozen.read_text()) != protocol:
            raise ValueError("changed extraction protocol")
    else:
        atomic_json(frozen, protocol)
    protocol_sha = sha(frozen)
    model = None
    generator = RDKit2DNormalized()
    collator = Collator_tune(5)
    receipts, computed = [], 0
    for start in range(0, len(rows), args.batch_size):
        batch = rows[start:start + args.batch_size]
        ids = np.array([r["row_id"] for r in batch])
        path = args.out / f"batch_{start:06d}.npz"
        marker = path.with_suffix(".json")
        if marker.exists():
            receipt = json.loads(marker.read_text())
            verify(path, receipt, ids, protocol_sha)
            receipts.append({"file": path.name, **receipt})
            continue
        if model is None:
            torch.set_num_threads(2)
            torch.manual_seed(22)
            np.random.seed(22)
            config = config_dict["base"]
            keys = ("d_node_feats", "d_edge_feats", "d_g_feats", "d_hpath_ratio", "n_mol_layers",
                    "path_length", "n_heads", "n_ffn_dense_layers")
            model = LiGhTPredictor(**{k: config[k] for k in keys}, input_drop=0., attn_drop=0.,
                feat_drop=0., n_node_types=Vocab(N_ATOM_TYPES, N_BOND_TYPES).vocab_size)
            state = torch.load(args.checkpoint, map_location="cpu", weights_only=True)
            model.load_state_dict({k.removeprefix("module."): v for k, v in state.items()}, strict=True)
            model.eval().to(args.device)
        started, samples, nan_records = time.monotonic(), [], []
        for row in batch:
            try:
                smiles = row["canonical_isomeric_smiles"]
                mol = Chem.MolFromSmiles(smiles)
                graph = smiles_to_graph_tune(smiles, max_length=5, n_virtual_nodes=2)
                if mol is None or graph is None:
                    raise ValueError("invalid molecule or graph")
                fp = np.asarray(Chem.RDKFingerprint(mol, minPath=1, maxPath=7, fpSize=512), dtype=np.float32)
                descriptors = generator.process(smiles)
                if descriptors is None or not descriptors[0]:
                    raise ValueError("descriptor calculation failed")
                md = np.asarray(descriptors[1:], dtype=np.float32)
                if fp.shape != (512,) or md.shape != (200,) or not np.isfinite(fp).all():
                    raise ValueError("invalid fingerprint/descriptor shape or values")
                md,nan_mask=normalized_loader(md)
                names=[x[0] for x in generator.columns]
                if len(names)!=200:raise ValueError("descriptor column identity changed")
                nan_records.append({"row_id":row["row_id"],"nan_mask":nan_mask.astype(int).tolist(),
                    "nan_count":int(nan_mask.sum()),"fields":[{"index":int(i),"name":names[i]} for i in np.flatnonzero(nan_mask)]})
                # The collator API requires a target tensor; this constant carries no assay information.
                samples.append((smiles, graph, torch.from_numpy(fp), torch.from_numpy(md), torch.zeros(1)))
            except Exception as error:
                atomic_json(args.out / "failure.json", {"row_id": row["row_id"],
                    "protocol_sha256": protocol_sha, "stage": "joint_row_construction", "error": repr(error)})
                raise
        smiles, graph, fp, md, _ = collator(samples)
        if smiles != [r["canonical_isomeric_smiles"] for r in batch] or len(samples) != len(ids):
            raise ValueError("collation changed row order")
        with torch.inference_mode():
            vectors = model.generate_fps(graph.to(args.device), fp.to(args.device), md.to(args.device)).cpu().numpy()
        if vectors.shape != (len(ids), 2304) or not np.isfinite(vectors).all():
            raise ValueError("invalid KPGT output")
        temp = path.with_suffix(".tmp")
        with temp.open("wb") as handle:
            np.savez_compressed(handle, row_ids=ids, features=vectors)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
        audit=path.with_suffix(".nan_audit.json")
        atomic_json(audit,{"rows":nan_records,"columns":[x[0] for x in generator.columns],
            "policy":NAN_LOADER_RULE,"policy_sha256":NAN_POLICY_SHA256,"protocol_sha256":protocol_sha,"mask_changes_input_dimension":False})
        receipt = {"protocol_sha256": protocol_sha, "npz_sha256": sha(path),"nan_audit_sha256":sha(audit),
                   "rows": len(ids), "wall_seconds": time.monotonic() - started}
        atomic_json(marker, receipt)
        verify(path, receipt, ids, protocol_sha)
        receipts.append({"file": path.name, **receipt})
        computed += 1
        print(json.dumps({"completed_rows": start + len(ids), "total_rows": len(rows)}), flush=True)
        if args.stop_after_batches and computed >= args.stop_after_batches:
            print(json.dumps({"controlled_stop": True, "new_batches": computed}), flush=True)
            return
    atomic_json(args.out / "completion.json", {"protocol_sha256": protocol_sha, "rows": len(rows),
        "batches": receipts, "new_batches_this_run": computed, "pretraining_exposure": "unresolved"})
    print(json.dumps({"complete": True, "rows": len(rows), "new_batches": computed}), flush=True)


if __name__ == "__main__":
    main()
