"""Fresh keyed ChemBERTa CLS vectors with verified per-batch recovery."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import platform
import time

import numpy as np


def sha(path):
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def atomic_json(path, value):
    temp = path.with_suffix(path.suffix + ".tmp")
    with temp.open("w") as handle:
        json.dump(value, handle, sort_keys=True, indent=2, allow_nan=False)
        handle.flush()
        os.fsync(handle.fileno())
    os.replace(temp, path)


def load_structures(root):
    manifest = json.loads((root / "manifest.json").read_text())
    path = root / "structures.jsonl"
    if manifest["scope"] != "development_structure_sidecar" or sha(path) != manifest["structures_sha256"]:
        raise ValueError("structure sidecar changed")
    rows = [json.loads(line) for line in path.read_text().splitlines()]
    fields = {"row_id", "task", "split", "canonical_isomeric_smiles"}
    if len(rows) != manifest["rows"] or not rows:
        raise ValueError("structure row count mismatch")
    if any(set(row) != fields or row["split"] not in ("train", "valid") for row in rows):
        raise ValueError("unexpected fields or split in feature input")
    if len({row["row_id"] for row in rows}) != len(rows):
        raise ValueError("duplicate row IDs")
    return rows, manifest


def verify_batch(path, receipt, row_ids, protocol_sha):
    if receipt["protocol_sha256"] != protocol_sha or receipt["npz_sha256"] != sha(path):
        raise ValueError("checkpoint hash mismatch")
    with np.load(path, allow_pickle=False) as values:
        if not np.array_equal(values["row_ids"], row_ids):
            raise ValueError("checkpoint row order mismatch")
        x = values["features"]
        if x.shape != (len(row_ids), 768) or not np.isfinite(x).all():
            raise ValueError("invalid feature matrix")


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--model", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--device", choices=("cpu", "cuda:0"), default="cuda:0")
    parser.add_argument("--batch-size", type=int, default=16)
    parser.add_argument("--stop-after-batches", type=int)
    args = parser.parse_args()
    if args.batch_size < 1:
        raise ValueError("invalid batch size")
    import fcntl
    import torch
    import transformers
    from transformers import AutoModel, AutoTokenizer

    rows, source = load_structures(args.input)
    names = ("config.json", "pytorch_model.bin", "vocab.json", "merges.txt",
             "tokenizer_config.json", "special_tokens_map.json")
    model_hashes = {name: sha(args.model / name) for name in names}
    protocol = {"scope": "fresh_development_chemberta_cls", "script_sha256": sha(Path(__file__)),
                "structures_sha256": source["structures_sha256"], "model_sha256": model_hashes,
                "batch_size": args.batch_size, "max_length": 512, "pooling": "first_token",
                "device": args.device, "torch": torch.__version__, "transformers": transformers.__version__,
                "numpy": np.__version__, "python": platform.python_version(),
                "row_count": len(rows), "labels_in_input": False, "fine_tuning": False}
    args.out.mkdir(parents=True, exist_ok=True)
    lock = (args.out / "extract.lock").open("a")
    fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
    freeze = args.out / "protocol.json"
    if freeze.exists():
        if json.loads(freeze.read_text()) != protocol:
            raise ValueError("cannot resume under a changed protocol")
    else:
        atomic_json(freeze, protocol)
    protocol_sha = sha(freeze)
    model = tokenizer = None
    verified, computed = [], 0
    for start in range(0, len(rows), args.batch_size):
        batch = rows[start:start + args.batch_size]
        ids = np.array([row["row_id"] for row in batch])
        path = args.out / f"batch_{start:06d}.npz"
        marker = path.with_suffix(".json")
        if marker.exists():
            receipt = json.loads(marker.read_text())
            verify_batch(path, receipt, ids, protocol_sha)
            verified.append({"file": path.name, **receipt})
            continue
        if model is None:
            torch.set_num_threads(2)
            torch.manual_seed(1)
            tokenizer = AutoTokenizer.from_pretrained(args.model, local_files_only=True)
            model, loading = AutoModel.from_pretrained(args.model, local_files_only=True,
                add_pooling_layer=False, output_loading_info=True)
            if loading.get("missing_keys") or loading.get("mismatched_keys") or loading.get("error_msgs"):
                raise ValueError(f"incomplete checkpoint loading: {loading}")
            unused_pooler = {"roberta.pooler.dense.bias", "roberta.pooler.dense.weight"}
            if any(not key.startswith("lm_head.") and key not in unused_pooler
                   for key in loading.get("unexpected_keys", [])):
                raise ValueError(f"unexpected model parameters: {loading}")
            model.eval().to(args.device)
            atomic_json(args.out / "loading_info.json", loading)
        started = time.monotonic()
        smiles = [row["canonical_isomeric_smiles"] for row in batch]
        lengths = [len(tokenizer(s, truncation=False)["input_ids"]) for s in smiles]
        inputs = tokenizer(smiles, return_tensors="pt", padding=True, truncation=True, max_length=512)
        with torch.inference_mode():
            vectors = model(**{k: v.to(args.device) for k, v in inputs.items()}).last_hidden_state[:, 0].cpu().numpy()
        if vectors.shape != (len(batch), 768) or not np.isfinite(vectors).all():
            raise ValueError("invalid model output")
        temp = path.with_suffix(".tmp")
        with temp.open("wb") as handle:
            np.savez_compressed(handle, row_ids=ids, features=vectors)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
        receipt = {"protocol_sha256": protocol_sha, "npz_sha256": sha(path),
                   "rows": len(batch), "wall_seconds": time.monotonic() - started,
                   "truncated_row_ids": [row["row_id"] for row, length in zip(batch, lengths) if length > 512]}
        atomic_json(marker, receipt)
        verify_batch(path, receipt, ids, protocol_sha)
        verified.append({"file": path.name, **receipt})
        computed += 1
        print(json.dumps({"completed_rows": start + len(batch), "total_rows": len(rows)}), flush=True)
        if args.stop_after_batches and computed >= args.stop_after_batches:
            print(json.dumps({"controlled_stop": True, "new_batches": computed}), flush=True)
            return
    atomic_json(args.out / "completion.json", {"protocol_sha256": protocol_sha,
                "rows": len(rows), "batches": verified, "new_batches_this_run": computed,
                "historical_pretraining_exposure": "unresolved"})
    print(json.dumps({"complete": True, "rows": len(rows), "new_batches": computed}), flush=True)


if __name__ == "__main__":
    main()
