import os,json,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent
old=json.loads(Path('/mnt/data/projects/trimole_target_only_expanded_20261013_v02/ENVIRONMENT.json').read_text())
env=os.environ.copy();env.update(old['environment'])
for k in ['CUDA_CACHE_PATH','DGLDOWNLOAD_DIR','HF_HOME','MPLCONFIGDIR','NUMBA_CACHE_DIR','TORCH_HOME']:
 env[k]=str(R/'tmp'/k);Path(env[k]).mkdir(parents=True,exist_ok=True)
with (R/'kpgt.log').open('x') as f:
 p=subprocess.Popen([old['python'],'-B',str(R/'run_kpgt.py')],env=env,stdout=f,stderr=subprocess.STDOUT,start_new_session=True,stdin=subprocess.DEVNULL,cwd=R)
(R/'KPGT_LAUNCH.json').write_text(json.dumps({'pid':p.pid,'python':old['python'],'environment':env if False else {k:env[k] for k in old['environment']}},indent=2))
print(p.pid)
