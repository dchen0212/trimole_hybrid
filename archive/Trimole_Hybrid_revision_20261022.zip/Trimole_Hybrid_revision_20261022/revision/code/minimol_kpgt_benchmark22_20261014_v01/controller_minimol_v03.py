import os,time,json,subprocess
from pathlib import Path
R=Path(__file__).resolve().parent
try:
 pid=json.loads((R/'MINIMOL_LAUNCH.json').read_text())['pid']
 (R/'CONTROLLER_STATUS.json').write_text(json.dumps({'stage':'RUNNING_MINIMOL','pid':pid,'controller':'controller_minimol_v03.py'}))
 while True:
  p=R/'MINIMOL_STATUS.json'
  if p.exists() and len(json.loads(p.read_text()))==22:break
  os.kill(pid,0);time.sleep(20)
 with (R/'minimol_evaluate.log').open('x') as f:subprocess.run(['/mnt/data/projects/trimole_clean_reproduction_20260927/ept_env/bin/python',str(R/'evaluate.py'),'minimol'],cwd=R,stdout=f,stderr=subprocess.STDOUT,check=True)
 (R/'CONTROLLER_STATUS.json').write_text(json.dumps({'stage':'FINISHED_WITH_TASK_DISPOSITIONS'}))
except Exception as e:
 (R/'CONTROLLER_STATUS.json').write_text(json.dumps({'stage':'FAILED','error':repr(e),'controller':'controller_minimol_v03.py'}));raise
