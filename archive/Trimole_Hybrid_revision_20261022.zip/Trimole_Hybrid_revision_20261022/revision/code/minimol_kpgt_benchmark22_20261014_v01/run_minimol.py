"""Official-recipe downstream reproduction; no test labels in fitting process."""
import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='2'
import sys,json,csv,hashlib,time,traceback,ast,random,math,copy
from pathlib import Path
import numpy as np,pandas as pd,torch
R=Path(__file__).resolve().parent;S=Path('/mnt/data/projects/trimole_hybrid_revision_20260915');ST=Path('/mnt/data/projects/trimole_dual3090_transfer_20261011_v01/staging/structures')
sys.path.insert(0,str(R/'minimol_official'))
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(x,f,indent=2,allow_nan=False)
def guard(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)) and Path(os.fsdecode(args[0])).name=='test.csv':raise PermissionError('No test labels in fit')
sys.addaudithook(guard)
# Execute only model declarations and published hyperparameter constants, never upstream top-level evaluation.
source=R/'minimol_official/tdc_leaderboard_submission.py';tree=ast.parse(source.read_text())
keep=[]
for n in tree.body:
 if isinstance(n,ast.ImportFrom) and n.module=='tdc.benchmark_group':continue
 if isinstance(n,(ast.Import,ast.ImportFrom,ast.FunctionDef,ast.ClassDef)):keep.append(n)
 elif isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id in ['EPOCHS','REPETITIONS','ENSEMBLE_SIZE','SWEEP_RESULTS'] for t in n.targets):keep.append(n)
ns={};exec(compile(ast.Module(body=keep,type_ignores=[]),str(source),'exec'),ns)
TaskHead=ns['TaskHead'];HP=ns['SWEEP_RESULTS']
split_source=R/'tdc_split_reference.py'
split_node=next(n for n in ast.parse(split_source.read_text()).body if isinstance(n,ast.FunctionDef) and n.name=='create_scaffold_split')
split_ns={'print_sys':print};exec(compile(ast.Module(body=[split_node],type_ignores=[]),str(split_source),'exec'),split_ns)
create_scaffold_split=split_ns['create_scaffold_split']
from torch.utils.data import TensorDataset,DataLoader
from minimol import Minimol


def setup():
 # Graphium's float16 sparse featurizer is unsupported by recent scipy;
 # use float32 feature construction, matching the upstream final fp32 cast.
 import graphium.features.featurizer as gf
 for name in ['mol_to_pyggraph','mol_to_graph_dict','mol_to_adj_and_features','mol_to_adjacency_matrix']:
  fn=getattr(gf,name);defaults=list(fn.__defaults__ or ())
  fn.__defaults__=tuple(np.float32 if v is np.float16 else v for v in defaults)
  def wrap(*args,_fn=fn,**kw):
   if kw.get('dtype') is np.float16:kw['dtype']=np.float32
   return _fn(*args,**kw)
  setattr(gf,name,wrap)
 model=Minimol(batch_size=32);model.datamodule.featurization_n_jobs=1;model.datamodule.num_workers=0
 return model


def features(model,task,d,df,h):
 rows=[{'row_id':f'{task}:dev:{i}','smiles':s} for i,s in enumerate(df.Drug)]+[{'row_id':f'{task}:test:{r["source_row"]}','smiles':r['raw_smiles']} for r in h['rows']]
 if not (d/'ROWS.json').exists():write(d/'ROWS.json',rows)
 from rdkit import Chem
 bad=[r['row_id'] for r in rows if Chem.MolFromSmiles(r['smiles']) is None]
 if bad:raise ValueError('STRUCTURE_PARSE_FAILURE: '+repr(bad))
 out=d/'features';out.mkdir(exist_ok=True);xs=[]
 for start in range(0,len(rows),32):
  batch=rows[start:start+32];p=out/f'{start:06d}.npz'
  if p.exists():
   with np.load(p) as z:
    assert z['row_ids'].tolist()==[r['row_id'] for r in batch];x=z['features']
  else:
   with torch.inference_mode():vals=model([r['smiles'] for r in batch]);x=torch.stack(vals).detach().cpu().numpy()
   assert x.shape==(len(batch),512) and np.isfinite(x).all()
   np.savez_compressed(p,row_ids=np.array([r['row_id'] for r in batch]),features=x)
  xs.append(x)
  print(task,'features',start+len(batch),'/',len(rows),flush=True)
 return np.concatenate(xs),rows


def fit_task(model,t):
 task=t['task'];metric=t['metric'];binary=metric in ['AUROC','AUPRC'];d=R/'minimol'/task;d.mkdir(parents=True,exist_ok=True)
 if (d/'PREDICTIONS_FROZEN.json').exists():return
 df=pd.read_csv(S/'data/admet_group'/task/'train_val.csv');df['_row']=np.arange(len(df));h=json.loads((ST/(task+'.json')).read_text());assert h['labels_present'] is False
 X,rows=features(model,task,d,df,h);n=len(df);y=df.Y.to_numpy(np.float32)
 X=torch.tensor(X,dtype=torch.float32);yt=torch.tensor(y)
 device='cuda' if torch.cuda.is_available() else 'cpu';torch.set_num_threads(2)
 reps=[]
 for rep in range(1,6):
  pred=[];records=[]
  for member in range(6,11):
   seed=ns['cantor_pairing'](rep,member);o=d/f'rep{rep}_member{member}';o.mkdir(exist_ok=True)
   if (o/'FIT.json').exists():
    pred.append(np.load(o/'logits.npy'));records.append(json.loads((o/'FIT.json').read_text()));continue
   random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed)
   split=create_scaffold_split(df,seed=seed,frac=[.875,.125,0],entity='Drug')
   tr=split['train']['_row'].to_numpy();va=split['valid']['_row'].to_numpy()
   assert len(tr)+len(va)==n and len(set(tr)&set(va))==0
   if binary:assert set(y[tr])=={0.,1.}
   write(o/'SPLIT.json',{'seed':seed,'train_rows':tr.tolist(),'valid_rows':va.tolist(),'train_val_sha256':sha(S/'data/admet_group'/task/'train_val.csv')})
   params=HP[task];m=TaskHead(hidden_dim=params['hidden_dim'],depth=params['depth'],combine=params['combine']).to(device)
   opt=torch.optim.Adam(m.parameters(),lr=params['lr'],weight_decay=.0001)
   sched=torch.optim.lr_scheduler.LambdaLR(opt,lambda ep:ep/5 if ep<5 else (1+math.cos(math.pi*(ep-5)/20))/2)
   lossfn=torch.nn.BCELoss() if binary else torch.nn.MSELoss()
   # BatchNorm cannot train on singleton batches: merge the last singleton into previous batch.
   best=float('inf');beststate=None;history=[];start=time.monotonic()
   for epoch in range(25):
    sched.step(epoch);m.train();order=tr[torch.randperm(len(tr)).numpy()];batches=list(np.array_split(order,np.arange(32,len(order),32)))
    if len(batches)>1 and len(batches[-1])==1:batches[-2]=np.concatenate([batches[-2],batches[-1]]);batches.pop()
    for ids in batches:
     opt.zero_grad();z=m(X[ids].to(device)).reshape(-1);loss=lossfn(torch.sigmoid(z) if binary else z,yt[ids].to(device));assert torch.isfinite(loss);loss.backward();opt.step()
    m.eval();vl=[]
    with torch.no_grad():
     for k in range(0,len(va),128):
      ids=va[k:k+128];z=m(X[ids].to(device)).reshape(-1);vl.append(lossfn(torch.sigmoid(z) if binary else z,yt[ids].to(device)).item())
    v=float(np.mean(vl));history.append(v)
    if v<best:best=v;beststate={k:v.detach().cpu().clone() for k,v in m.state_dict().items()};bestepoch=epoch
   m.load_state_dict(beststate);m.eval();out=[]
   with torch.no_grad():
    for k in range(n,len(X),128):out.append(m(X[k:k+128].to(device)).reshape(-1).cpu().numpy())
   logits=np.concatenate(out);assert len(logits)==len(h['rows']) and np.isfinite(logits).all()
   torch.save(beststate,o/'model.pt');np.save(o/'logits.npy',logits)
   rec={'task':task,'rep':rep,'member':member,'seed':seed,'best_epoch':bestepoch,'valid_losses':history,'hyperparameters':params,'model_sha256':sha(o/'model.pt'),'prediction_sha256':sha(o/'logits.npy'),'split_sha256':sha(o/'SPLIT.json'),'seconds':time.monotonic()-start}
   write(o/'FIT.json',rec);records.append(rec);pred.append(logits);print(task,rep,member,'FIT_DONE',flush=True)
  z=np.mean(pred,axis=0);p=1/(1+np.exp(-z)) if binary else z
  path=d/f'rep{rep}_predictions.npz';np.savez_compressed(path,row_ids=np.array([r['row_id'] for r in rows[n:]]),prediction=p)
  reps.append({'rep':rep,'prediction_sha256':sha(path),'members':records})
 write(d/'PREDICTIONS_FROZEN.json',{'task':task,'metric':metric,'runs':reps,'rows_sha256':sha(d/'ROWS.json'),'test_labels_used':False,'official_recipe_sha256':sha(source),'checkpoint_sha256':sha(R/'minimol_official/minimol/ckpts/minimol_v1/state_dict.pth')})

if __name__=='__main__':
 model=setup();status={}
 for t in csv.DictReader((R/'SUBMITTED_TABLE1.csv').open()):
  task=t['task']
  try:fit_task(model,t);status[task]='PREDICTIONS_FROZEN'
  except Exception as e:
   status[task]='FAILED';traceback.print_exc();d=R/'minimol'/task;d.mkdir(parents=True,exist_ok=True)
   if not (d/'FAILURE.json').exists():write(d/'FAILURE.json',{'error':repr(e),'traceback':traceback.format_exc()})
  (R/'MINIMOL_STATUS.json').write_text(json.dumps(status,indent=2))
