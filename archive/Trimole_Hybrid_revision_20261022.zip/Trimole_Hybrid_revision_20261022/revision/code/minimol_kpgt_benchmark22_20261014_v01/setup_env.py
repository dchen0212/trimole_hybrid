import subprocess, pathlib, json
R=pathlib.Path('/mnt/data/projects/trimole_minimol_kpgt22_20261014_v01')
base=pathlib.Path('/mnt/data/projects/trimole_clean_reproduction_20260927/ept_env/lib/python3.10/site-packages')
site=R/'minimol_env/lib/python3.10/site-packages'
(site/'inherited_torch.pth').write_text(str(base)+'\n')
(R/'constraints.txt').write_text('torch==2.1.2\nnumpy==1.26.4\nscipy==1.11.4\ntorch-geometric==2.5.3\n')
cmd=[str(R/'minimol_env/bin/python'),'-m','pip','install','--constraint',str(R/'constraints.txt'),'graphium==2.4.7','pytdc','hydra-core','setuptools<81']
with (R/'install.log').open('w') as f:
 p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(R/'INSTALL_STATUS.json').write_text(json.dumps({'returncode':p.returncode,'command':cmd},indent=2))
