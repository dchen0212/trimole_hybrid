import json,time,hashlib
from pathlib import Path
import numpy as np,torch
from run_minimol import setup
R=Path(__file__).resolve().parent
records=[];original=torch.nn.Module.load_state_dict

def audited(self,state_dict,*args,**kwargs):
 own=set(self.state_dict());provided=set(state_dict);result=original(self,state_dict,*args,**kwargs)
 records.append({'class':type(self).__name__,'model_keys':len(own),'provided_keys':len(provided),'matched_keys':len(own&provided),'missing':list(result.missing_keys),'unexpected':list(result.unexpected_keys)})
 assert len(own&provided)>0 or not own,'Checkpoint loaded no parameters'
 return result

torch.nn.Module.load_state_dict=audited
m=setup();smiles=['CCO','c1ccccc1']
with torch.inference_mode():a=torch.stack(m(smiles)).cpu().numpy();b=torch.stack(m(smiles)).cpu().numpy()
assert a.shape==(2,512) and np.isfinite(a).all();assert np.allclose(a,b,atol=1e-6,rtol=1e-6)
# The official featurizer must not silently omit pretrained model parameters.
(R/'MINIMOL_CHECKPOINT_LOAD_AUDIT_v03.json').write_text(json.dumps(records,indent=2))
allowed={'model.task_heads.graph_output_nn.graph.graph_output_nn.layers.1.normalization.weight','model.task_heads.graph_output_nn.graph.graph_output_nn.layers.1.normalization.bias'}
assert all(set(x['missing'])<=allowed and not x['unexpected'] for x in records),'Backbone missing/mismatched checkpoint parameters'
# Official MiniMol exports gnn:15 before graph_output_nn; these unused task-head BN parameters do not enter embeddings.
(R/'MINIMOL_SMOKE.json').write_text(json.dumps({'shape':list(a.shape),'repeat_max_abs':float(np.max(abs(a-b))),'checkpoint_loads':records,'torch':torch.__version__,'source':'two synthetic molecules; no endpoint labels'},indent=2))
print('MINIMOL_SMOKE_PASS')
