import json,time,hashlib
from pathlib import Path
import numpy as np,torch
from run_minimol import setup
R=Path(__file__).resolve().parent
records=[];original=torch.nn.Module.load_state_dict

def audited(self,state_dict,*args,**kwargs):
 own=set(self.state_dict());provided=set(state_dict);result=original(self,state_dict,*args,**kwargs)
 records.append({'class':type(self).__name__,'model_keys':len(own),'provided_keys':len(provided),'matched_keys':len(own&provided),'missing':list(result.missing_keys),'unexpected':list(result.unexpected_keys)})
 assert len(own&provided)>0 or not own,'Checkpoint loaded no parameters'
 return result

torch.nn.Module.load_state_dict=audited
m=setup();smiles=['CCO','c1ccccc1']
with torch.inference_mode():a=torch.stack(m(smiles)).cpu().numpy();b=torch.stack(m(smiles)).cpu().numpy()
assert a.shape==(2,512) and np.isfinite(a).all();assert np.allclose(a,b,atol=1e-6,rtol=1e-6)
# The official featurizer must not silently omit pretrained model parameters.
(R/'MINIMOL_CHECKPOINT_LOAD_AUDIT_v02.json').write_text(json.dumps(records,indent=2))
assert all(not x['missing'] for x in records),'Missing pretrained parameters; inspect checkpoint audit'
(R/'MINIMOL_SMOKE.json').write_text(json.dumps({'shape':list(a.shape),'repeat_max_abs':float(np.max(abs(a-b))),'checkpoint_loads':records,'torch':torch.__version__,'source':'two synthetic molecules; no endpoint labels'},indent=2))
print('MINIMOL_SMOKE_PASS')
