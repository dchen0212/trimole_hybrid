import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import csv,json,hashlib,sys
from pathlib import Path
import numpy as np,pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score,average_precision_score,mean_absolute_error
R=Path(__file__).resolve().parent;S=Path('/mnt/data/projects/trimole_hybrid_revision_20260915/data/admet_group')
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
arm=sys.argv[1];out=R/(arm+'_evaluation');out.mkdir(exist_ok=True)
assert not (out/'RESULTS.json').exists(),'Evaluation already exists'
rows=[];summary=[];failed={}
current={r['task']:r for r in json.loads((R/'current_table.json').read_text())['results']}
manifest={}
for t in csv.DictReader((R/'SUBMITTED_TABLE1.csv').open()):
 task=t['task'];d=R/arm/task;seal=d/'PREDICTIONS_FROZEN.json'
 if seal.exists():manifest[task]=sha(seal)
 else:failed[task]=json.loads((d/'FAILURE.json').read_text()) if (d/'FAILURE.json').exists() else 'NOT_COMPLETE'
(out/'ACCESS_STARTED.json').write_text(json.dumps({'arm':arm,'seals':manifest,'failed':failed},indent=2))
for task,h in manifest.items():
 d=R/arm/task;seal=json.loads((d/'PREDICTIONS_FROZEN.json').read_text());rr=json.loads((d/'ROWS.json').read_text());tt=pd.read_csv(S/task/'test.csv');testrows=[r for r in rr if ':test:' in r['row_id']]
 assert len(testrows)==len(tt),'No partial test reporting'
 assert [r.get('smiles',r.get('canonical_isomeric_smiles')) for r in testrows]==tt.Drug.tolist(),'Test structure/order mismatch'
 y=tt.Y.to_numpy(float);metric=current[task]['metric'];vals=[]
 for run in seal['runs']:
  seed=run['seed'] if arm=='kpgt' else run['rep']
  p=d/f'seed{seed}/predictions.npz' if arm=='kpgt' else d/f'rep{seed}_predictions.npz'
  assert sha(p)==run['prediction_sha256']
  with np.load(p) as z:assert z['row_ids'].tolist()==[r['row_id'] for r in testrows];pred=z['prediction']
  fn={'AUROC':roc_auc_score,'AUPRC':average_precision_score,'MAE':mean_absolute_error,'Spearman':lambda a,b:spearmanr(a,b).statistic}[metric]
  score=float(fn(y,pred));assert np.isfinite(score);vals.append(score)
  rows.append({'task':task,'metric':metric,'seed_or_repeat':seed,'score':score,'prediction_sha256':sha(p),'test_sha256':sha(S/task/'test.csv')})
 assert len(vals)==5
 avg=float(np.mean(vals));cur=current[task]['current_mean']
 summary.append({'task':task,'metric':metric,'mean':avg,'population_sd':float(np.std(vals)),'current_table_mean':cur,'current_table_sd':current[task]['current_sd'],'current_advantage':avg-cur if metric=='MAE' else cur-avg,'current_source':current[task]['current_source'],'test_rows':len(tt)})
for name,data in [('SEED_SCORES.csv',rows),('SUMMARY.csv',summary)]:
 if data:
  with (out/name).open('x',newline='') as f:w=csv.DictWriter(f,fieldnames=list(data[0]));w.writeheader();w.writerows(data)
(out/'RESULTS.json').write_text(json.dumps({'arm':arm,'summary':summary,'failed':failed,'interpretation':'benchmark reuse; historical 20+2 comparator, unequal training and selection histories','full_22_complete':len(summary)==22},indent=2))
print('EVALUATED',arm,len(summary),'of 22')
