from pathlib import Path
import hashlib
import json
import shutil
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator
import numpy as np
import pandas as pd
from pypdf import PdfReader, PdfWriter, Transformation
from pypdf.generic import RectangleObject

R = Path(__file__).resolve().parent
SRC = R.parent.parent / "outputs/subgroup_four_recovery_20261020_v01"
BASE = R.parent / "figure2_original_solid_palette_20261020_v03/Figure2_solid_palette.pdf"
EXAMPLES = R.parent / "figure2d_literature_styles_20261020_v08/PLOT_DATA.csv"
DATA_FILES = [
    "PAIRED_SUBGROUP_RESULTS.csv", "SUBGROUP_COUNTS.csv",
    "PER_RUN_SUBGROUP_METRICS.csv", "COVERAGE_v02.json",
    "INPUT_HASHES_v02.json", "ANALYSIS_RECEIPT.json", "PROTOCOL.md",
    "RECOVERY_RECEIPT.json", "SOLUBILITY_ROW_MAP.csv", "SOLUBILITY_UNASSIGNED_ROWS.csv",
]
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

source_hashes = {str(p): sha(p) for p in [BASE, EXAMPLES] + [SRC / f for f in DATA_FILES]}
for f in DATA_FILES:
    shutil.copy2(SRC / f, R / f)
df = pd.read_csv(R / "PAIRED_SUBGROUP_RESULTS.csv").fillna({"reason": ""})
counts = pd.read_csv(R / "SUBGROUP_COUNTS.csv")
tasks = list(counts.task.drop_duplicates())
assert len(tasks) == 22 and len(df) == 264 and len(counts) == 132
assert not df.status.eq("source_unresolved").any()

# User requested no further changes to main Figure 2.
shutil.copy2(R.parent / "figure2_no_d_subgroup_appendix_20261020_v09/Figure2_abc.pdf", R / "Figure2_abc_unchanged.pdf")

names = {
    "bioavailability_ma": "Bioavailability", "caco2_wang": "Caco-2",
    "hia_hou": "HIA", "lipophilicity_astrazeneca": "Lipophilicity",
    "pgp_broccatelli": "P-gp", "bbb_martins": "BBB", "ppbr_az": "PPBR",
    "vdss_lombardo": "VDss", "cyp2c9_substrate_carbonmangels": "CYP2C9 substrate",
    "cyp2c9_veith": "CYP2C9 inhibition",
    "cyp2d6_substrate_carbonmangels": "CYP2D6 substrate",
    "cyp2d6_veith": "CYP2D6 inhibition",
    "cyp3a4_substrate_carbonmangels": "CYP3A4 substrate",
    "cyp3a4_veith": "CYP3A4 inhibition",
    "clearance_hepatocyte_az": "Hepatocyte clearance",
    "clearance_microsome_az": "Microsome clearance",
    "half_life_obach": "Half-life", "ames": "AMES", "dili": "DILI",
    "herg": "hERG", "ld50_zhu": "LD50", "solubility_aqsoldb": "Solubility",
}
unresolved = {}

models = [
    ("trimole", "Trimole-Hybrid", "#2E8B57"),
    ("minimol", "MiniMol", "#B99AD8"),
    ("chemprop", "Chemprop", "#82C49A"),
]
bins = ["MW<300", "MW>=300", "cLogP<3", "cLogP>=3", "TPSA<75", "TPSA>=75"]
shortlabels = ["< 300", "≥ 300", "< 3", "≥ 3", "< 75", "≥ 75"]
tablelabels = ["MW < 300", "MW ≥ 300", "cLogP < 3", "cLogP ≥ 3", "TPSA < 75", "TPSA ≥ 75"]
x = np.array([0, 1, 2.65, 3.65, 5.3, 6.3])
plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial"],
    "font.size": 10, "axes.spines.right": False, "axes.spines.top": False,
    "axes.linewidth": .8, "legend.frameon": False,
    "pdf.fonttype": 42, "svg.fonttype": "none",
})
(R / "task_figures").mkdir(exist_ok=True)
(R / "previews").mkdir(exist_ok=True)

plot_rows = []
for task in tasks:
    for bn in bins:
        pair = df[(df.task == task) & (df.bin == bn)]
        assert len(pair) == 2
        for key, name, color in models:
            row = pair.iloc[0] if key == "trimole" else pair[pair.comparator == key].iloc[0]
            plot_rows.append({
                "task": task, "metric": row.metric, "bin": bn, "method": name,
                "mean": row.trimole_score if key == "trimole" else row.baseline_score,
                "ci_low": row[f"{key}_ci_low"], "ci_high": row[f"{key}_ci_high"],
                "n": row.n, "clusters": row.clusters, "prevalence": row.prevalence,
                "status": row.status, "reason": row.reason,
            })
plot = pd.DataFrame(plot_rows)
assert len(plot) == 396
assert plot["mean"].notna().sum() == 396
plot.to_csv(R / "PLOT_DATA_ALL22.csv", index=False)

# Verify every previously displayed mean/interval is unchanged.
previous = pd.read_csv(EXAMPLES).set_index(["task", "bin", "method"])
for key, old in previous.iterrows():
    new = plot.set_index(["task", "bin", "method"]).loc[key]
    for col in ["mean", "ci_low", "ci_high", "n", "clusters", "prevalence"]:
        assert (pd.isna(old[col]) and pd.isna(new[col])) or np.isclose(
            old[col], new[col], rtol=0, atol=1e-14)

page_index = []
def styled_table(ax, celltext, labels, widths, fontsize=8):
    ax.axis("off")
    table = ax.table(cellText=celltext, colLabels=labels, colWidths=widths,
                     cellLoc="center", loc="center", bbox=[0, 0, 1, 1])
    table.auto_set_font_size(False)
    table.set_fontsize(fontsize)
    for (r, c), cell in table.get_celld().items():
        cell.set_edgecolor("#DDDDDD")
        cell.set_linewidth(.5)
        cell.set_facecolor("#F2F2F2" if r == 0 else "white")
        if r == 0:
            cell.set_text_props(weight="bold")
    return table

def page_footer(fig, number):
    fig.text(.07, .033, "Saved predictions; exploratory intervals without multiplicity correction.",
             fontsize=8, color="#666666")
    fig.text(.95, .033, str(number), fontsize=8, color="#666666", ha="right")

with PdfPages(R / "Supplementary_subgroups_all22.pdf") as pdf:
    fig = plt.figure(figsize=(11.7, 8.3))
    fig.text(.07, .91, "Molecular subgroup comparisons", fontsize=23, weight="bold")
    fig.text(.07, .86, "All 22 tasks with matched baseline predictions", fontsize=13, color="#555555")
    paragraphs = [
        ("Coverage", "All 22 tasks have matched comparisons, one task per page. BBB uses archived ensemble predictions, scored as ensembles for all three models. Solubility covers 1,995 valid structures; two invalid structures are unassigned. These two qualifications are also noted on the task pages."),
        ("What is plotted", "Within each task, the same molecules are compared across Trimole-Hybrid, MiniMol and Chemprop. For 21 tasks, bars show the mean of five run-specific metrics. BBB shows the metric of mean predictions for all three models. Groups use MW 300, cLogP 3 and TPSA 75. Sample sizes, scaffold-cluster counts and classification prevalence accompany each plot."),
        ("Uncertainty and paired comparisons", "The existing analysis used 2,000 paired scaffold-cluster bootstrap draws. Error bars are percentile 95% confidence intervals conditional on the saved fitted models. Tables report oriented paired differences: positive values favor Trimole-Hybrid. These intervals are exploratory and unadjusted for multiple comparisons."),
        ("Unavailable intervals", "Intervals require at least 30 rows, 30 scaffold clusters, five observations per class for classification, and 1,900 valid bootstrap draws. All 264 paired comparisons have point estimates. The page for each task identifies any subgroup for which an interval is withheld."),
        ("Interpretation", "The current table comprises 20 historical endpoints and two updated target-only endpoints. This retrospective analysis does not remove historical selection or source limitations. AUPRC differences across subgroups can reflect class prevalence. Model differences should be read from the paired-difference tables, not inferred from overlap of marginal error bars."),
        ("Source limitations", "Historical sources include recovered row indices and source-digest discrepancies recorded in the accompanying coverage files. VDss and CYP2D6 inhibition were recovered by preserving the original CSV precision. BBB individual-run vectors have not been recovered; its original stored ensemble is used instead. Solubility rows were matched by molecule identity, with no label-based filling."),
    ]
    y = .79
    for title, body in paragraphs:
        fig.text(.07, y, title, fontsize=11, weight="bold")
        lines = textwrap.fill(body, width=128)
        fig.text(.07, y - .028, lines, fontsize=9.5, va="top", linespacing=1.45)
        y -= .045 + .024 * len(lines.splitlines())
    page_footer(fig, 1)
    pdf.savefig(fig)
    fig.savefig(R / "previews/00_guide.png", dpi=110)
    plt.close(fig)

    for i, task in enumerate(tasks, 1):
        part = plot[plot.task == task]
        meta = counts[counts.task == task].set_index("bin").loc[bins]
        metric = part.metric.iloc[0]
        paired = df[df.task == task]
        fig = plt.figure(figsize=(11.7, 8.3))
        fig.text(.07, .93, f"{i:02d}  {names[task]}", fontsize=19, weight="bold")
        fig.text(.07, .885, f"{metric} {'↓' if metric == 'MAE' else '↑'}  |  Molecular-property subgroups",
                 fontsize=11, color="#555555")
        handles = [Patch(facecolor=co, label=nm) for _, nm, co in models]
        fig.legend(handles=handles, loc="center right", bbox_to_anchor=(.95, .89),
                   ncol=3, fontsize=10, handlelength=1.4)
        if task in unresolved:
            assert part[part.method == "Trimole-Hybrid"]["mean"].isna().all()
            fig.text(.07, .76, "Matched performance comparison unavailable", fontsize=15, weight="bold", color="#555555")
            fig.text(.07, .70, textwrap.fill(unresolved[task], width=105),
                     fontsize=12, va="top", linespacing=1.5)
            fig.text(.07, .56,
                     "Subgroup composition and available baseline means are retained below. No alternative\n"
                     "prediction set is substituted for Trimole-Hybrid; matched differences are unavailable.",
                     fontsize=11, linespacing=1.5)
            celltext = [
                ["Molecules"] + [str(int(n)) for n in meta.n],
                ["Scaffold clusters"] + [str(int(n)) for n in meta.clusters],
            ]
            if meta.prevalence.notna().all():
                celltext += [["Positive (%)"] + [f"{p * 100:.1f}" for p in meta.prevalence]]
            celltext += [["Trimole-Hybrid"] + ["Unavailable"] * 6]
            for _, name, _ in models[1:]:
                values = part[part.method == name].set_index("bin").loc[bins, "mean"]
                celltext += [[name] + [f"{v:.3f}" for v in values]]
            styled_table(fig.add_axes([.07, .25, .88, .25]), celltext,
                         [""] + tablelabels, [.18] + [.82 / 6] * 6, fontsize=9)
            fig.text(.07, .17, "Status: source verification pending for all six subgroups and both comparators.",
                     fontsize=10, color="#555555")
            fig.text(.07, .12, task, fontsize=8, color="#777777")
        else:
            ax = fig.add_axes([.10, .405, .85, .355])
            ax.set_xlim(-.65, 6.95)
            vals = part[["mean", "ci_low", "ci_high"]].to_numpy()
            finite = vals[np.isfinite(vals)]
            bottom = min(0., finite.min())
            top = max(0., finite.max())
            pad = max((top - bottom) * .12, .04)
            if metric in ["AUROC", "AUPRC"]:
                ax.set_ylim(0, 1.08)
                ax.set_yticks([0, .25, .5, .75, 1.0])
            elif metric == "Spearman":
                ax.set_ylim(bottom - (pad if bottom < 0 else 0), min(1.08, top + pad))
                ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
            else:
                ax.set_ylim(0, top + pad)
                ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
            ax.set_axisbelow(True)
            ax.yaxis.grid(True, color="#EAEAEA", lw=.65)
            ax.set_xticks(x, shortlabels)
            ax.tick_params(axis="x", length=0, pad=7)
            ax.set_ylabel(f"{metric} {'↓' if metric == 'MAE' else '↑'}", fontsize=12)
            if bottom < 0:
                ax.axhline(0, color="#999999", lw=.7)
            for pos, title in [(0.5, "Molecular weight"), (3.15, "cLogP"), (5.8, "TPSA")]:
                ax.text(pos, 1.04, title, transform=ax.get_xaxis_transform(),
                        ha="center", fontsize=11, color="#444444")
            for sep in [1.825, 4.475]:
                ax.axvline(sep, color="#D9D9D9", lw=.75, zorder=0)
            for k, (_, name, color) in enumerate(models):
                block = part[part.method == name].set_index("bin").loc[bins]
                xx = x + (k - 1) * .235
                ax.bar(xx, block["mean"], width=.205, color=color, edgecolor="none", zorder=2)
                lo, hi = block.ci_low.to_numpy(), block.ci_high.to_numpy()
                good = np.isfinite(lo) & np.isfinite(hi)
                assert np.all(lo[good] >= ax.get_ylim()[0])
                assert np.all(hi[good] <= ax.get_ylim()[1])
                ax.vlines(xx[good], lo[good], hi[good], color="#4B4B4B", lw=1, zorder=3)
                ax.hlines(lo[good], xx[good] - .04, xx[good] + .04, color="#4B4B4B", lw=.8)
                ax.hlines(hi[good], xx[good] - .04, xx[good] + .04, color="#4B4B4B", lw=.8)
            for j, (label, values) in enumerate([
                ("n", [f"{int(n):,}" for n in meta.n]),
                ("Clusters", [f"{int(n):,}" for n in meta.clusters]),
                ("Positive", [f"{p * 100:.1f}%" for p in meta.prevalence]),
            ]):
                if label == "Positive" and not meta.prevalence.notna().all():
                    continue
                yy = -.15 - j * .075
                ax.text(-.025, yy, label, transform=ax.transAxes, ha="right",
                        va="center", fontsize=8.5, color="#666666")
                for xx, value in zip(x, values):
                    ax.text(xx, yy, value, transform=ax.get_xaxis_transform(),
                            ha="center", va="center", fontsize=9, color="#666666")
            missing_bins = paired[paired.status == "withheld"].bin.unique().tolist()
            fig.text(.07, .264, "Paired difference and 95% CI: positive favors Trimole-Hybrid", fontsize=10, weight="bold")
            celltext = []
            for comp, label in [("minimol", "vs MiniMol"), ("chemprop", "vs Chemprop")]:
                rowtext = [label]
                for bn in bins:
                    row = paired[(paired.bin == bn) & (paired.comparator == comp)].iloc[0]
                    value = f"{row.delta_favors_trimole:+.3f}"
                    if row.status == "interval":
                        value += f"\n[{row.ci_low:+.3f}, {row.ci_high:+.3f}]"
                    else:
                        value += "\nCI unavailable"
                    rowtext.append(value)
                celltext.append(rowtext)
            styled_table(fig.add_axes([.07, .135, .88, .11]), celltext,
                         [""] + tablelabels, [.14] + [.86 / 6] * 6, fontsize=8)
            if missing_bins:
                reason = "; ".join(
                    f"{bn}: {paired[paired.bin == bn].iloc[0].reason}" for bn in missing_bins)
                fig.text(.07, .10, textwrap.fill("Bars without error bars - " + reason, width=137),
                         fontsize=8, color="#555555", va="top", linespacing=1.3)
            else:
                fig.text(.07, .10, "All six subgroups meet the interval-reporting criteria.", fontsize=8, color="#555555")
            if task == "hia_hou":
                fig.text(.07, .065, "Chemprop: validation-only checkpoint tie-break correction; all five seeds retained.", fontsize=8, color="#555555")
            elif task == "bbb_martins":
                fig.text(.07, .065, "BBB: archived five-run ensemble; all three methods scored from mean predictions, not mean run AUROC.", fontsize=8, color="#555555")
            elif task == "solubility_aqsoldb":
                fig.text(.07, .065, "Coverage: 1,995/1,997 molecules; two invalid structures unassigned. No replacement predictions were created.", fontsize=8, color="#555555")
            elif task == "half_life_obach":
                fig.text(.07, .065, "Chemprop: validation-selected log-target MSE configuration; all five seeds retained.", fontsize=8, color="#555555")
        page_footer(fig, i + 1)
        pdf.savefig(fig)
        stem = f"{i:02d}_{task}"
        fig.savefig(R / f"task_figures/{stem}.svg")
        fig.savefig(R / f"task_figures/{stem}.png", dpi=300)
        fig.savefig(R / f"previews/{stem}.png", dpi=110)
        plt.close(fig)
        page_index.append({
            "pdf_page": i + 1, "task": task, "display_name": names[task],
            "metric": metric, "status": "source_unresolved" if task in unresolved else "available",
            "paired_intervals": int(paired.status.eq("interval").sum()),
            "withheld_intervals": int(paired.status.eq("withheld").sum()),
        })
        print(f"Saved task {i}/22: {task}", flush=True)

pd.DataFrame(page_index).to_csv(R / "APPENDIX_PAGE_INDEX.csv", index=False)
assert len(PdfReader(R / "Supplementary_subgroups_all22.pdf").pages) == 23
assert all(sha(Path(p)) == h for p, h in source_hashes.items())

(R / "QA_RECEIPT.json").write_text(json.dumps({
    "source_sha256":source_hashes,"source_files_unchanged":True,
    "main_figure_unchanged":sha(R/"Figure2_abc_unchanged.pdf")==sha(R.parent/"figure2_no_d_subgroup_appendix_20261020_v09/Figure2_abc.pdf"),
    "appendix_pages":23,"matched_tasks":22,"bar_means":396,
    "paired_comparisons":len(df),"paired_statuses":df.status.value_counts().to_dict(),
    "marginal_intervals":int(plot.ci_low.notna().sum()),"previous_four_example_tasks_unchanged":True,
    "recomputed_tasks":["bbb_martins","vdss_lombardo","cyp2d6_veith","solubility_aqsoldb"],
    "training":False,"inference":False,"bootstrap":True,"original_files_overwritten":False,
    "bbb_statistic":"ensemble score for all three models; not main-table five-run mean",
    "solubility_coverage":"1995/1997; two invalid structures unassigned",
    "visual_review":"pending"},indent=2))
