from pathlib import Path
import hashlib,json,shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator,FormatStrFormatter

R=Path(__file__).resolve().parent
source=Path("/Users/huangdachen/Desktop/ADMET_Project_Final/tdc/molecule_subgroup_benchmark_v1/server_outputs/binary_subgroup_compact_for_text.csv")
original=pd.read_csv(source)
tasks=original.task.drop_duplicates().tolist()
assert len(tasks)==10
shutil.copy2(source,R/"ORIGINAL_TEN_TASK_SUBGROUP_SOURCE.csv")
names={"ames":"AMES","bbb_martins":"BBB","hia_hou":"HIA","pgp_broccatelli":"P-gp",
       "solubility_aqsoldb":"Solubility","ppbr_az":"PPBR",
       "clearance_hepatocyte_az":"Hepatocyte clearance",
       "clearance_microsome_az":"Microsome clearance",
       "cyp2d6_substrate_carbonmangels":"CYP2D6 substrate",
       "cyp3a4_substrate_carbonmangels":"CYP3A4 substrate"}
d=pd.read_csv(R/"PLOT_DATA_ALL22.csv")
models=[("Trimole-Hybrid","#2E8B57"),("MiniMol","#B99AD8"),("Chemprop","#82C49A")]
bins=["MW<300","MW>=300","cLogP<3","cLogP>=3","TPSA<75","TPSA>=75"]
thresholds=["< 300","≥ 300","< 3","≥ 3","< 75","≥ 75"]
x=np.array([0,1,2.65,3.65,5.3,6.3])
plt.rcParams.update({"font.family":"sans-serif","font.sans-serif":["Arial"],
    "font.size":11,"axes.spines.top":False,"axes.spines.right":False,
    "axes.linewidth":.8,"legend.frameon":False,"pdf.fonttype":42,"svg.fonttype":"none"})

def draw(fig,chosen,rows,split=False):
    fig.text(.075,.965,"Performance across molecular subgroups",fontsize=20,weight="bold")
    fig.text(.075,.94,"The ten tasks from the original Figure 2d • matched comparisons with two external baselines",
             fontsize=11,color="#555555")
    handles=[Patch(facecolor=c,label=n) for n,c in models]
    fig.legend(handles=handles,loc="center left",bbox_to_anchor=(.068,.918),ncol=3,fontsize=12)
    top=.91;bottom=.10
    slot=(top-bottom)/rows
    for i,task in enumerate(chosen):
        left=.075 if i%2==0 else .565
        yy=top-(i//2+1)*slot+.045
        ax=fig.add_axes([left,yy,.405,slot-.078])
        part=d[d.task==task]
        meta=part[part.method=="Trimole-Hybrid"].set_index("bin").loc[bins]
        metric=meta.metric.iloc[0]
        vals=part[["mean","ci_low","ci_high"]].to_numpy();finite=vals[np.isfinite(vals)]
        low=min(0,float(finite.min()));high=max(0,float(finite.max()))
        if metric in ["AUROC","AUPRC"]:
            ax.set_ylim(0,1.05);ax.set_yticks([0,.5,1])
        else:
            pad=max((high-low)*.10,.02)
            ax.set_ylim(low-pad if low<0 else 0,high+pad)
            ax.yaxis.set_major_locator(MaxNLocator(nbins=3))
        ax.yaxis.set_major_formatter(FormatStrFormatter("%.2f"))
        ax.set_xlim(-.65,6.95)
        title=names[task]+(" *" if task=="bbb_martins" else " †" if task=="solubility_aqsoldb" else "")
        ax.set_title(f"{chr(97+tasks.index(task))}   {title}",loc="left",fontsize=13,weight="bold",pad=26)
        ax.set_ylabel(f"{metric} {'↓' if metric=='MAE' else '↑'}",fontsize=11)
        ax.set_xticks(x,thresholds)
        ax.tick_params(axis="x",length=0,pad=6,labelsize=9)
        ax.tick_params(axis="y",length=3,pad=4,labelsize=9)
        ax.set_axisbelow(True);ax.yaxis.grid(True,color="#EAEAEA",lw=.6)
        for middle,label in [(0.5,"Molecular weight"),(3.15,"cLogP"),(5.8,"TPSA")]:
            ax.text(middle,1.04,label,transform=ax.get_xaxis_transform(),ha="center",fontsize=10,color="#444444")
        for sep in [1.825,4.475]:ax.axvline(sep,color="#D9D9D9",lw=.65,zorder=0)
        for k,(method,color) in enumerate(models):
            block=part[part.method==method].set_index("bin").loc[bins]
            xx=x+(k-1)*.235
            ax.bar(xx,block["mean"],width=.205,color=color,edgecolor="none",zorder=2)
            lo,hi=block.ci_low.to_numpy(),block.ci_high.to_numpy()
            good=np.isfinite(lo)&np.isfinite(hi)
            assert np.all(lo[good]>=ax.get_ylim()[0]) and np.all(hi[good]<=ax.get_ylim()[1])
            ax.vlines(xx[good],lo[good],hi[good],color="#4B4B4B",lw=.9,zorder=3)
            ax.hlines(lo[good],xx[good]-.04,xx[good]+.04,color="#4B4B4B",lw=.8)
            ax.hlines(hi[good],xx[good]-.04,xx[good]+.04,color="#4B4B4B",lw=.8)
        for row,(label,values) in enumerate([
            ("n",[str(int(n)) for n in meta.n]),
            ("Positive",[f"{p*100:.1f}%" for p in meta.prevalence])]):
            if row and not meta.prevalence.notna().all():continue
            pos=-.235-row*.135
            ax.text(-.035,pos,label,transform=ax.transAxes,ha="right",va="center",fontsize=8,color="#666666")
            for xx,value in zip(x,values):
                ax.text(xx,pos,value,transform=ax.get_xaxis_transform(),ha="center",va="center",fontsize=8.5,color="#666666")
    foot=[
        "Bars: mean of five run metrics, except BBB*. Error bars: 95% scaffold-bootstrap confidence intervals; exploratory, unadjusted.",
        "* BBB: all three methods scored using five-run mean predictions; the archived Trimole ensemble is used.",
        "† Solubility: 1,995 valid structures; two unparseable structures are unassigned. Bars without intervals have insufficient subgroup support.",
        "All 22 tasks, scaffold counts and paired model differences are provided in the supplementary subgroup analysis."
    ]
    for j,line in enumerate(foot):fig.text(.075,.061-j*.012,line,fontsize=9,color="#555555")

fig=plt.figure(figsize=(14,20))
draw(fig,tasks,5)
fig.savefig(R/"Rebuttal_subgroups_original10.pdf")
fig.savefig(R/"Rebuttal_subgroups_original10.svg")
fig.savefig(R/"Rebuttal_subgroups_original10.png",dpi=600)
fig.savefig(R/"Rebuttal_subgroups_original10_preview.png",dpi=110)
plt.close(fig)
subset=d[d.task.isin(tasks)]
assert len(subset)==180 and subset["mean"].notna().all()
subset.to_csv(R/"PLOT_DATA_REBUTTAL10.csv",index=False)
pd.DataFrame({"task":tasks,"display_name":[names[t] for t in tasks],
              "selection_reason":"Same task list as original Figure 2d; not reselected on new results"}).to_csv(R/"REBUTTAL_TASK_LIST.csv",index=False)
q=json.loads((R/"QA_RECEIPT.json").read_text())
q.update(rebuttal_tasks=tasks,rebuttal_task_source=str(source),
         rebuttal_task_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest(),
         rebuttal_bar_means=180,rebuttal_png_dpi=600,
         original_ten_task_list_verified=True)
(R/"QA_RECEIPT.json").write_text(json.dumps(q,indent=2))
