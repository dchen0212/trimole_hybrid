"""Style-only revision of the two v10 subgroup figures. No evaluation code runs."""
from pathlib import Path
import ast
import hashlib
import json
import shutil

R = Path(__file__).resolve().parent
SRC = R.parent / "rebuttal10_subgroup_all22_20261020_v10"
ATTACHED = Path("/Users/huangdachen/Library/Containers/com.tencent.xinWeChat/Data/Documents/xwechat_files/wxid_tzeh9u37bnfd32_9165/temp/drag")
FILES = [
    "PLOT_DATA_ALL22.csv", "PLOT_DATA_REBUTTAL10.csv",
    "PAIRED_SUBGROUP_RESULTS.csv", "SUBGROUP_COUNTS.csv",
    "REBUTTAL_TASK_LIST.csv", "ORIGINAL_TEN_TASK_SUBGROUP_SOURCE.csv",
    "PROTOCOL.md", "COVERAGE_v02.json",
]
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()

sources = [SRC / n for n in FILES + ["build_rebuttal.py", "build_appendix.py"]]
for name in ["Rebuttal_subgroups_original10.pdf", "Supplementary_subgroups_all22.pdf"]:
    assert (SRC / name).read_bytes() == (ATTACHED / name).read_bytes()
    sources.extend([SRC / name, ATTACHED / name])
hashes = {str(p): sha(p) for p in sources}
for name in FILES:
    shutil.copy2(SRC / name, R / name)
for name in ["build_rebuttal.py", "build_appendix.py"]:
    shutil.copy2(SRC / name, R / ("source_" + name))

def replace(s, before, after, count=1):
    assert s.count(before) == count, (before, s.count(before), count)
    return s.replace(before, after)

rebuttal = (SRC / "build_rebuttal.py").read_text()
rebuttal = replace(
    rebuttal,
    'source=Path("/Users/huangdachen/Desktop/ADMET_Project_Final/tdc/molecule_subgroup_benchmark_v1/server_outputs/binary_subgroup_compact_for_text.csv")',
    'source=R/"ORIGINAL_TEN_TASK_SUBGROUP_SOURCE.csv"')
rebuttal = replace(rebuttal, 'shutil.copy2(source,R/"ORIGINAL_TEN_TASK_SUBGROUP_SOURCE.csv")', "")
rebuttal = replace(rebuttal, '"font.size":11,', '"font.size":8,"axes.grid":False,')
start = rebuttal.index('    fig.text(.075,.965,')
end = rebuttal.index('    handles=', start)
rebuttal = rebuttal[:start] + rebuttal[end:]
rebuttal = replace(rebuttal,
    'fig.legend(handles=handles,loc="center left",bbox_to_anchor=(.068,.918),ncol=3,fontsize=12)',
    'fig.legend(handles=handles,loc="upper center",bbox_to_anchor=(.52,.995),ncol=3,fontsize=8)')
rebuttal = replace(rebuttal, 'top=.91;bottom=.10', 'top=.94;bottom=.035')
rebuttal = replace(rebuttal, 'fontsize=13,weight="bold",pad=26', 'fontsize=8.5,weight="bold",pad=14')
rebuttal = replace(rebuttal, 'fontsize=11)', 'fontsize=8)')
rebuttal = replace(rebuttal, 'pad=6,labelsize=9', 'pad=4,labelsize=7')
rebuttal = replace(rebuttal, 'length=3,pad=4,labelsize=9', 'length=2.5,pad=3,labelsize=7')
rebuttal = replace(rebuttal, 'ax.set_axisbelow(True);ax.yaxis.grid(True,color="#EAEAEA",lw=.6)', 'ax.grid(False, which="both")')
rebuttal = replace(rebuttal, '(0.5,"Molecular weight")', '(0.5,"MW")')
rebuttal = replace(rebuttal, 'fontsize=10,color="#444444"', 'fontsize=7.5,color="#222222"')
rebuttal = replace(rebuttal, '        for sep in [1.825,4.475]:ax.axvline(sep,color="#D9D9D9",lw=.65,zorder=0)\n', '')
rebuttal = replace(rebuttal, 'fontsize=8,color="#666666"', 'fontsize=7,color="#555555"')
rebuttal = replace(rebuttal, 'fontsize=8.5,color="#666666"', 'fontsize=7,color="#555555"')
start = rebuttal.index('    foot=[')
end = rebuttal.index('\nfig=plt.figure', start)
rebuttal = rebuttal[:start] + rebuttal[end:]
rebuttal = replace(rebuttal, 'fig=plt.figure(figsize=(14,20))', 'fig=plt.figure(figsize=(7.2,9.6))')
rebuttal = replace(rebuttal, 'dpi=110', 'dpi=180')
# Record numerical values actually passed to the artists.
rebuttal = replace(rebuttal, 'def draw(fig,chosen,rows,split=False):',
    'rendered=[]\ndef draw(fig,chosen,rows,split=False):')
rebuttal = replace(rebuttal, '            xx=x+(k-1)*.235',
    '            rendered.extend(block.reset_index()[["task","bin","method","mean","ci_low","ci_high"]].to_dict("records"))\n'
    '            xx=x+(k-1)*.235')
start = rebuttal.index('q=json.loads(')
rebuttal = rebuttal[:start] + 'pd.DataFrame(rendered).to_csv(R/"RENDERED_REBUTTAL_DATA.csv",index=False)\n'
(R / "build_rebuttal.py").write_text(rebuttal)

appendix = (SRC / "build_appendix.py").read_text()
start = appendix.index('SRC = ')
end = appendix.index('names = {')
appendix = appendix[:start] + '''df = pd.read_csv(R / "PAIRED_SUBGROUP_RESULTS.csv").fillna({"reason": ""})
counts = pd.read_csv(R / "SUBGROUP_COUNTS.csv")
tasks = list(counts.task.drop_duplicates())
assert len(tasks) == 22 and len(df) == 264 and len(counts) == 132
''' + appendix[end:]
appendix = replace(appendix, '"font.size": 10,', '"font.size": 8, "axes.grid": False,')
start = appendix.index('plot_rows = []')
end = appendix.index('page_index = []', start)
appendix = appendix[:start] + '''plot = pd.read_csv(R / "PLOT_DATA_ALL22.csv").fillna({"reason": ""})
assert len(plot) == 396 and plot["mean"].notna().all()
rendered = []
''' + appendix[end:]
appendix = replace(appendix, 'cell.set_edgecolor("#DDDDDD")', 'cell.set_edgecolor("#555555")')
appendix = replace(appendix, 'cell.set_linewidth(.5)', 'cell.set_linewidth(.45)\n        cell.visible_edges = "TB" if r == 0 else ("B" if r == len(celltext) else "")')
appendix = replace(appendix, 'cell.set_facecolor("#F2F2F2" if r == 0 else "white")', 'cell.set_facecolor("white")')
appendix = replace(appendix, 'cell.set_text_props(weight="bold")', 'cell.set_text_props(weight="normal")')
start = appendix.index('def page_footer(')
end = appendix.index('with PdfPages(', start)
appendix = appendix[:start] + appendix[end:]
start = appendix.index('    fig = plt.figure', appendix.index('with PdfPages('))
end = appendix.index('    for i, task in enumerate(tasks, 1):', start)
# Save the complete original explanation as figure captions, not decoration inside the plots.
original_guide = (SRC / "build_appendix.py").read_text()
tree = ast.parse(original_guide)
guide = next(ast.literal_eval(n.value) for n in ast.walk(tree)
             if isinstance(n, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "paragraphs" for t in n.targets))
appendix = appendix[:start] + appendix[end:]
appendix = replace(appendix, 'fig = plt.figure(figsize=(11.7, 8.3))', 'fig = plt.figure(figsize=(7.2, 5.3))')
appendix = replace(appendix,
    'fig.text(.07, .93, f"{i:02d}  {names[task]}", fontsize=19, weight="bold")',
    'qualification = " *" if task == "bbb_martins" else " †" if task == "solubility_aqsoldb" else ""\n'
    '        fig.text(.07, .95, f"{i:02d}  {names[task]}{qualification}", fontsize=9, weight="bold")')
appendix = replace(appendix,
    '        fig.text(.07, .885, f"{metric} {\'↓\' if metric == \'MAE\' else \'↑\'}  |  Molecular-property subgroups",\n'
    '                 fontsize=11, color="#555555")\n', '')
appendix = replace(appendix, 'bbox_to_anchor=(.95, .89)', 'bbox_to_anchor=(.96, .955)')
appendix = replace(appendix, 'ncol=3, fontsize=10, handlelength=1.4', 'ncol=3, fontsize=7.5, handlelength=1.25, columnspacing=1.2')
appendix = replace(appendix, '[.10, .405, .85, .355]', '[.10, .405, .85, .40]')
appendix = replace(appendix, 'ax.yaxis.grid(True, color="#EAEAEA", lw=.65)', 'ax.grid(False, which="both")')
appendix = replace(appendix, 'ax.tick_params(axis="x", length=0, pad=7)',
    'ax.tick_params(axis="x", length=0, pad=4, labelsize=7)\n'
    '            ax.tick_params(axis="y", length=2.5, pad=3, labelsize=7)')
appendix = replace(appendix, 'fontsize=12)', 'fontsize=8)')
appendix = replace(appendix, '(0.5, "Molecular weight")', '(0.5, "MW")')
appendix = replace(appendix, 'ha="center", fontsize=11, color="#444444"', 'ha="center", fontsize=8, color="#222222"')
appendix = replace(appendix, '            for sep in [1.825, 4.475]:\n                ax.axvline(sep, color="#D9D9D9", lw=.75, zorder=0)\n', '')
appendix = replace(appendix, 'fontsize=8.5, color="#666666"', 'fontsize=7, color="#555555"')
appendix = replace(appendix, 'fontsize=9, color="#666666"', 'fontsize=7, color="#555555"')
appendix = replace(appendix,
    'fig.text(.07, .264, "Paired difference and 95% CI: positive favors Trimole-Hybrid", fontsize=10, weight="bold")',
    'fig.text(.07, .256, "Paired difference (95% CI); positive favors Trimole-Hybrid", fontsize=7, color="#333333")')
appendix = replace(appendix, '[.07, .135, .88, .11]', '[.07, .095, .88, .135]')
appendix = replace(appendix, '[.14] + [.86 / 6] * 6, fontsize=8)', '[.14] + [.86 / 6] * 6, fontsize=7)')
appendix = replace(appendix, '                xx = x + (k - 1) * .235',
    '                rendered.extend(block.reset_index()[["task","bin","method","mean","ci_low","ci_high"]].to_dict("records"))\n'
    '                xx = x + (k - 1) * .235')
start = appendix.index('            if missing_bins:')
end = appendix.index('        pdf.savefig(fig)', start)
appendix = appendix[:start] + appendix[end:]
appendix = replace(appendix, 'dpi=300', 'dpi=600')
appendix = replace(appendix, 'dpi=110', 'dpi=160')
appendix = replace(appendix, '"pdf_page": i + 1', '"pdf_page": i')
start = appendix.index('assert len(PdfReader(')
appendix = appendix[:start] + '''assert len(PdfReader(R / "Supplementary_subgroups_all22.pdf").pages) == 22
pd.DataFrame(rendered).to_csv(R / "RENDERED_APPENDIX_DATA.csv", index=False)
'''
(R / "build_appendix.py").write_text(appendix)

caption = """# Figure captions and explanatory notes

These captions accompany the clean figures. They preserve the statistical and source qualifications from the original files; removing decorative text from the artwork does not remove these qualifications.

## Rebuttal figure: the original ten tasks

Performance of Trimole-Hybrid, MiniMol and Chemprop across molecular-property subgroups for the ten tasks shown in the original Figure 2d. The task list has not been reselected using the new comparisons. MW denotes molecular weight; the grouping thresholds are MW 300, cLogP 3 and TPSA 75. Bars show means of five run-specific metrics, except BBB (*). Error bars are percentile 95% scaffold-bootstrap confidence intervals, exploratory and unadjusted. All methods are compared on the same molecules within each subgroup. Sample sizes and, for classification, positive-class proportions are displayed below the axes.

* BBB: all three methods are scored from five-run mean predictions; the archived Trimole ensemble is used. These are ensemble metrics, not averages of run-specific AUROCs.

† Solubility: 1,995 valid structures are assigned to subgroups; two unparseable structures are unassigned.

Bars without error bars have insufficient subgroup support for interval reporting. Paired differences, scaffold-cluster counts and all 22 tasks are provided in the supplementary figure and accompanying data.

## Supplementary figure: all 22 tasks

Each page retains one task, the three models, six subgroups, sample counts, scaffold-cluster counts, classification prevalence where applicable, and the paired-difference table. Page numbers correspond to APPENDIX_PAGE_INDEX.csv. Intervals and point estimates are unchanged.

"""
caption += "\n\n".join(f"### {title}\n\n{body}" for title, body in guide)
caption += """

### Task-specific notes

- HIA: Chemprop used the existing validation-only checkpoint tie-break correction, with all five seeds retained.
- BBB (*): the archived five-run ensemble is used; all three methods are scored from mean predictions, not mean run AUROC.
- Solubility (†): 1,995/1,997 molecules are covered; two invalid structures are unassigned. No replacement predictions were created.
- Half-life: Chemprop used the existing validation-selected log-target MSE configuration; all five seeds were retained.
- The exact reasons for withheld intervals are retained in PAIRED_SUBGROUP_RESULTS.csv and listed below.

"""
import pandas as pd
pairs = pd.read_csv(R / "PAIRED_SUBGROUP_RESULTS.csv").fillna({"reason": ""})
for _, row in pairs.loc[pairs.status.eq("withheld"), ["task", "bin", "reason"]].drop_duplicates().iterrows():
    caption += f"- `{row.task}`, `{row['bin']}`: {row.reason}.\n"
(R / "CAPTIONS_EN.md").write_text(caption)
(R / "CHANGELOG_CN.md").write_text("""# 亚组图论文排版版 v11

仅调整用户提供的两份 v10 图的排版，来源 PDF 已逐字节核对。原文件全部保留。

- 删除绘图区横向网格和两条竖向分隔线，保留坐标轴和必要的零基线。
- 删除页顶总标题、重复副标题、页脚长段说明；任务名保留为小号面板标识，MW/cLogP/TPSA 保留为分组轴标签。
- 保留原实心绿/紫/浅绿配色、柱图、任务顺序和模型顺序。
- 按 7.2 英寸双栏宽度重新设置字号（最小 7 pt）、线宽和边距；10 任务图仍为 5×2 布局。
- 附录仍每页一个任务，移除说明封面后共 22 页；配对差值表改为无竖线的三线表。
- 原长图注、BBB 统计口径、溶解度覆盖范围、置信区间定义和缺失原因移入 CAPTIONS_EN.md，需随图使用。
- 直接读取已保存的结果。均值、区间、样本量、阳性率、配对差值均不重算，没有训练、推理、评估或 bootstrap。

交付含矢量 PDF/SVG 和 600 dpi PNG。QA_RECEIPT.json 记录输入哈希、逐值核对和版面检查。
""")
(R / "QA_RECEIPT.json").write_text(json.dumps({
    "source_sha256": hashes,
    "operation": "Style-only replot from saved result tables",
    "training": False, "inference": False, "evaluation": False, "bootstrap": False,
    "expected_rebuttal_tasks": 10, "expected_appendix_tasks": 22,
    "expected_rebuttal_bars": 180, "expected_appendix_bars": 396,
    "notes_moved_to": "CAPTIONS_EN.md",
    "original_files_overwritten": False,
}, indent=2))
print(R)
