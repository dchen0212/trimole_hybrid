from pathlib import Path
import hashlib,json,shutil
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator,FormatStrFormatter

R=Path(__file__).resolve().parent
source=R/"ORIGINAL_TEN_TASK_SUBGROUP_SOURCE.csv"
original=pd.read_csv(source)
tasks=original.task.drop_duplicates().tolist()
assert len(tasks)==10

names={"ames":"AMES","bbb_martins":"BBB","hia_hou":"HIA","pgp_broccatelli":"P-gp",
       "solubility_aqsoldb":"Solubility","ppbr_az":"PPBR",
       "clearance_hepatocyte_az":"Hepatocyte clearance",
       "clearance_microsome_az":"Microsome clearance",
       "cyp2d6_substrate_carbonmangels":"CYP2D6 substrate",
       "cyp3a4_substrate_carbonmangels":"CYP3A4 substrate"}
d=pd.read_csv(R/"PLOT_DATA_ALL22.csv")
models=[("Trimole-Hybrid","#2E8B57"),("MiniMol","#B99AD8"),("Chemprop","#82C49A")]
bins=["MW<300","MW>=300","cLogP<3","cLogP>=3","TPSA<75","TPSA>=75"]
thresholds=["< 300","≥ 300","< 3","≥ 3","< 75","≥ 75"]
x=np.array([0,1,2.65,3.65,5.3,6.3])
plt.rcParams.update({"font.family":"sans-serif","font.sans-serif":["Arial"],
    "font.size":8,"axes.grid":False,"axes.spines.top":False,"axes.spines.right":False,
    "axes.linewidth":.8,"legend.frameon":False,"pdf.fonttype":42,"svg.fonttype":"none"})

rendered=[]
def draw(fig,chosen,rows,split=False):
    handles=[Patch(facecolor=c,label=n) for n,c in models]
    fig.legend(handles=handles,loc="upper center",bbox_to_anchor=(.52,.995),ncol=3,fontsize=8)
    top=.94;bottom=.035
    slot=(top-bottom)/rows
    for i,task in enumerate(chosen):
        left=.075 if i%2==0 else .565
        yy=top-(i//2+1)*slot+.045
        ax=fig.add_axes([left,yy,.405,slot-.078])
        part=d[d.task==task]
        meta=part[part.method=="Trimole-Hybrid"].set_index("bin").loc[bins]
        metric=meta.metric.iloc[0]
        vals=part[["mean","ci_low","ci_high"]].to_numpy();finite=vals[np.isfinite(vals)]
        low=min(0,float(finite.min()));high=max(0,float(finite.max()))
        if metric in ["AUROC","AUPRC"]:
            ax.set_ylim(0,1.05);ax.set_yticks([0,.5,1])
        else:
            pad=max((high-low)*.10,.02)
            ax.set_ylim(low-pad if low<0 else 0,high+pad)
            ax.yaxis.set_major_locator(MaxNLocator(nbins=3))
        ax.yaxis.set_major_formatter(FormatStrFormatter("%.2f"))
        ax.set_xlim(-.65,6.95)
        title=names[task]+(" *" if task=="bbb_martins" else " †" if task=="solubility_aqsoldb" else "")
        ax.set_title(f"{chr(97+tasks.index(task))}   {title}",loc="left",fontsize=8.5,weight="bold",pad=14)
        ax.set_ylabel(f"{metric} {'↓' if metric=='MAE' else '↑'}",fontsize=8)
        ax.set_xticks(x,thresholds)
        ax.tick_params(axis="x",length=0,pad=4,labelsize=7)
        ax.tick_params(axis="y",length=2.5,pad=3,labelsize=7)
        ax.grid(False, which="both")
        for middle,label in [(0.5,"MW"),(3.15,"cLogP"),(5.8,"TPSA")]:
            ax.text(middle,1.04,label,transform=ax.get_xaxis_transform(),ha="center",fontsize=7.5,color="#222222")
        for k,(method,color) in enumerate(models):
            block=part[part.method==method].set_index("bin").loc[bins]
            rendered.extend(block.reset_index()[["task","bin","method","mean","ci_low","ci_high"]].to_dict("records"))
            xx=x+(k-1)*.235
            ax.bar(xx,block["mean"],width=.205,color=color,edgecolor="none",zorder=2)
            lo,hi=block.ci_low.to_numpy(),block.ci_high.to_numpy()
            good=np.isfinite(lo)&np.isfinite(hi)
            assert np.all(lo[good]>=ax.get_ylim()[0]) and np.all(hi[good]<=ax.get_ylim()[1])
            ax.vlines(xx[good],lo[good],hi[good],color="#4B4B4B",lw=.9,zorder=3)
            ax.hlines(lo[good],xx[good]-.04,xx[good]+.04,color="#4B4B4B",lw=.8)
            ax.hlines(hi[good],xx[good]-.04,xx[good]+.04,color="#4B4B4B",lw=.8)
        for row,(label,values) in enumerate([
            ("n",[str(int(n)) for n in meta.n]),
            ("Positive",[f"{p*100:.1f}%" for p in meta.prevalence])]):
            if row and not meta.prevalence.notna().all():continue
            pos=-.235-row*.135
            ax.text(-.035,pos,label,transform=ax.transAxes,ha="right",va="center",fontsize=7,color="#555555")
            for xx,value in zip(x,values):
                ax.text(xx,pos,value,transform=ax.get_xaxis_transform(),ha="center",va="center",fontsize=7,color="#555555")

fig=plt.figure(figsize=(7.2,9.6))
draw(fig,tasks,5)
fig.savefig(R/"Rebuttal_subgroups_original10.pdf")
fig.savefig(R/"Rebuttal_subgroups_original10.svg")
fig.savefig(R/"Rebuttal_subgroups_original10.png",dpi=600)
fig.savefig(R/"Rebuttal_subgroups_original10_preview.png",dpi=180)
plt.close(fig)
subset=d[d.task.isin(tasks)]
assert len(subset)==180 and subset["mean"].notna().all()
subset.to_csv(R/"PLOT_DATA_REBUTTAL10.csv",index=False)
pd.DataFrame({"task":tasks,"display_name":[names[t] for t in tasks],
              "selection_reason":"Same task list as original Figure 2d; not reselected on new results"}).to_csv(R/"REBUTTAL_TASK_LIST.csv",index=False)
pd.DataFrame(rendered).to_csv(R/"RENDERED_REBUTTAL_DATA.csv",index=False)
