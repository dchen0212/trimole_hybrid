from pathlib import Path
import hashlib
import json
import shutil
import textwrap

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from matplotlib.patches import Patch
from matplotlib.ticker import MaxNLocator
import numpy as np
import pandas as pd
from pypdf import PdfReader, PdfWriter, Transformation
from pypdf.generic import RectangleObject

R = Path(__file__).resolve().parent
df = pd.read_csv(R / "PAIRED_SUBGROUP_RESULTS.csv").fillna({"reason": ""})
counts = pd.read_csv(R / "SUBGROUP_COUNTS.csv")
tasks = list(counts.task.drop_duplicates())
assert len(tasks) == 22 and len(df) == 264 and len(counts) == 132
names = {
    "bioavailability_ma": "Bioavailability", "caco2_wang": "Caco-2",
    "hia_hou": "HIA", "lipophilicity_astrazeneca": "Lipophilicity",
    "pgp_broccatelli": "P-gp", "bbb_martins": "BBB", "ppbr_az": "PPBR",
    "vdss_lombardo": "VDss", "cyp2c9_substrate_carbonmangels": "CYP2C9 substrate",
    "cyp2c9_veith": "CYP2C9 inhibition",
    "cyp2d6_substrate_carbonmangels": "CYP2D6 substrate",
    "cyp2d6_veith": "CYP2D6 inhibition",
    "cyp3a4_substrate_carbonmangels": "CYP3A4 substrate",
    "cyp3a4_veith": "CYP3A4 inhibition",
    "clearance_hepatocyte_az": "Hepatocyte clearance",
    "clearance_microsome_az": "Microsome clearance",
    "half_life_obach": "Half-life", "ames": "AMES", "dili": "DILI",
    "herg": "hERG", "ld50_zhu": "LD50", "solubility_aqsoldb": "Solubility",
}
unresolved = {}

models = [
    ("trimole", "Trimole-Hybrid", "#2E8B57"),
    ("minimol", "MiniMol", "#B99AD8"),
    ("chemprop", "Chemprop", "#82C49A"),
]
bins = ["MW<300", "MW>=300", "cLogP<3", "cLogP>=3", "TPSA<75", "TPSA>=75"]
shortlabels = ["< 300", "≥ 300", "< 3", "≥ 3", "< 75", "≥ 75"]
tablelabels = ["MW < 300", "MW ≥ 300", "cLogP < 3", "cLogP ≥ 3", "TPSA < 75", "TPSA ≥ 75"]
x = np.array([0, 1, 2.65, 3.65, 5.3, 6.3])
plt.rcParams.update({
    "font.family": "sans-serif", "font.sans-serif": ["Arial"],
    "font.size": 8, "axes.grid": False, "axes.spines.right": False, "axes.spines.top": False,
    "axes.linewidth": .8, "legend.frameon": False,
    "pdf.fonttype": 42, "svg.fonttype": "none",
})
(R / "task_figures").mkdir(exist_ok=True)
(R / "previews").mkdir(exist_ok=True)

plot = pd.read_csv(R / "PLOT_DATA_ALL22.csv").fillna({"reason": ""})
assert len(plot) == 396 and plot["mean"].notna().all()
rendered = []
page_index = []
def styled_table(ax, celltext, labels, widths, fontsize=8):
    ax.axis("off")
    table = ax.table(cellText=celltext, colLabels=labels, colWidths=widths,
                     cellLoc="center", loc="center", bbox=[0, 0, 1, 1])
    table.auto_set_font_size(False)
    table.set_fontsize(fontsize)
    for (r, c), cell in table.get_celld().items():
        cell.set_edgecolor("#555555")
        cell.set_linewidth(.45)
        cell.visible_edges = "TB" if r == 0 else ("B" if r == len(celltext) else "")
        cell.set_facecolor("white")
        if r == 0:
            cell.set_text_props(weight="normal")
    return table

with PdfPages(R / "Supplementary_subgroups_all22.pdf") as pdf:
    for i, task in enumerate(tasks, 1):
        part = plot[plot.task == task]
        meta = counts[counts.task == task].set_index("bin").loc[bins]
        metric = part.metric.iloc[0]
        paired = df[df.task == task]
        fig = plt.figure(figsize=(7.2, 5.3))
        qualification = " *" if task == "bbb_martins" else " †" if task == "solubility_aqsoldb" else ""
        fig.text(.07, .95, f"{i:02d}  {names[task]}{qualification}", fontsize=9, weight="bold")
        handles = [Patch(facecolor=co, label=nm) for _, nm, co in models]
        fig.legend(handles=handles, loc="center right", bbox_to_anchor=(.96, .955),
                   ncol=3, fontsize=7.5, handlelength=1.25, columnspacing=1.2)
        if task in unresolved:
            assert part[part.method == "Trimole-Hybrid"]["mean"].isna().all()
            fig.text(.07, .76, "Matched performance comparison unavailable", fontsize=15, weight="bold", color="#555555")
            fig.text(.07, .70, textwrap.fill(unresolved[task], width=105),
                     fontsize=12, va="top", linespacing=1.5)
            fig.text(.07, .56,
                     "Subgroup composition and available baseline means are retained below. No alternative\n"
                     "prediction set is substituted for Trimole-Hybrid; matched differences are unavailable.",
                     fontsize=11, linespacing=1.5)
            celltext = [
                ["Molecules"] + [str(int(n)) for n in meta.n],
                ["Scaffold clusters"] + [str(int(n)) for n in meta.clusters],
            ]
            if meta.prevalence.notna().all():
                celltext += [["Positive (%)"] + [f"{p * 100:.1f}" for p in meta.prevalence]]
            celltext += [["Trimole-Hybrid"] + ["Unavailable"] * 6]
            for _, name, _ in models[1:]:
                values = part[part.method == name].set_index("bin").loc[bins, "mean"]
                celltext += [[name] + [f"{v:.3f}" for v in values]]
            styled_table(fig.add_axes([.07, .25, .88, .25]), celltext,
                         [""] + tablelabels, [.18] + [.82 / 6] * 6, fontsize=9)
            fig.text(.07, .17, "Status: source verification pending for all six subgroups and both comparators.",
                     fontsize=10, color="#555555")
            fig.text(.07, .12, task, fontsize=8, color="#777777")
        else:
            ax = fig.add_axes([.10, .405, .85, .40])
            ax.set_xlim(-.65, 6.95)
            vals = part[["mean", "ci_low", "ci_high"]].to_numpy()
            finite = vals[np.isfinite(vals)]
            bottom = min(0., finite.min())
            top = max(0., finite.max())
            pad = max((top - bottom) * .12, .04)
            if metric in ["AUROC", "AUPRC"]:
                ax.set_ylim(0, 1.08)
                ax.set_yticks([0, .25, .5, .75, 1.0])
            elif metric == "Spearman":
                ax.set_ylim(bottom - (pad if bottom < 0 else 0), min(1.08, top + pad))
                ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
            else:
                ax.set_ylim(0, top + pad)
                ax.yaxis.set_major_locator(MaxNLocator(nbins=5))
            ax.set_axisbelow(True)
            ax.grid(False, which="both")
            ax.set_xticks(x, shortlabels)
            ax.tick_params(axis="x", length=0, pad=4, labelsize=7)
            ax.tick_params(axis="y", length=2.5, pad=3, labelsize=7)
            ax.set_ylabel(f"{metric} {'↓' if metric == 'MAE' else '↑'}", fontsize=8)
            if bottom < 0:
                ax.axhline(0, color="#999999", lw=.7)
            for pos, title in [(0.5, "MW"), (3.15, "cLogP"), (5.8, "TPSA")]:
                ax.text(pos, 1.04, title, transform=ax.get_xaxis_transform(),
                        ha="center", fontsize=8, color="#222222")
            for k, (_, name, color) in enumerate(models):
                block = part[part.method == name].set_index("bin").loc[bins]
                rendered.extend(block.reset_index()[["task","bin","method","mean","ci_low","ci_high"]].to_dict("records"))
                xx = x + (k - 1) * .235
                ax.bar(xx, block["mean"], width=.205, color=color, edgecolor="none", zorder=2)
                lo, hi = block.ci_low.to_numpy(), block.ci_high.to_numpy()
                good = np.isfinite(lo) & np.isfinite(hi)
                assert np.all(lo[good] >= ax.get_ylim()[0])
                assert np.all(hi[good] <= ax.get_ylim()[1])
                ax.vlines(xx[good], lo[good], hi[good], color="#4B4B4B", lw=1, zorder=3)
                ax.hlines(lo[good], xx[good] - .04, xx[good] + .04, color="#4B4B4B", lw=.8)
                ax.hlines(hi[good], xx[good] - .04, xx[good] + .04, color="#4B4B4B", lw=.8)
            for j, (label, values) in enumerate([
                ("n", [f"{int(n):,}" for n in meta.n]),
                ("Clusters", [f"{int(n):,}" for n in meta.clusters]),
                ("Positive", [f"{p * 100:.1f}%" for p in meta.prevalence]),
            ]):
                if label == "Positive" and not meta.prevalence.notna().all():
                    continue
                yy = -.15 - j * .075
                ax.text(-.025, yy, label, transform=ax.transAxes, ha="right",
                        va="center", fontsize=7, color="#555555")
                for xx, value in zip(x, values):
                    ax.text(xx, yy, value, transform=ax.get_xaxis_transform(),
                            ha="center", va="center", fontsize=7, color="#555555")
            missing_bins = paired[paired.status == "withheld"].bin.unique().tolist()
            fig.text(.07, .256, "Paired difference (95% CI); positive favors Trimole-Hybrid", fontsize=7, color="#333333")
            celltext = []
            for comp, label in [("minimol", "vs MiniMol"), ("chemprop", "vs Chemprop")]:
                rowtext = [label]
                for bn in bins:
                    row = paired[(paired.bin == bn) & (paired.comparator == comp)].iloc[0]
                    value = f"{row.delta_favors_trimole:+.3f}"
                    if row.status == "interval":
                        value += f"\n[{row.ci_low:+.3f}, {row.ci_high:+.3f}]"
                    else:
                        value += "\nCI unavailable"
                    rowtext.append(value)
                celltext.append(rowtext)
            styled_table(fig.add_axes([.07, .095, .88, .135]), celltext,
                         [""] + tablelabels, [.14] + [.86 / 6] * 6, fontsize=7)
        pdf.savefig(fig)
        stem = f"{i:02d}_{task}"
        fig.savefig(R / f"task_figures/{stem}.svg")
        fig.savefig(R / f"task_figures/{stem}.png", dpi=600)
        fig.savefig(R / f"previews/{stem}.png", dpi=160)
        plt.close(fig)
        page_index.append({
            "pdf_page": i, "task": task, "display_name": names[task],
            "metric": metric, "status": "source_unresolved" if task in unresolved else "available",
            "paired_intervals": int(paired.status.eq("interval").sum()),
            "withheld_intervals": int(paired.status.eq("withheld").sum()),
        })
        print(f"Saved task {i}/22: {task}", flush=True)

pd.DataFrame(page_index).to_csv(R / "APPENDIX_PAGE_INDEX.csv", index=False)
assert len(PdfReader(R / "Supplementary_subgroups_all22.pdf").pages) == 22
pd.DataFrame(rendered).to_csv(R / "RENDERED_APPENDIX_DATA.csv", index=False)
