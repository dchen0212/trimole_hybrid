from pathlib import Path
import hashlib
import json
import re
import zipfile
import numpy as np
import pandas as pd
from PIL import Image, ImageDraw
from pypdf import PdfReader

R = Path(__file__).resolve().parent
SRC = R.parent / "rebuttal10_subgroup_all22_20261020_v10"
q = json.loads((R / "QA_RECEIPT.json").read_text())
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
assert all(sha(Path(p)) == value for p, value in q["source_sha256"].items())

for name in ["PLOT_DATA_ALL22.csv", "PAIRED_SUBGROUP_RESULTS.csv", "SUBGROUP_COUNTS.csv"]:
    assert (R / name).read_bytes() == (SRC / name).read_bytes()
keys = ["task", "bin", "method"]
numeric = ["mean", "ci_low", "ci_high"]
for rendered, ref, n in [
    ("RENDERED_REBUTTAL_DATA.csv", "PLOT_DATA_REBUTTAL10.csv", 180),
    ("RENDERED_APPENDIX_DATA.csv", "PLOT_DATA_ALL22.csv", 396),
]:
    got = pd.read_csv(R / rendered).set_index(keys).sort_index()[numeric]
    want = pd.read_csv(SRC / ref).set_index(keys).sort_index()[numeric]
    assert len(got) == n and not got.index.duplicated().any()
    pd.testing.assert_frame_equal(got, want, check_exact=False, rtol=0, atol=1e-14)

index = pd.read_csv(R / "APPENDIX_PAGE_INDEX.csv")
old_index = pd.read_csv(SRC / "APPENDIX_PAGE_INDEX.csv")
assert index.task.tolist() == old_index.task.tolist()
assert index.pdf_page.tolist() == list(range(1, 23))
assert index.paired_intervals.sum() == 248 and index.withheld_intervals.sum() == 16
pd.testing.assert_frame_equal(
    pd.read_csv(R / "REBUTTAL_TASK_LIST.csv"),
    pd.read_csv(SRC / "REBUTTAL_TASK_LIST.csv"))

pdf_checks = []
for name, expected_pages in [("Rebuttal_subgroups_original10.pdf", 1), ("Supplementary_subgroups_all22.pdf", 22)]:
    pdf = PdfReader(R / name)
    assert len(pdf.pages) == expected_pages
    font_sizes = []
    for i, page in enumerate(pdf.pages):
        assert np.isclose(float(page.mediabox.width), 7.2 * 72)
        assert len(page.images) == 0
        def visitor(text, cm, tm, font, size):
            if text.strip():
                font_sizes.append(size)
        text = page.extract_text(visitor_text=visitor)
        for method in ["Trimole-Hybrid", "MiniMol", "Chemprop"]:
            assert method in text
        for removed in ["Performance across molecular subgroups", "Molecular-property subgroups",
                        "Saved predictions;", "All six subgroups meet"]:
            assert removed not in text
        if expected_pages == 22:
            assert index.iloc[i].display_name in text
    assert min(font_sizes) >= 7
    pdf_checks.append({"file": name, "pages": expected_pages, "vector_only": True,
                       "width_inches": 7.2, "minimum_font_pt": min(font_sizes)})

# All paired table cells, including withheld intervals, must still occur in their task page.
pairs = pd.read_csv(R / "PAIRED_SUBGROUP_RESULTS.csv")
pdf = PdfReader(R / "Supplementary_subgroups_all22.pdf")
for page, task in zip(pdf.pages, index.task):
    text = re.sub(r"\s+", "", page.extract_text()).replace("−", "-")
    for row in pairs[pairs.task == task].itertuples():
        value = f"{row.delta_favors_trimole:+.3f}"
        if row.status == "interval":
            value += f"[{row.ci_low:+.3f},{row.ci_high:+.3f}]"
        else:
            value += "CIunavailable"
        assert value in text, (task, value)

for p in [R / "Rebuttal_subgroups_original10.svg", *sorted((R / "task_figures").glob("*.svg"))]:
    content = p.read_text().lower()
    assert "#eaeaea" not in content and "#d9d9d9" not in content
    for color in ["#2e8b57", "#b99ad8", "#82c49a"]:
        assert color in content

assert Image.open(R / "Rebuttal_subgroups_original10.png").size == (4320, 5760)
assert len(list((R / "task_figures").glob("*.png"))) == 22
assert all(Image.open(p).size == (4320, 3180) for p in (R / "task_figures").glob("*.png"))
q.update({
    "source_files_unchanged": True,
    "rendered_bar_values_and_intervals_match_source": {"rebuttal": 180, "appendix": 396},
    "all_264_paired_difference_table_cells_verified": True,
    "task_order_and_sample_information_unchanged": True,
    "plot_grid_and_vertical_separators_removed": True,
    "palette_unchanged": ["#2E8B57", "#B99AD8", "#82C49A"],
    "pdf_checks": pdf_checks, "png_dpi": 600,
    "output_sha256": {name: sha(R / name) for name in
        ["Rebuttal_subgroups_original10.pdf", "Supplementary_subgroups_all22.pdf",
         "Rebuttal_subgroups_original10.png", "Rebuttal_subgroups_original10.svg", "CAPTIONS_EN.md"]},
    "visual_review": "pending",
})
(R / "QA_RECEIPT.json").write_text(json.dumps(q, indent=2))
print(json.dumps({"status": "PASS", "pdf_checks": pdf_checks, "matched_plotted_bars": 576,
                  "paired_table_cells": 264}, indent=2))
