"""Versioned FLAML historical-pool comparison and fresh target-only search.

No F selector; no test-guided search. Historical-pool limitations are inherited.
"""
import os
for _key in ('OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[_key]='1'
os.environ['CUDA_VISIBLE_DEVICES']=''
os.environ['PYTHONDONTWRITEBYTECODE']='1'
import argparse, collections, concurrent.futures, copy, csv, hashlib, json, pickle
import subprocess, sys, time, traceback
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.stats import spearmanr
from sklearn.metrics import roc_auc_score, average_precision_score, mean_absolute_error
from sklearn.model_selection import GroupKFold, StratifiedGroupKFold
ROOT=Path(__file__).resolve().parent
SOURCE=Path('/mnt/data/projects/trimole_hybrid_revision_20260915')
SEEDS=[101,202,303,404,505]
TARGETS={'clearance_hepatocyte_az':'Spearman','cyp3a4_substrate_carbonmangels':'AUROC'}
_DENY=False

def guard(event,args):
    if _DENY and event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
        p=Path(os.fsdecode(args[0]))
        if p.name in ('test.csv','test_predictions.csv','H_labels.json') or 'H_vault' in p.parts:
            raise PermissionError('TEST_ACCESS_FORBIDDEN_DURING_FIT:'+str(p))
sys.addaudithook(guard)

def sha(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''):h.update(b)
    return h.hexdigest()
def read(p):return json.loads(Path(p).read_text())
def write(p,d):
    p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
    with p.open('x') as f:json.dump(d,f,indent=2,sort_keys=True,allow_nan=False,default=lambda o:o.item() if isinstance(o,np.generic) else str(o))
def atomic(p,d):
    p=Path(p);tmp=p.with_suffix('.pending');tmp.write_text(json.dumps(d,indent=2,default=str));os.replace(tmp,p)
def binary(metric):return metric in ('AUROC','AUPRC')
def score(metric,y,p):
    y=np.asarray(y,float);p=np.asarray(p,float)
    if not np.isfinite(p).all():raise ValueError('NONFINITE_PREDICTION')
    s={'AUROC':lambda:roc_auc_score(y,p),'AUPRC':lambda:average_precision_score(y,p),'MAE':lambda:mean_absolute_error(y,p),'Spearman':lambda:spearmanr(y,p).statistic}[metric]()
    if not np.isfinite(s):raise ValueError('UNDEFINED_METRIC')
    return float(s)
def utility(metric,s):return -s if metric=='MAE' else s
def predict(model,X,metric):
    if binary(metric):
        if hasattr(model,'predict_proba'):
            return np.asarray(model.predict_proba(X))[:,list(model.classes_).index(1)]
        return np.asarray(model.decision_function(X))
    return np.asarray(model.predict(X))
def columns(frame):
    sm=next(x for x in ('Drug','smiles','SMILES','drug') if x in frame)
    label=next(x for x in ('Y','y','label','target') if x in frame)
    return sm,label

def group_keys(smiles):
    from rdkit import Chem
    from rdkit.Chem import rdMolDescriptors
    from rdkit.Chem.Scaffolds import MurckoScaffold
    groups=[]
    for s in smiles:
        m=Chem.MolFromSmiles(s)
        if m is None:raise ValueError('INVALID_DEVELOPMENT_STRUCTURE')
        fragments=Chem.GetMolFrags(m,asMols=True,sanitizeFrags=True)
        m=max(fragments,key=lambda a:(a.GetNumHeavyAtoms(),Chem.MolToSmiles(a)))
        sc=MurckoScaffold.MurckoScaffoldSmiles(mol=m,includeChirality=False)
        # Empty-scaffold molecules are grouped by parent connectivity, avoiding
        # one artificial enormous acyclic scaffold component.
        groups.append('scaffold:'+sc if sc else 'parent:'+Chem.MolToInchiKey(m).split('-')[0])
    return np.asarray(groups)
def identity_keys(smiles):
    from rdkit import Chem
    out=[]
    for s in smiles:
        m=Chem.MolFromSmiles(s)
        if m is None:raise ValueError('INVALID_DEVELOPMENT_STRUCTURE')
        m=max(Chem.GetMolFrags(m,asMols=True,sanitizeFrags=True),key=lambda a:(a.GetNumHeavyAtoms(),Chem.MolToSmiles(a)))
        out.append(Chem.MolToInchiKey(m).split('-')[0])
    return np.asarray(out)

def folds(metric,y,g,seed=101):
    cv=StratifiedGroupKFold(3,shuffle=True,random_state=seed) if binary(metric) else GroupKFold(3)
    out=list(cv.split(np.zeros((len(y),1)),y,g))
    for tr,va in out:
        assert not (set(g[tr])&set(g[va]))
        if binary(metric):assert set(y[tr])==set(y[va])=={0,1},'INVALID_FOLD_CLASSES'
    return out,cv

def baseline_fit(task,seed):
    global _DENY
    _DENY=True
    import flaml
    from flaml import AutoML
    import legacy_budget as legacy
    from sklearn.base import clone
    assert flaml.__version__=='2.7.0'
    plan=read(ROOT/'S28_SOURCE_PLAN.json');metric=plan['task_metrics'][task]
    dest=ROOT/'baseline'/task/f'seed{seed}';dest.mkdir(parents=True,exist_ok=False)
    start=time.monotonic()
    y,p,ids,audit=legacy.read_pool(plan,task,seed,'valid',plan['validation_inputs'])
    X=np.column_stack([p[f] for f in plan['candidate_pool']])
    frame=pd.read_csv(Path(plan['candidate_split_root'])/task/'valid.csv')
    sm,_=columns(frame);g=identity_keys(frame[sm].astype(str));fs,cv=folds(metric,y,g,seed)
    write(dest/'FOLDS.json',{'folds':[{'fit':a.tolist(),'validation':b.tolist()} for a,b in fs], 'grouping':'parent molecular connectivity; NOT scaffold-separated meta folds','alignment':audit})
    trace=[]
    def loss(X_val,y_val,estimator,labels,X_train,y_train,*args,**kwargs):
        try:s=score(metric,y_val,predict(estimator,X_val,metric));v=s if metric=='MAE' else 1-s
        except ValueError:s=None;v=float('inf')
        trace.append({'score':s,'fit_rows':len(y_train),'validation_rows':len(y_val)})
        return v,{'score':s if s is not None else 0.0}
    a=AutoML();from linear_adapter import register
    register(a)
    learners=['rf','extra_tree','xgboost','lgbm','catboost', 'linear_cls' if binary(metric) else 'ridge_scaled']
    search_start=time.monotonic()
    a.fit(X_train=X,y_train=y,groups=g,task='classification' if binary(metric) else 'regression',
          metric=loss,estimator_list=learners,time_budget=120,max_iter=100000,
          n_jobs=1,seed=seed,n_concurrent_trials=1,eval_method='cv',split_type=cv,n_splits=3,
          sample=False,auto_augment=False,retrain_full=False,ensemble=False,skip_transform=True,
          keep_search_state=True,log_file_name=str(dest/'search.log'),log_type='all',verbose=0,
          mlflow_logging=False,early_stop=False,hpo_method='cfo',
          custom_hp={n:{('random_seed' if n=='catboost' else 'random_state'):{'domain':seed,'init_value':seed}} for n in learners})
    search_s=time.monotonic()-search_start
    assert a.model is not None and np.isfinite(a.best_loss)
    model=copy.deepcopy(a.model);model.cleanup();model.params['thread_count' if a.best_estimator=='catboost' else 'n_jobs']=1
    params=copy.deepcopy(model.params);t=time.monotonic();model.fit(X,y,budget=None);refit_s=time.monotonic()-t
    assert params==model.params
    with (dest/'model.pkl').open('xb') as f:pickle.dump(model,f)
    write(dest/'SEAL.json',{'task':task,'seed':seed,'metric':metric,'model_sha256':sha(dest/'model.pkl'),
          'source_plan_sha256':sha(ROOT/'S28_SOURCE_PLAN.json'),'best_estimator':a.best_estimator,
          'best_config':a.best_config,'selected_params':params,'cv_loss':float(a.best_loss),
          'search_seconds':search_s,'refit_seconds':refit_s,'elapsed_seconds':time.monotonic()-start,
          'trace':trace,'test_used_by_this_search':False,'scope':'historical cached-prediction reanalysis; upstream and positional limitations inherited'})
    return {'task':task,'seed':seed,'status':'SEALED','elapsed':time.monotonic()-start}

def baseline_evaluate():
    import legacy_budget as legacy
    import run_expanded_candidate_pool_controls_v1 as common
    plan=read(ROOT/'S28_SOURCE_PLAN.json');dest=ROOT/'baseline_evaluation';dest.mkdir(exist_ok=False)
    seals={}
    for t in plan['tasks']:
        for s in SEEDS:
            p=ROOT/'baseline'/t/f'seed{s}'/'SEAL.json'
            if p.exists():seals[str(p.relative_to(ROOT))]=sha(p)
    write(dest/'FROZEN_MODELS.json',{'seals':seals,'all_fit_attempts_finished':True})
    rows=[];failures=[]
    for t in plan['tasks']:
        try:
            valid=all((ROOT/'baseline'/t/f'seed{s}'/'SEAL.json').exists() for s in SEEDS)
            if not valid:raise ValueError('INCOMPLETE_FIVE_SEEDS')
            h={str(p):sha(p) for p in legacy._input_paths({**plan,'tasks':[t]},'test')}
            idx,ey,alignment=common.build_test_alignment(legacy._split_path(plan,t,'test'),legacy._split_path(plan,t,'test',evaluation=True))
            write(dest/(t+'_alignment.json'),alignment)
            for s in SEEDS:
                d=ROOT/'baseline'/t/f'seed{s}';seal=read(d/'SEAL.json');assert sha(d/'model.pkl')==seal['model_sha256']
                ty,tp,_,audit=legacy.read_pool(plan,t,s,'test',h);assert np.allclose(ty[idx],ey,rtol=0,atol=1e-12)
                X=np.column_stack([tp[f][idx] for f in plan['candidate_pool']])
                with (d/'model.pkl').open('rb') as f:m=pickle.load(f)
                pred=predict(m,X,plan['task_metrics'][t])
                np.savez_compressed(dest/(t+f'_seed{s}_predictions.npz'),y=ey,prediction=pred,source_indices=idx)
                rows.append({'task':t,'seed':s,'metric':plan['task_metrics'][t],'score':score(plan['task_metrics'][t],ey,pred),'search_seconds':seal['search_seconds'],'refit_seconds':seal['refit_seconds']})
        except Exception as e:failures.append({'task':t,'error':repr(e),'traceback':traceback.format_exc()})
    pd.DataFrame(rows).to_csv(dest/'SEED_SCORES.csv',index=False)
    write(dest/'RESULTS.json',{'scope':'retrospective historical-pool FLAML comparison, not independent full-pipeline replication','rows':rows,'failures':failures})

def chemical_features(smiles):
    from rdkit import Chem,DataStructs,RDLogger
    from rdkit.Chem import rdFingerprintGenerator,Descriptors
    RDLogger.DisableLog('rdApp.warning')
    gens=[rdFingerprintGenerator.GetMorganGenerator(radius=r,fpSize=2048) for r in (2,3)]
    fps=[[],[]];desc=[];names=[n for n,f in Descriptors._descList]
    for s in smiles:
        m=Chem.MolFromSmiles(s)
        if m is None:raise ValueError('INVALID_STRUCTURE_NO_ROW_DROPPED')
        for i,gen in enumerate(gens):fps[i].append(gen.GetFingerprintAsNumPy(m).astype(np.float32))
        row=[]
        for n,f in Descriptors._descList:
            try:row.append(float(f(m)))
            except Exception:row.append(float('nan'))
        desc.append(row)
    d=np.asarray(desc,np.float32);d[~np.isfinite(d)]=np.nan
    f2=np.asarray(fps[0]);f3=np.asarray(fps[1])
    return {'fp2':f2,'fp3':f3,'fp2_desc':np.column_stack([f2,d]),'desc':d},names

def chemical_catalog():
    out=[]
    for feature in ['fp2','fp3','fp2_desc','desc']:
        for depth in [2,4,6]:
            for reg in [1.,10.]:out.append({'kind':'xgb','feature':feature,'depth':depth,'reg_lambda':reg,'trees':500,'rate':.035})
        for leaf in [1,3,8]:
            for kind in ['rf','et']:out.append({'kind':kind,'feature':feature,'leaf':leaf,'trees':500})
    for feature in ['fp2','fp3']:
        for c in [.01,.1,1.,10.,100.]:out.append({'kind':'tanimoto','feature':feature,'C':c})
    return [dict(id=f'candidate{i:03d}',**d) for i,d in enumerate(out)]

def tanimoto(a,b):
    z=a@b.T;den=a.sum(1)[:,None]+b.sum(1)[None,:]-z
    return np.divide(z,den,out=np.zeros_like(z),where=den>0)
def make_chemical(c,metric,seed):
    from sklearn.impute import SimpleImputer
    from sklearn.pipeline import make_pipeline
    from sklearn.ensemble import RandomForestClassifier,RandomForestRegressor,ExtraTreesClassifier,ExtraTreesRegressor
    from sklearn.svm import SVC
    from sklearn.kernel_ridge import KernelRidge
    from xgboost import XGBClassifier,XGBRegressor
    b=binary(metric)
    if c['kind']=='tanimoto':return SVC(C=c['C'],kernel='precomputed',class_weight='balanced',probability=False,random_state=seed) if b else KernelRidge(alpha=1/c['C'],kernel='precomputed')
    if c['kind']=='xgb':
        klass=XGBClassifier if b else XGBRegressor
        model=klass(n_estimators=c['trees'],max_depth=c['depth'],learning_rate=c['rate'],reg_lambda=c['reg_lambda'],min_child_weight=1,subsample=.85,colsample_bytree=.8,n_jobs=1,tree_method='hist',random_state=seed,objective='binary:logistic' if b else 'reg:squarederror',eval_metric='logloss' if b else 'rmse')
    else:
        klass=({'rf':RandomForestClassifier,'et':ExtraTreesClassifier} if b else {'rf':RandomForestRegressor,'et':ExtraTreesRegressor})[c['kind']]
        kw={'class_weight':'balanced'} if b else {}
        model=klass(n_estimators=c['trees'],min_samples_leaf=c['leaf'],max_features='sqrt' if b else .7,n_jobs=1,random_state=seed,**kw)
    return make_pipeline(SimpleImputer(strategy='median',keep_empty_features=True),model)

def chemical_prepare():
    dest=ROOT/'target_only';dest.mkdir(exist_ok=False)
    cat=chemical_catalog();write(dest/'CATALOG.json',cat)
    for task,metric in TARGETS.items():
        p=SOURCE/'data/admet_group'/task/'train_val.csv';f=pd.read_csv(p);sm,lab=columns(f)
        x,names=chemical_features(f[sm].astype(str));y=f[lab].to_numpy(float);g=group_keys(f[sm].astype(str));fs,_=folds(metric,y,g,101)
        d=dest/task;d.mkdir();np.savez_compressed(d/'development.npz',**x,y=y,groups=g)
        write(d/'INPUTS.json',{'path':str(p),'sha256':sha(p),'rows':len(y),'smiles':f[sm].astype(str).tolist(),'descriptor_names':names,'folds':[{'fit':a.tolist(),'validation':b.tolist()} for a,b in fs],'cross_task_source_rows':0,'supervised_pretrained_encoders':False,'test_labels_opened':False})

def chemical_fit(task,cid):
    global _DENY
    _DENY=True
    metric=TARGETS[task];dest=ROOT/'target_only'/task;cat=read(ROOT/'target_only/CATALOG.json');c=next(d for d in cat if d['id']==cid)
    with np.load(dest/'development.npz') as z:X=z[c['feature']];y=z['y']
    rec={'task':task,'candidate':c,'fold_scores':[]};out=dest/'candidates';out.mkdir(exist_ok=True)
    try:
        start=time.monotonic()
        for k,fold in enumerate(read(dest/'INPUTS.json')['folds']):
            tr=np.asarray(fold['fit']);va=np.asarray(fold['validation']);m=make_chemical(c,metric,101)
            a,b=X[tr],X[va]
            if c['kind']=='tanimoto':a,b=tanimoto(X[tr],X[tr]),tanimoto(X[va],X[tr])
            yy=y[tr];mu=float(yy.mean());sd=float(yy.std()) or 1.
            target=yy if binary(metric) else (yy-mu)/sd
            m.fit(a,target);pred=predict(m,b,metric)
            if not binary(metric):pred=pred*sd+mu
            rec['fold_scores'].append(score(metric,y[va],pred))
        rec.update(status='SUCCESS',cv_score=float(np.mean(rec['fold_scores'])),elapsed_seconds=time.monotonic()-start)
    except Exception as e:rec.update(status='FAILED',error=repr(e),traceback=traceback.format_exc())
    write(out/(cid+'.json'),rec);return rec

def chemical_freeze():
    selected={}
    for task,metric in TARGETS.items():
        rows=[read(p) for p in (ROOT/'target_only'/task/'candidates').glob('*.json')]
        good=[r for r in rows if r['status']=='SUCCESS'];assert good,'NO_VALID_CANDIDATE'
        best=min(good,key=lambda r:(-utility(metric,r['cv_score']),r['candidate']['id']))
        selected[task]={'selected':best,'attempted':len(rows),'successful':len(good),'selection':'mean of three development scaffold-fold metrics; lexical ties','test_used':False}
    write(ROOT/'target_only/SELECTION_FREEZE.json',selected)

def chemical_predict(task,seed):
    global _DENY
    _DENY=True
    metric=TARGETS[task];dest=ROOT/'target_only'/task;selection=read(ROOT/'target_only/SELECTION_FREEZE.json');c=selection[task]['selected']['candidate']
    with np.load(dest/'development.npz') as z:X=z[c['feature']];y=z['y']
    # Existing structure-only export; original official test CSV is denied.
    path=Path('/mnt/data/projects/trimole_dual3090_transfer_20261011_v01/staging/structures')/(task+'.json')
    hold=read(path);assert hold['labels_present'] is False
    sm=[r['raw_smiles'] for r in hold['rows']];features,_=chemical_features(sm);T=features[c['feature']]
    m=make_chemical(c,metric,seed);A=X
    if c['kind']=='tanimoto':A,T=tanimoto(X,X),tanimoto(T,X)
    mu=float(y.mean());sd=float(y.std()) or 1.;m.fit(A,y if binary(metric) else (y-mu)/sd)
    p=predict(m,T,metric)
    if not binary(metric):p=p*sd+mu
    d=dest/f'final_seed{seed}';d.mkdir(exist_ok=False)
    with (d/'model.pkl').open('xb') as f:pickle.dump(m,f)
    np.savez_compressed(d/'predictions.npz',prediction=p,source_rows=np.asarray([r['source_row'] for r in hold['rows']]),smiles=np.asarray(sm))
    write(d/'SEAL.json',{'selection_sha256':sha(ROOT/'target_only/SELECTION_FREEZE.json'),'prediction_sha256':sha(d/'predictions.npz'),'model_sha256':sha(d/'model.pkl'),'structure_export_sha256':sha(path),'seed':seed,'task':task,'test_labels_used':False,'fit_rows':len(y),'prediction_rows':len(p),'cross_task_rows':0})

def chemical_evaluate():
    rows=[]
    seals={str(p.relative_to(ROOT)):sha(p) for p in (ROOT/'target_only').glob('*/final_seed*/SEAL.json')}
    assert len(seals)==10,'REQUIRE_BOTH_TASKS_FIVE_SEEDS_BEFORE_SCORING'
    write(ROOT/'target_only/ALL_PREDICTIONS_FROZEN.json',seals)
    for task,metric in TARGETS.items():
        path=SOURCE/'data/admet_group'/task/'test.csv';f=pd.read_csv(path);sm,lab=columns(f)
        for seed in SEEDS:
            d=ROOT/'target_only'/task/f'final_seed{seed}';seal=read(d/'SEAL.json');assert sha(d/'predictions.npz')==seal['prediction_sha256']
            with np.load(d/'predictions.npz') as z:
                ix=z['source_rows'];assert f.iloc[ix][sm].astype(str).tolist()==z['smiles'].tolist()
                p=z['prediction'];y=f.iloc[ix][lab].to_numpy(float)
            rows.append({'task':task,'metric':metric,'seed':seed,'score':score(metric,y,p),'test_sha256':sha(path)})
    write(ROOT/'target_only/RESULTS.json',{'rows':rows,'scope':'new target-only development-selected chemical models; historically reused benchmark test','no_test_guided_reselection':True,'seeds_note':'deterministic kernel methods may produce identical predictions across seeds; do not imply independent stochastic fits'})
    pd.DataFrame(rows).to_csv(ROOT/'target_only/SEED_SCORES.csv',index=False)

def job(cmd,timeout,log):
    t=time.monotonic();log.parent.mkdir(parents=True,exist_ok=True)
    with log.open('xb') as f:
        p=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),*cmd],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
        try:rc=p.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            import signal
            os.killpg(p.pid,signal.SIGKILL);p.wait();rc=-9
    return {'command':cmd,'returncode':rc,'elapsed_seconds':time.monotonic()-t,'log':str(log)}

def controller(kind):
    start=time.monotonic();status={'kind':kind,'state':'RUNNING','completed':[],'start_unix':time.time()}
    p=ROOT/(kind+'_STATUS.json');assert not p.exists();atomic(p,status)
    try:
        if kind=='baseline':
            plan=read(ROOT/'S28_SOURCE_PLAN.json');jobs=[(['baseline_fit',t,str(s)],480,ROOT/'logs'/f'baseline_{t}_{s}.log') for t in plan['tasks'] for s in SEEDS]
        else:
            chemical_prepare();jobs=[(['chemical_fit',t,c['id']],180,ROOT/'logs'/f'chemical_{t}_{c["id"]}.log') for t in TARGETS for c in chemical_catalog()]
        with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
            futures=[pool.submit(job,*j) for j in jobs]
            for f in concurrent.futures.as_completed(futures):status['completed'].append(f.result());status['elapsed_seconds']=time.monotonic()-start;atomic(p,status)
        if kind=='baseline':baseline_evaluate()
        else:
            chemical_freeze()
            with concurrent.futures.ThreadPoolExecutor(max_workers=4) as pool:
                fs=[pool.submit(job,['chemical_predict',t,str(s)],180,ROOT/'logs'/f'final_{t}_{s}.log') for t in TARGETS for s in SEEDS]
                for f in concurrent.futures.as_completed(fs):status['completed'].append(f.result());atomic(p,status)
            chemical_evaluate()
        status['state']='FINISHED_REQUIRES_REVIEW'
    except Exception as e:status.update(state='FAILED',error=repr(e),traceback=traceback.format_exc())
    status['elapsed_seconds']=time.monotonic()-start;atomic(p,status)

def selftest():
    import flaml
    from flaml import AutoML
    rng=np.random.RandomState(9);X=rng.normal(size=(90,9));g=np.repeat(np.arange(30),3)
    outcomes={}
    for metric in ['AUROC','AUPRC','MAE','Spearman']:
        y=(X[:,0]+rng.normal(size=90)*.5>0).astype(float) if binary(metric) else X[:,0]+rng.normal(size=90)*.5
        fs,cv=folds(metric,y,g,101)
        def loss(Xv,yv,est,labels,Xt,yt,*args,**kwargs):
            s=score(metric,yv,predict(est,Xv,metric));return s if metric=='MAE' else 1-s,{'metric':s}
        a=AutoML();a.fit(X_train=X,y_train=y,groups=g,task='classification' if binary(metric) else 'regression',metric=loss,estimator_list=['rf','extra_tree','xgboost'],time_budget=10,max_iter=3,n_jobs=1,seed=101,eval_method='cv',split_type=cv,n_splits=3,sample=False,auto_augment=False,retrain_full=False,ensemble=False,skip_transform=True,verbose=0,mlflow_logging=False)
        assert np.isfinite(a.best_loss);m=copy.deepcopy(a.model);m.cleanup();m.fit(X,y,budget=None);assert np.isfinite(predict(m,X,metric)).all()
        outcomes[metric]={'loss':a.best_loss,'estimator':a.best_estimator}
    global _DENY
    _DENY=True
    try:
        open('/tmp/test.csv')
        raise AssertionError('guard did not reject')
    except PermissionError:pass
    _DENY=False
    write(ROOT/'SELFTEST_v02.json',{'status':'PASS','four_metrics':outcomes,'test_read_guard':'PASS','flaml':flaml.__version__})

if __name__=='__main__':
    mode=sys.argv[1]
    if mode=='baseline_fit':baseline_fit(sys.argv[2],int(sys.argv[3]))
    elif mode=='chemical_fit':chemical_fit(sys.argv[2],sys.argv[3])
    elif mode=='chemical_predict':chemical_predict(sys.argv[2],int(sys.argv[3]))
    elif mode=='controller':controller(sys.argv[2])
    elif mode=='selftest':selftest()
    else:raise ValueError(mode)
