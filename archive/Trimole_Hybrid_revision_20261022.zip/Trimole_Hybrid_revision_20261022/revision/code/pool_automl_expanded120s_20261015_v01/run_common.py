import os,sys,time,json,subprocess,concurrent.futures,hashlib,signal
from pathlib import Path
R=Path(__file__).resolve().parent
if sys.argv[1]=='fit':
 import controls,experiment_v02 as e
 controls.fit(sys.argv[2],int(sys.argv[3]));e.baseline_fit(sys.argv[2],int(sys.argv[3]));sys.exit()
import experiment_v02 as e
assert e.read(R/'SMOKE_PASS.json')['status']=='PASS'
assert not (R/'RUN_FREEZE.json').exists()
plan=e.read(R/'S28_SOURCE_PLAN.json')
import legacy_budget as legacy
legacy.verify_hashes(plan['validation_inputs'])
e.write(R/'RUN_FREEZE.json',{'time':time.time(),'code':{p.name:e.sha(p) for p in R.glob('*.py')},'protocol_sha256':e.sha(R/'PROTOCOL.md'),'plan_sha256':e.sha(R/'S28_SOURCE_PLAN.json'),'prior_test_exposure':True})
state={'stage':'FITTING','completed':[],'start':time.time()}
def save():e.atomic(R/'STATUS.json',state)
def job(t,s):
 d=R/'logs';d.mkdir(exist_ok=True);start=time.time()
 with (d/f'{t}_{s}.log').open('xb') as f:
  p=subprocess.Popen([sys.executable,'-B',__file__,'fit',t,str(s)],stdout=f,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=p.wait(timeout=600)
  except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL);p.wait();rc=-9
 return {'task':t,'seed':s,'returncode':rc,'seconds':time.time()-start}
save()
try:
 with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
  fs=[pool.submit(job,t,s) for t in plan['tasks'] for s in e.SEEDS]
  for f in concurrent.futures.as_completed(fs):
   result=f.result();state['completed'].append(result);save();print(result,flush=True)
 if any(z['returncode'] for z in state['completed']):raise RuntimeError('FIT_FAILURES: scoring not started; inspect logs')
 state['stage']='SCORING';save()
 import controls
 controls.evaluate();e.baseline_evaluate()
 auto=e.read(R/'baseline_evaluation/RESULTS.json');assert len(auto['rows'])==110 and not auto['failures']
 rows=e.read(R/'controls_evaluation/RESULTS.json')['rows']+[{**z,'method':'flaml_expanded120s'} for z in auto['rows']]
 df=e.pd.DataFrame(rows);df.to_csv(R/'COMMON_POOL_SEED_SCORES.csv',index=False)
 summary=df.groupby(['task','metric','method']).score.agg(['mean',lambda x:x.std(ddof=0),'count']).reset_index();summary.columns=['task','metric','method','mean','population_sd','n'];summary.to_csv(R/'COMMON_POOL_SUMMARY.csv',index=False)
 assert len(rows)==660 and len(summary)==132 and (summary.n==5).all()
 search_audit=[]
 for log in (R/'baseline').glob('*/*/search.log'):
  records=[json.loads(line) for line in log.read_text().splitlines()]
  records=[z for z in records if 'learner' in z]
  search_audit.append({'path':str(log.relative_to(R)),'attempted_learners':sorted(set(z['learner'] for z in records)),'trials':len(records),'best_record':min(records,key=lambda z:z['validation_loss'])})
 e.write(R/'SEARCH_AUDIT.json',{'runs':search_audit,'models_share_fixed_prediction_pool':True,'main_table_is_separate_reference':True})
 state['stage']='COMPLETE';save()
except Exception as ex:
 state['stage']='FAILED';state['error']=repr(ex);save();raise
