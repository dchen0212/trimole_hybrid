import json,pickle,time
import numpy as np
from scipy.stats import rankdata
import experiment_v02 as e
import legacy_budget as legacy
from linear_adapter import logistic_factory,ridge_factory

def fit(task,seed):
    e._DENY=True
    plan=e.read(e.ROOT/'S28_SOURCE_PLAN.json');metric=plan['task_metrics'][task]
    y,p,ids,audit=legacy.read_pool(plan,task,seed,'valid',plan['validation_inputs'])
    names=plan['candidate_pool'];X=np.column_stack([p[n] for n in names])
    frame=e.pd.read_csv(e.Path(plan['candidate_split_root'])/task/'valid.csv');sm,_=e.columns(frame)
    folds,_=e.folds(metric,y,e.identity_keys(frame[sm].astype(str)),seed)
    ordering=sorted(range(len(names)),key=lambda i:(-e.utility(metric,e.score(metric,y,X[:,i])),names[i]))
    maker=logistic_factory if e.binary(metric) else ridge_factory
    grid=[1e-4,1e-3,.01,.1,1.,10.,100.,1000.,10000.]
    traces=[]
    for value in grid:
        cfg={'C':value,'random_state':seed} if e.binary(metric) else {'alpha':value}
        scores=[]
        for tr,va in folds:
            m=maker(**cfg);m.fit(X[tr],y[tr]);scores.append(e.score(metric,y[va],e.predict(m,X[va],metric)))
        traces.append({'config':cfg,'cv_score':float(np.mean(scores))})
    best=max(traces,key=lambda z:e.utility(metric,z['cv_score']))
    tuned=maker(**best['config']);tuned.fit(X,y)
    fixed=maker();fixed.fit(X,y)
    d=e.ROOT/'controls'/task/f'seed{seed}';d.mkdir(parents=True,exist_ok=False)
    with (d/'models.pkl').open('xb') as f:pickle.dump({'stacking_fixed':fixed,'stacking_tuned':tuned},f)
    e.write(d/'SEAL.json',{'task':task,'seed':seed,'metric':metric,'pool':names,'ordering':ordering,'audit':audit,'stacking_grid':traces,'selected':best,'model_sha256':e.sha(d/'models.pkl'),'folds':[{'fit':a.tolist(),'valid':b.tolist()} for a,b in folds]})

def evaluate():
    import run_expanded_candidate_pool_controls_v1 as common
    e._DENY=False
    plan=e.read(e.ROOT/'S28_SOURCE_PLAN.json');dest=e.ROOT/'controls_evaluation';dest.mkdir(exist_ok=False)
    seals={str(p.relative_to(e.ROOT)):e.sha(p) for p in (e.ROOT/'controls').glob('*/*/SEAL.json')}
    assert len(seals)==110
    e.write(dest/'ACCESS_STARTED.json',{'seals':seals,'time':time.time()})
    rows=[]
    for task in plan['tasks']:
        metric=plan['task_metrics'][task]
        idx,y,alignment=common.build_test_alignment(legacy._split_path(plan,task,'test'),legacy._split_path(plan,task,'test',evaluation=True))
        e.write(dest/(task+'_alignment.json'),alignment)
        hashes={str(p):e.sha(p) for p in legacy._input_paths({**plan,'tasks':[task]},'test')}
        for seed in e.SEEDS:
            d=e.ROOT/'controls'/task/f'seed{seed}';s=e.read(d/'SEAL.json');assert e.sha(d/'models.pkl')==s['model_sha256']
            yy,p,_,_=legacy.read_pool(plan,task,seed,'test',hashes);assert np.allclose(yy[idx],y,rtol=0,atol=1e-12)
            X=np.column_stack([p[n][idx] for n in s['pool']]);A=np.column_stack([rankdata(X[:,i],method='average')/len(X) for i in range(9)]) if metric=='Spearman' else X
            preds={'single_valid':X[:,s['ordering'][0]],'uniform':A.mean(axis=1),'top3_valid':A[:,s['ordering'][:3]].mean(axis=1)}
            with (d/'models.pkl').open('rb') as f:models=pickle.load(f)
            preds.update({k:e.predict(m,X,metric) for k,m in models.items()})
            for method,pred in preds.items():
                rows.append({'task':task,'seed':seed,'metric':metric,'method':method,'score':e.score(metric,y,pred)})
                np.savez_compressed(dest/f'{task}_{seed}_{method}.npz',y=y,prediction=pred,source_indices=idx)
    e.pd.DataFrame(rows).to_csv(dest/'SEED_SCORES.csv',index=False);e.write(dest/'RESULTS.json',{'rows':rows})
