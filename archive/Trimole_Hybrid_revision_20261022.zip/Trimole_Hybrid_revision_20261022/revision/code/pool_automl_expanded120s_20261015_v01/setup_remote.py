from pathlib import Path
import json,shutil
old=Path('/mnt/data/projects/trimole_pool_automl_60s_20261013_v02'); new=Path('/mnt/data/projects/trimole_pool_automl_expanded120s_20261015_v01');new.mkdir(exist_ok=False)
for n in ['experiment_v02.py','legacy_budget.py','run_common_pool_fair_comparison_v1.py','run_expanded_candidate_pool_controls_v1.py','S28_SOURCE_PLAN.json','ENVIRONMENT.json']:
 shutil.copy2(old/n,new/n)
p=new/'ENVIRONMENT.json'; c=json.loads(p.read_text());c['environment']={k:v.replace(str(old),str(new)) for k,v in c['environment'].items()};p.write_text(json.dumps(c,indent=2))
p=new/'experiment_v02.py';s=p.read_text();s=s.replace('a=AutoML();search_start=time.monotonic()',"a=AutoML();from linear_adapter import register\n    register(a)\n    learners=['rf','extra_tree','xgboost','lgbm','catboost', 'linear_cls' if binary(metric) else 'ridge_scaled']\n    search_start=time.monotonic()")
s=s.replace("metric=loss,estimator_list=['rf','extra_tree','xgboost'],time_budget=60,max_iter=100000,","metric=loss,estimator_list=learners,time_budget=120,max_iter=100000,")
s=s.replace("for n in ['rf','extra_tree','xgboost']})","for n in learners})")
s=s.replace("],240,ROOT/'logs'", "],480,ROOT/'logs'").replace('max_workers=6','max_workers=2')
p.write_text(s)
print(new)
