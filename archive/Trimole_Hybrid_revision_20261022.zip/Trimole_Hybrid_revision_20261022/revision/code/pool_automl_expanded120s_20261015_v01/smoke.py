import experiment_v02 as e
import numpy as np, pickle
from flaml import AutoML
from linear_adapter import register
import importlib.metadata as md
from sklearn.metrics import roc_auc_score,average_precision_score,mean_absolute_error
from scipy.stats import spearmanr
import importlib
versions={n:{'version':getattr(importlib.import_module(n),'__version__','unknown'),'path':importlib.import_module(n).__file__} for n in ['flaml','lightgbm','catboost','xgboost','sklearn']}
print(versions,flush=True)
if (e.ROOT/'PACKAGE_VERSIONS.json').exists():assert e.read(e.ROOT/'PACKAGE_VERSIONS.json')==versions
else:e.write(e.ROOT/'PACKAGE_VERSIONS.json',versions)
rng=np.random.default_rng(101);X=rng.normal(size=(90,9));g=np.repeat(np.arange(30),3);out=[]
for metric in ['AUROC','AUPRC','Spearman','MAE']:
 y=(X[:,0]+rng.normal(size=90)>.0).astype(float) if e.binary(metric) else X[:,0]+rng.normal(size=90)*.3
 fs,cv=e.folds(metric,y,g,101)
 for learner in ['rf','extra_tree','xgboost','lgbm','catboost','linear_cls' if e.binary(metric) else 'ridge_scaled']:
  def loss(xv,yv,m,*args,**kw):
   try:z=e.score(metric,yv,e.predict(m,xv,metric));return (z if metric=='MAE' else 1-z),{'score':z}
   except ValueError:return float('inf'),{'score':0.0}
  a=AutoML();register(a)
  a.fit(X_train=X,y_train=y,groups=g,task='classification' if e.binary(metric) else 'regression',metric=loss,estimator_list=[learner],time_budget=15,max_iter=6,eval_method='cv',split_type=cv,n_splits=3,n_jobs=1,seed=101,sample=False,auto_augment=False,retrain_full=False,ensemble=False,skip_transform=True,verbose=0,mlflow_logging=False,custom_hp={learner:{('random_seed' if learner=='catboost' else 'random_state'):{'domain':101,'init_value':101}}})
  assert np.isfinite(a.best_loss)
  m=e.copy.deepcopy(a.model);m.cleanup();m.params['thread_count' if learner=='catboost' else 'n_jobs']=1;params=e.copy.deepcopy(m.params);m.fit(X,y,budget=None);assert params==m.params
  p=e.predict(m,X,metric);m2=pickle.loads(pickle.dumps(m));assert np.allclose(p,e.predict(m2,X,metric));out.append([metric,learner,a.best_loss]);print(out[-1],flush=True)
e.write(e.ROOT/'SMOKE_PASS.json',{'cases':out,'status':'PASS'})
