import os,json,sys,subprocess
from pathlib import Path
r=Path(__file__).resolve().parent;c=json.loads((r/'ENVIRONMENT.json').read_text());env={**os.environ,**c['environment']}
cmd=[c['python'],'-B',str(r/sys.argv[1]),*sys.argv[2:]]
os.execve(c['python'],cmd,env)
