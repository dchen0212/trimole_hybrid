import os
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='2'
os.environ['CUDA_VISIBLE_DEVICES']=''
import sys,json,time,hashlib,traceback
from pathlib import Path
R=Path(__file__).resolve().parent;C=Path('/mnt/data/projects/trimole_chemprop22_20261015_v01');T=C/'chemprop/half_life_obach';D=C/'prepared/half_life_obach'
sys.path.insert(0,str(C))
def guard(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)) and Path(os.fsdecode(args[0])).name in ['test.csv','inference.csv','predictions.npz','raw_predictions.csv']:
  raise PermissionError('No official test inputs, labels, or saved test predictions in development-only review')
sys.addaudithook(guard)
import numpy as np,pandas as pd,torch
from scipy.stats import spearmanr
import custom_metrics,chemprop
from chemprop import data,featurizers
from chemprop.models.utils import load_model
torch.set_num_threads(2)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
 with Path(p).open('x') as f:json.dump(x,f,indent=2,allow_nan=False)
def run():
 started=time.time();source=C.parent/'trimole_hybrid_revision_20260915/data/admet_group/half_life_obach/train_val.csv';raw=pd.read_csv(source);df=pd.read_csv(D/'development.csv');ready=read(D/'READY.json')
 assert sha(source)==ready['dev_sha256'] and raw.Drug.tolist()==df.Drug.tolist() and np.array_equal(raw.Y,df.Y)
 assert len(df)==len(raw) and df.Y.notna().all()
 winner=read(T/'CONFIGURATION_FROZEN.json')['winner'];alltrials=[];curves=[];checks=[]
 for p in sorted(T.glob('trial*/FIT.json')):
  fit=read(p);metrics=next((p.parent/'model').rglob('metrics.csv'));f=pd.read_csv(metrics);v=f.dropna(subset=['val/spearman']);i=v['val/spearman'].idxmax();b=v.loc[i]
  assert abs(float(b['val/spearman'])-fit['validation_score'])<1e-12
  loss=f['train_loss_epoch'].dropna().to_numpy();assert np.isfinite(loss).all()
  alltrials.append({'trial':int(p.parent.name[5:]),'validation':fit['validation_score'],'best_epoch_0based':int(b.epoch),'epochs_observed':fit['epochs_observed'],'first_train_loss':float(loss[0]),'final_train_loss':float(loss[-1]),'model_sha256':sha(fit['model'])})
  for row in f.to_dict('records'):
   curves.append({'run':p.parent.name,**{k:None if pd.isna(x) else x for k,x in row.items()}})
 assert len(alltrials)==20 and sorted(alltrials,key=lambda x:(-x['validation'],x['trial']))[0]['trial']==winner['trial']
 featurizer=featurizers.SimpleMoleculeMolGraphFeaturizer()
 points=[data.MoleculeDatapoint.from_smi(s,y=np.array([y],dtype=np.float32)) for s,y in zip(df.Drug,df.Y)]
 ds=data.MoleculeDataset(points,featurizer=featurizer);ds.cache=True
 loader=data.build_dataloader(ds,batch_size=64,num_workers=0,shuffle=False,drop_last=False)
 for seed in [101,202,303,404,505]:
  p=T/f'seed{seed}';fit=read(p/'FIT.json');split=read(D/f'split{seed}.json')[0];tr=np.asarray(split['train']);va=np.asarray(split['val'])
  assert set(tr).isdisjoint(va) and sorted(tr.tolist()+va.tolist())==list(range(len(df))) and not split['test']
  assert sha(D/f'split{seed}.json')==fit['split_sha256'] and sha(fit['model'])==fit['model_sha256'] and fit['configuration']==winner['configuration']
  m=load_model(fit['model']);m.eval();scaler=m.predictor.output_transform.to_standard_scaler();yt=df.Y.to_numpy()[tr]
  assert np.allclose(scaler.mean_,[yt.mean()],rtol=1e-5,atol=1e-6) and np.allclose(scaler.scale_,[yt.std()],rtol=1e-5,atol=1e-6)
  best=list((p/'model').rglob('best-*.ckpt'));assert len(best)==1
  ck=torch.load(best[0],map_location='cpu',weights_only=False)
  state=m.state_dict();assert state.keys()==ck['state_dict'].keys()
  assert all(torch.equal(v,ck['state_dict'][k]) for k,v in state.items())
  preds=[]
  with torch.inference_mode():
   for batch in loader:
    bmg,Vd,Xd,*_=batch;preds.append(m(bmg,Vd,Xd).cpu().numpy().reshape(-1))
  pred=np.concatenate(preds);assert len(pred)==len(df) and np.isfinite(pred).all()
  metric=custom_metrics.Spearman();y=torch.tensor(df.Y.to_numpy()[va],dtype=torch.float);pp=torch.tensor(pred[va],dtype=torch.float)
  for start in range(0,len(va),64):metric.update(pp[start:start+64].reshape(-1,1),y[start:start+64].reshape(-1,1))
  tm=float(metric.compute());scipy=float(spearmanr(df.Y.to_numpy()[va],pred[va]).statistic)
  delta=abs(scipy-fit['validation_score']);assert delta<1e-5,(seed,scipy,fit['validation_score']);assert abs(tm-scipy)<1e-5
  metrics=next((p/'model').rglob('metrics.csv'));f=pd.read_csv(metrics);v=f.dropna(subset=['val/spearman']);best_epoch=int(v.loc[v['val/spearman'].idxmax()].epoch);assert int(ck['epoch'])==best_epoch
  loss=f['train_loss_epoch'].dropna().to_numpy()
  row={'seed':seed,'train_rows':len(tr),'valid_rows':len(va),'best_epoch_0based':best_epoch,'epochs_completed':fit['epochs_observed'],'logged_validation':fit['validation_score'],'cpu_validation_scipy':scipy,'cpu_validation_custom_metric':tm,'validation_abs_difference':delta,'cpu_training_spearman':float(spearmanr(yt,pred[tr]).statistic),'first_train_loss':float(loss[0]),'final_train_loss':float(loss[-1]),'last_validation':float(v['val/spearman'].iloc[-1]),'prediction_unique_values':len(np.unique(pred)),'train_target_mean':float(yt.mean()),'train_target_sd':float(yt.std()),'checkpoint_state_matches_export':True,'target_scaler_train_only':True,'model_sha256':sha(fit['model'])}
  checks.append(row);pd.DataFrame({'row_index':np.arange(len(df)),'role':['fit' if i in set(tr) else 'validation' for i in range(len(df))],'prediction':pred}).to_csv(R/f'development_predictions_seed{seed}.csv',index=False)
  if seed!=101:
   for rec in f.to_dict('records'):curves.append({'run':f'seed{seed}',**{k:None if pd.isna(x) else x for k,x in rec.items()}})
  print(json.dumps(row),flush=True)
 pd.DataFrame(curves).to_csv(R/'TRAINING_CURVES.csv',index=False);pd.DataFrame(checks).to_csv(R/'FIVE_SEED_CHECKS.csv',index=False);pd.DataFrame(alltrials).to_csv(R/'SEARCH_TRIAL_CHECKS.csv',index=False)
 source_files=[C/'run_benchmark.py',C/'cli_guard.py',C/'custom_metrics.py',C/'SEARCH_CONFIGS.json',C/'PROTOCOL.md',T/'CONFIGURATION_FROZEN.json',D/'READY.json',Path(chemprop.__file__).parent/'cli/train.py',Path(chemprop.__file__).parent/'models/model.py']
 write(R/'REVIEW.json',{'status':'PASS','scope':'implementation, native validation metric and convergence checks; does not prove optimal hyperparameters or eliminate generalization error','chemprop_version':chemprop.__version__,'selected_trial':winner['trial'],'trials':alltrials,'five_seed_checks':checks,'data_rows':len(df),'source_hashes':{str(p):sha(p) for p in source_files},'all_development_rows_preserved':True,'test_data_or_predictions_loaded':False,'GPU_used':False,'retraining_performed':False,'elapsed_seconds':time.time()-started})
 print('REVIEW_PASS',flush=True)
if __name__=='__main__':
 try:run()
 except Exception as e:write(R/'ERROR.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
