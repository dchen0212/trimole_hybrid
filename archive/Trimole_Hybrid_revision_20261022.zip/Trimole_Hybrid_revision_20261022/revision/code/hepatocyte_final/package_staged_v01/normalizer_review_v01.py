"""Verify all staged normalizers use exactly their recorded fit rows; no labels or fitting."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,hashlib,time,traceback
import numpy as np
import torch
from rdkit import Chem
R=Path(__file__).resolve().parent
P=Path('/mnt/data/projects/trimole_target_only_expanded_20261013_v02/clearance_hepatocyte_az')
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,data):
 with (R/name).open('x') as f:json.dump(data,f,indent=2)
def main():
 for p,h in read(R/'FREEZE.json')['files'].items():assert sha(R/p)==h
 dev=read(R/'development.json');folds=read(R/'FOLDS.json')['folds']
 bind=read(P/'FOLDS.json');assert sha(P/'development_features.npz')==bind['development_features_sha256']
 assert sha(P/'ROWS.json')==bind['row_binding_sha256']
 source=[r['row_id'] for r in read(P/'ROWS.json') if r['region']=='development']
 assert source==[r['row_id'] for r in dev['rows']]
 canonical=[Chem.MolToSmiles(Chem.MolFromSmiles(r['raw_smiles']),canonical=True,isomericSmiles=True) for r in dev['rows']]
 for f in folds:
  assert not {canonical[i] for i in f['fit']}&{canonical[i] for i in f['validation']}
 with np.load(P/'development_features.npz') as z:features=z['K'].astype(np.float64)
 assert features.shape==(970,2304)
 selected=read(R/'SELECTION_FREEZE.json')['selected'];records=[]
 jobs=[]
 for c in read(R/'CATALOG.json'):
  for fi,f in enumerate(folds):jobs.append((R/'cv'/c['id']/f'fold{fi}',f['fit'],f['validation'],[4,8,16]))
 for seed in [101,202,303,404,505]:jobs.append((R/'final'/f'seed{seed}',list(range(970)),None,[selected['epochs']]))
 for directory,fit,valid,epochs in jobs:
  start=read(directory/'START.json');warm=read(directory/'WARMUP.json')
  assert start['fit_row_ids']==[source[i] for i in fit]
  if valid is not None:assert start['score_row_ids']==[source[i] for i in valid]
  assert start['cross_task_supervised_rows']==0 and not start['test_labels_used']
  assert warm['rows']==len(fit) and warm['feature_source_sha256']==bind['development_features_sha256']
  assert warm['encoder_updates_during_warmup']==0 and warm['normalization_fit_rows_only']
  assert [r['epoch'] for r in warm['epochs']]==list(range(1,41))
  assert all(np.isfinite(r['loss']) for r in warm['epochs'])
  x=features[fit];mean=x.mean(0).astype(np.float32);sd=x.std(0);sd[sd<1e-6]=1.;sd=sd.astype(np.float32)
  for epoch in epochs:
   p=directory/f'epoch{epoch:02d}';seal=read(p/'SEAL.json');assert sha(p/'checkpoint.pt')==seal['checkpoint_sha256']
   state=torch.load(p/'checkpoint.pt',map_location='cpu',weights_only=True)
   assert np.array_equal(state['head.0.mean'].numpy(),mean)
   assert np.array_equal(state['head.0.scale'].numpy(),sd)
   del state
  records.append({'path':str(directory.relative_to(R)),'fit_rows':len(fit),'checkpoint_epochs_checked':epochs,'mean_and_scale_equal':True})
 write('NORMALIZER_REVIEW_v01.json',{'status':'PASS','records':records,'cv_trajectories':18,'final_fits':5,'canonical_molecules':len(set(canonical)),'canonical_molecule_disjoint_cv_folds':True,'test_labels_read':False,'scope':'FitNormalizer saved buffers for every CV checkpoint and each final checkpoint match float64 statistics from exactly the fit rows, then cast to float32. Warmup steps checked from logs; this is not an independent retraining.'})
try:
 while not (R/'REVIEW_COMPLETE.json').exists():
  for name in ['QUEUE_RESUME_ERROR_v01.json','REVIEW_ERROR.json']:
   if (R/name).exists():raise RuntimeError(name)
  if (R/'STATUS.json').exists() and read(R/'STATUS.json')['status']=='FAILED':raise RuntimeError('staged training failed')
  time.sleep(15)
 assert read(R/'REVIEW_COMPLETE.json')['status']=='PASS'
 main()
except Exception as exc:write('NORMALIZER_REVIEW_ERROR_v01.json',{'error':repr(exc),'traceback':traceback.format_exc()});raise
