from pathlib import Path
import torch,numpy as np,json
import run as m
torch.set_num_threads(2);m.verify()
c=m.config_dict['base'];keys=('d_node_feats','d_edge_feats','d_g_feats','d_hpath_ratio','n_mol_layers','path_length','n_heads','n_ffn_dense_layers')
model=m.LiGhTPredictor(**{k:c[k] for k in keys},input_drop=0.,attn_drop=0.,feat_drop=0.,n_node_types=m.Vocab(m.N_ATOM_TYPES,m.N_BOND_TYPES).vocab_size)
state=torch.load(m.MODEL/'models/base.pth',map_location='cpu',weights_only=True);model.load_state_dict({k.removeprefix('module.'):v for k,v in state.items()},strict=True);model.eval()
records=[]
for part in ['development','evaluation']:
 rows=m.read(m.R/f'{part}.json')['rows'];seqs,_=m.encode_inputs(None,rows)
 p=m.P/m.TASK/(part+'_features.npz');fb=m.read(m.P/m.TASK/'FOLDS.json');assert m.sha(p)==fb[part+'_features_sha256']
 assert m.sha(m.P/m.TASK/'ROWS.json')==fb['row_binding_sha256']
 assert [r['row_id'] for r in rows]==[r['row_id'] for r in m.read(m.P/m.TASK/'ROWS.json') if r['region']==part]
 with np.load(p) as z:old=z['K'].copy()
 preds=[]
 with torch.inference_mode():
  for start in range(0,len(rows),8):
   _,g,fp,md,_=m.Collator_tune(5)(seqs[start:start+8]);fresh=model.generate_fps(g,fp,md).numpy();preds.append(fresh)
   if start%200==0:print(part,start,flush=True)
 new=np.concatenate(preds);passed=bool(np.allclose(new,old,atol=1e-4,rtol=1e-4))
 record={'part':part,'rows':len(rows),'max_abs_diff':float(np.max(abs(new-old))),'mean_abs_diff':float(np.mean(abs(new-old))),'passed':passed,'source_sha256':m.sha(p)};records.append(record)
 assert passed,record
m.write(m.R/'INPUT_PARITY_ALL_ROWS.json',{'status':'PASS','records':records,'device':'cpu','atol':1e-4,'rtol':1e-4,'test_labels_read':False,'training_updates':0})
print(records)
