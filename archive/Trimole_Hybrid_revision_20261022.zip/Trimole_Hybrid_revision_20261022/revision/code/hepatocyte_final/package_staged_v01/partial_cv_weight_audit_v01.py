from pathlib import Path
import json,hashlib,torch,numpy as np
from rdkit import Chem
R=Path('/mnt/data/projects/trimole_hepatocyte_staged_kpgt_20261014_v03')
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
torch.set_num_threads(2)
for p,h in read(R/'FREEZE.json')['files'].items():assert sha(R/p)==h
model=Path('/mnt/data/projects/trimole_hybrid_revision_20260915/_dependencies/KPGT/models/base.pth')
assert sha(model)=='8811c117cfedddff5ef2a512290d1a7a73d3d9560773860bc3b06942c597d15d'
orig={k.removeprefix('module.'):v for k,v in torch.load(model,map_location='cpu',weights_only=True).items()}
dev=read(R/'development.json');folds=read(R/'FOLDS.json')['folds'];ident=[Chem.MolToSmiles(Chem.MolFromSmiles(x['raw_smiles']),canonical=True,isomericSmiles=True) for x in dev['rows']]
for f in folds:assert not {ident[i] for i in f['fit']}&{ident[i] for i in f['validation']}
folders=[p.parent for p in sorted(R.glob('cv/*/*/COMPLETE.json'))];records=[]
for d in folders:
 start=read(d/'START.json');f=folds[int(d.name.removeprefix('fold'))];seal=read(d/'epoch16/SEAL.json')
 assert start['fit_row_ids']==[dev['rows'][i]['row_id'] for i in f['fit']]
 assert start['score_row_ids']==[dev['rows'][i]['row_id'] for i in f['validation']]
 assert sha(d/'epoch16/checkpoint.pt')==seal['checkpoint_sha256']
 assert sha(d/'epoch16/predictions.npz')==seal['prediction_sha256']
 state=torch.load(d/'epoch16/checkpoint.pt',map_location='cpu',weights_only=True);allowed=set(start['encoder_trainable_names']);changed=[];unchanged=0
 for k,v in state.items():
  if not k.startswith('encoder.'):continue
  n=k[8:];assert torch.isfinite(v).all()
  diff=float((v-orig[n]).abs().max())
  if n not in allowed:assert diff==0,n
  if diff>0:changed.append(n)
  else:unchanged+=1
 assert changed
 if start['config']['scope']=='top2':assert all(n.startswith(('model.mol_T_layers.10.','model.mol_T_layers.11.')) for n in changed)
 with np.load(d/'epoch16/predictions.npz') as z:assert z['prediction'].shape==(len(f['validation']),) and np.isfinite(z['prediction']).all()
 records.append({'path':str(d.relative_to(R)),'changed_encoder_tensors':len(changed),'unchanged_encoder_tensors':unchanged,'fit_rows':len(f['fit']),'validation_rows':len(f['validation'])})
 del state
report={'status':'PASS','scope':'Completed CV trajectories only; no test scores, final refits or complete experiment claim. Direct checkpoint comparison to official pretrained weights and fit/validation row identities.','trajectories_checked':len(records),'records':records,'canonical_molecule_disjoint_cv':True,'test_labels_read':False}
with (R/'PARTIAL_CV_WEIGHT_AUDIT_v01.json').open('x') as f:json.dump(report,f,indent=2)
print(json.dumps(report))
