import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json,time,hashlib,traceback
from pathlib import Path
import numpy as np
from scipy.stats import rankdata,spearmanr
R=Path(__file__).resolve().parent
B=Path('/mnt/data/projects/trimole_target_only_expanded_20261013_v02')
C=Path('/mnt/data/projects/trimole_hepatocyte_kpgt_finetune_20261014_v02')
TASK='clearance_hepatocyte_az'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(name,data):
 with (R/name).open('x') as f:json.dump(data,f,indent=2,allow_nan=False)
def rank(x):return rankdata(x,method='average')/len(x)
def score(y,p):return float(spearmanr(y,p).statistic)
def check_state():
 if (R/'NOT_STARTED_TARGET_ALREADY_EXCEEDED.json').exists():
  write('BLEND_NOT_STARTED_v01.json',{'reason':'Earlier method reached goal; staged training not started','unix':time.time()});return False
 for name in ['QUEUE_RESUME_ERROR_v01.json']:
  if (R/name).exists():raise RuntimeError(name)
 if (R/'STATUS.json').exists() and read(R/'STATUS.json')['status']=='FAILED':raise RuntimeError('Staged training failed')
 return True
def main():
 reg=read(R/'BLEND_REGISTRATION_v02.json');assert sha(R/'blend_v02.py')==reg['script_sha256']
 assert sha(R/'BLEND_ADDENDUM.md')==reg['protocol_sha256']
 for path,h in reg['reference_hashes'].items():assert sha(path)==h
 while not (R/'SELECTION_FREEZE.json').exists():
  if not check_state():return
  time.sleep(15)
 assert not (R/'TEST_ACCESS_STARTED.json').exists()
 d=read(R/'development.json');y=np.array(d['y']);folds=read(R/'FOLDS.json')['folds']
 assert folds==read(B/TASK/'FOLDS.json')['folds']==read(C/'FOLDS.json')['folds']
 assert [r['row_id'] for r in d['rows']]==[r['row_id'] for r in read(B/TASK/'ROWS.json') if r['region']=='development']==[r['row_id'] for r in read(C/'development.json')['rows']]
 s=read(R/'SELECTION_FREEZE.json')['selected'];cs=read(C/'SELECTION_FREEZE.json')['selected'];bs=read(B/'SELECTION_FREEZE.json')[TASK]
 path=R/'selection_oof'/f"{s['config']['id']}_epoch{s['epochs']:02d}.npz";assert sha(path)==s['oof_sha256']
 with np.load(path) as z:staged=z['prediction']
 path=C/'selection_oof'/f"{cs['config']['id']}_epoch{cs['epochs']:02d}.npz";assert sha(path)==cs['oof_sha256']
 with np.load(path) as z:prior=z['prediction']
 base=[]
 for cid in bs['selected']['members']:
  path=B/TASK/'candidates'/cid/'OOF.npz';assert sha(path)==bs['members'][cid]['oof_sha256']
  with np.load(path) as z:base.append(z['prediction'])
 prior_weight=read(C/'BLEND_SELECTION_FREEZE.json')['selected']['fine_tune_weight'];options=[]
 for anchor in ['earlier_frozen','prior_fused']:
  for alpha in [0.,.25,.5,.75,1.]:
   scores=[]
   for f in folds:
    ix=f['validation'];old=np.mean([rank(p[ix]) for p in base],axis=0)
    reference=old if anchor=='earlier_frozen' else (1-prior_weight)*rank(old)+prior_weight*rank(prior[ix])
    pred=(1-alpha)*rank(reference)+alpha*rank(staged[ix]);scores.append(score(y[ix],pred))
   options.append({'anchor':anchor,'fine_tune_weight':alpha,'fold_scores':scores,'cv_score':float(np.mean(scores))})
 chosen=sorted(options,key=lambda r:(-r['cv_score'],r['anchor'],r['fine_tune_weight']))[0]
 write('BLEND_SELECTION_FREEZE.json',{'selected':chosen,'options':options,'unix':time.time(),'staged_selection_sha256':sha(R/'SELECTION_FREEZE.json'),'prior_fusion_selection_sha256':sha(C/'BLEND_SELECTION_FREEZE.json'),'test_access_exists_at_freeze':False})
 assert not (R/'TEST_ACCESS_STARTED.json').exists()
 while not (R/'ALL_PREDICTIONS_FROZEN.json').exists():
  if not check_state():return
  time.sleep(15)
 ev=read(R/'evaluation.json')['rows'];assert [r['row_id'] for r in ev]==[r['row_id'] for r in read(C/'evaluation.json')['rows']]==[r['row_id'] for r in read(B/TASK/'ROWS.json') if r['region']=='evaluation']
 seals=[]
 for seed in [101,202,303,404,505]:
  npth=R/'final'/f'seed{seed}'/f"epoch{s['epochs']:02d}"/'predictions.npz'
  assert sha(npth)==read(npth.parent/'SEAL.json')['prediction_sha256']
  if chosen['anchor']=='earlier_frozen':
   apth=B/TASK/f'final_seed{seed}'/'predictions.npz';assert sha(apth)==read(apth.parent/'SEAL.json')['prediction_sha256']
  else:
   apth=C/f'blend_seed{seed}.npz';prior_seal=next(x for x in read(C/'BLEND_PREDICTIONS_FROZEN.json') if x['seed']==seed);assert sha(apth)==prior_seal['sha256']
  with np.load(npth) as z:n=z['prediction']
  with np.load(apth) as z:a=z['prediction']
  assert n.shape==a.shape==(243,);alpha=chosen['fine_tune_weight'];pred=(1-alpha)*rank(a)+alpha*rank(n)
  dest=R/f'blend_seed{seed}.npz';np.savez_compressed(dest,prediction=pred)
  seals.append({'seed':seed,'path':dest.name,'sha256':sha(dest),'anchor_path':str(apth),'anchor_sha256':sha(apth),'staged_path':str(npth),'staged_sha256':sha(npth)})
 write('BLEND_PREDICTIONS_FROZEN.json',seals)
 write('BLEND_TEST_ACCESS_STARTED.json',{'unix':time.time(),'selection_sha256':sha(R/'BLEND_SELECTION_FREEZE.json'),'predictions_freeze_sha256':sha(R/'BLEND_PREDICTIONS_FROZEN.json')})
 import pandas as pd
 path=Path(read(R/'INPUT_BINDING.json')['source']['development_path']).with_name('test.csv');assert sha(path)=='23e061c3fdc2627707c099be6a3082a55fd928a1f19e555f6f4f4b734ed8d314'
 data=pd.read_csv(path);ix=[r['source_row'] for r in ev];assert sorted(ix)==list(range(len(data))) and data.iloc[ix].Drug.tolist()==[r['raw_smiles'] for r in ev]
 scores=[]
 for row in seals:
  with np.load(R/row['path']) as z:pred=z['prediction']
  scores.append({'seed':row['seed'],'spearman':score(data.iloc[ix].Y.to_numpy(),pred)})
 values=[r['spearman'] for r in scores]
 write('BLEND_RESULTS.json',{'selected':chosen,'rows':scores,'mean':float(np.mean(values)),'population_sd':float(np.std(values)),'test_sha256':sha(path),'benchmark_reuse':True,'reference_test_results_known_before_this_round':True})
try:main()
except Exception as e:
 write('BLEND_ERROR_v02.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
