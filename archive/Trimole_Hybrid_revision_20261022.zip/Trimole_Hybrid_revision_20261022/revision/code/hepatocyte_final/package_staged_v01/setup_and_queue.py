from pathlib import Path
import os,json,subprocess,time,hashlib,traceback
R=Path(__file__).resolve().parent
B=Path('/mnt/data/projects/trimole_hepatocyte_kpgt_finetune_20261014_v02')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,obj):
 with (R/name).open('x') as f:json.dump(obj,f,indent=2)
try:
 e=json.loads((R/'ENVIRONMENT.json').read_text());env={**os.environ,**e['environment']}
 for part in ['development','evaluation']:
  with (R/f'cache_{part}.log').open('x') as log:subprocess.run([e['python'],'-B',str(R/'run.py'),'cache',part],env=env,cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
 subprocess.run([e['python'],'-B','-c',"import run;run.write(run.R/'CATALOG.json',run.catalog())"],env=env,cwd=R,check=True,timeout=60)
 files=['run.py','PROTOCOL.md','INPUT_BINDING.json','FOLDS.json','CATALOG.json','development.json','development_cache.json']
 write('FREEZE.json',{'files':{p:sha(R/p) for p in files},'unix':time.time(),'benchmark_reuse':True})
 with (R/'parity_all.log').open('x') as log:subprocess.run([e['python'],'-B',str(R/'parity_all.py')],env=env,cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True,timeout=1800)
 with (R/'queue_launch.log').open('x') as log:subprocess.run([e['python'],'-B',str(R/'queue_launch.py')],env=env,cwd=R,stdout=log,stderr=subprocess.STDOUT,check=True)
except Exception as e:write('SETUP_ERROR.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
