import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,time,hashlib,traceback
import numpy as np
from scipy.stats import rankdata
R=Path(__file__).resolve().parent
B=Path('/mnt/data/projects/trimole_target_only_expanded_20261013_v02')
C=Path('/mnt/data/projects/trimole_hepatocyte_kpgt_finetune_20261014_v02')
TASK='clearance_hepatocyte_az'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rank(x):return rankdata(x,method='average')/len(x)
def rho(a,b):
 a=rankdata(a,method='average');b=rankdata(b,method='average');a-=a.mean();b-=b.mean();return float(np.dot(a,b)/(np.linalg.norm(a)*np.linalg.norm(b)))
def close(a,b):assert np.allclose(a,b,atol=1e-12,rtol=0),(a,b)
def load(p):
 with np.load(p,allow_pickle=False) as z:return z['prediction'].copy()
def write(name,d):
 with (R/name).open('x') as f:json.dump(d,f,indent=2,allow_nan=False)
def review():
 reg=read(R/'BLEND_REGISTRATION_v02.json');assert sha(R/'blend_v02.py')==reg['script_sha256'] and sha(R/'BLEND_ADDENDUM.md')==reg['protocol_sha256']
 for p,h in reg['reference_hashes'].items():assert sha(p)==h
 assert reg['stage_training_started'] is False and reg['earlier_test_results_known'] is True
 d=read(R/'development.json');ev=read(R/'evaluation.json')['rows'];y=np.array(d['y']);folds=read(R/'FOLDS.json')['folds']
 assert folds==read(C/'FOLDS.json')['folds']==read(B/TASK/'FOLDS.json')['folds']
 assert [r['row_id'] for r in d['rows']]==[r['row_id'] for r in read(C/'development.json')['rows']]==[r['row_id'] for r in read(B/TASK/'ROWS.json') if r['region']=='development']
 assert [r['row_id'] for r in ev]==[r['row_id'] for r in read(C/'evaluation.json')['rows']]==[r['row_id'] for r in read(B/TASK/'ROWS.json') if r['region']=='evaluation']
 s=read(R/'SELECTION_FREEZE.json')['selected'];cs=read(C/'SELECTION_FREEZE.json')['selected'];bs=read(B/'SELECTION_FREEZE.json')[TASK]
 p=R/'selection_oof'/f"{s['config']['id']}_epoch{s['epochs']:02d}.npz";assert sha(p)==s['oof_sha256'];new=load(p)
 p=C/'selection_oof'/f"{cs['config']['id']}_epoch{cs['epochs']:02d}.npz";assert sha(p)==cs['oof_sha256'];prior=load(p)
 old=[]
 for cid in bs['selected']['members']:
  p=B/TASK/'candidates'/cid/'OOF.npz';assert sha(p)==bs['members'][cid]['oof_sha256'];old.append(load(p))
 pw=read(C/'BLEND_SELECTION_FREEZE.json')['selected']['fine_tune_weight'];options=[]
 for anchor in ['earlier_frozen','prior_fused']:
  for alpha in [0.,.25,.5,.75,1.]:
   scores=[]
   for f in folds:
    ix=f['validation'];baseline=np.vstack([rank(z[ix]) for z in old]).mean(0)
    reference=baseline if anchor=='earlier_frozen' else (1-pw)*rank(baseline)+pw*rank(prior[ix])
    scores.append(rho(y[ix],(1-alpha)*rank(reference)+alpha*rank(new[ix])))
   options.append({'anchor':anchor,'fine_tune_weight':alpha,'fold_scores':scores,'cv_score':float(np.mean(scores))})
 sf=read(R/'BLEND_SELECTION_FREEZE.json');best=sorted(options,key=lambda d:(-d['cv_score'],d['anchor'],d['fine_tune_weight']))[0];chosen=sf['selected']
 assert best['anchor']==chosen['anchor'] and best['fine_tune_weight']==chosen['fine_tune_weight'];close(best['cv_score'],chosen['cv_score'])
 assert len(options)==len(sf['options'])==10
 for a,b in zip(options,sf['options']):assert (a['anchor'],a['fine_tune_weight'])==(b['anchor'],b['fine_tune_weight']);close(a['fold_scores'],b['fold_scores']);close(a['cv_score'],b['cv_score'])
 assert reg['unix']<sf['unix']<read(R/'TEST_ACCESS_STARTED.json')['unix'];assert not sf['test_access_exists_at_freeze']
 seals=read(R/'BLEND_PREDICTIONS_FROZEN.json');assert [d['seed'] for d in seals]==[101,202,303,404,505]
 replays=[]
 for record in seals:
  seed=record['seed'];p=R/f'blend_seed{seed}.npz';cp=R/'final'/f'seed{seed}'/f"epoch{s['epochs']:02d}"/'predictions.npz'
  ap=B/TASK/f'final_seed{seed}'/'predictions.npz' if chosen['anchor']=='earlier_frozen' else C/f'blend_seed{seed}.npz'
  assert str(ap)==record['anchor_path'] and str(cp)==record['staged_path']
  assert sha(ap)==record['anchor_sha256'] and sha(cp)==record['staged_sha256'] and sha(p)==record['sha256']
  assert sha(cp)==read(cp.parent/'SEAL.json')['prediction_sha256']
  if chosen['anchor']=='earlier_frozen':assert sha(ap)==read(ap.parent/'SEAL.json')['prediction_sha256']
  else:assert sha(ap)==next(x for x in read(C/'BLEND_PREDICTIONS_FROZEN.json') if x['seed']==seed)['sha256']
  alpha=chosen['fine_tune_weight'];expected=(1-alpha)*rank(load(ap))+alpha*rank(load(cp));actual=load(p);close(expected,actual);assert len(actual)==243
  replays.append({'seed':seed,'max_abs_difference':float(np.max(abs(expected-actual)))})
 import pandas as pd
 tp=Path(read(R/'INPUT_BINDING.json')['source']['development_path']).with_name('test.csv');assert sha(tp)=='23e061c3fdc2627707c099be6a3082a55fd928a1f19e555f6f4f4b734ed8d314'
 table=pd.read_csv(tp);ix=[r['source_row'] for r in ev];assert sorted(ix)==list(range(len(table))) and table.iloc[ix].Drug.tolist()==[r['raw_smiles'] for r in ev]
 result=read(R/'BLEND_RESULTS.json');assert result['selected']==chosen and result['test_sha256']==sha(tp);values=[]
 for record,row in zip(seals,result['rows']):
  assert record['seed']==row['seed'];value=rho(table.iloc[ix].Y.to_numpy(),load(R/record['path']));close(value,row['spearman']);values.append(value)
 close(np.mean(values),result['mean']);close(np.std(values),result['population_sd'])
 write('BLEND_REVIEW_v01.json',{'status':'PASS','selected':chosen,'options_replayed':10,'prediction_replays':replays,'rank_definition_score_replay':values,'mean':result['mean'],'population_sd':result['population_sd'],'benchmark_reuse':True})
try:
 while not (R/'BLEND_RESULTS.json').exists():
  if (R/'NOT_STARTED_TARGET_ALREADY_EXCEEDED.json').exists():
   write('BLEND_REVIEW_NOT_NEEDED_v01.json',{'reason':'Staged experiment not started'});raise SystemExit(0)
  if (R/'BLEND_ERROR_v02.json').exists() or (R/'QUEUE_RESUME_ERROR_v01.json').exists() or ((R/'STATUS.json').exists() and read(R/'STATUS.json')['status']=='FAILED'):raise RuntimeError('Staged pipeline failed')
  time.sleep(15)
 review()
except Exception as e:write('BLEND_REVIEW_ERROR_v02.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
