"""Registered development-selected fusion of new fine-tuned and prior target-only predictions."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json,time,hashlib,traceback
from pathlib import Path
import numpy as np
from scipy.stats import rankdata,spearmanr
R=Path(__file__).resolve().parent
B=Path('/mnt/data/projects/trimole_target_only_expanded_20261013_v02')
TASK='clearance_hepatocyte_az'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):
 with Path(p).open('x') as f:json.dump(d,f,indent=2,allow_nan=False)
def rank(x):return rankdata(x,method='average')/len(x)
def score(y,p):return float(spearmanr(y,p).statistic)
def run():
 registration=read(R/'BLEND_REGISTRATION.json')
 assert sha(R/'blend.py')==registration['script_sha256']
 while not (R/'SELECTION_FREEZE.json').exists():
  if read(R/'STATUS.json')['status']=='FAILED':raise RuntimeError('Primary training failed')
  time.sleep(5)
 assert not (R/'TEST_ACCESS_STARTED.json').exists(),'Blend selection must precede new test access'
 s=read(R/'SELECTION_FREEZE.json')['selected'];old=read(B/'SELECTION_FREEZE.json')[TASK]
 dev=read(R/'development.json');y=np.array(dev['y']);folds=read(R/'FOLDS.json')['folds']
 assert folds==read(B/TASK/'FOLDS.json')['folds']
 assert [r['row_id'] for r in dev['rows']]==[r['row_id'] for r in read(B/TASK/'ROWS.json') if r['region']=='development']
 p=R/'selection_oof'/f"{s['config']['id']}_epoch{s['epochs']:02d}.npz";assert sha(p)==s['oof_sha256']
 with np.load(p) as z:new=z['prediction']
 old_oofs=[]
 for cid in old['selected']['members']:
  p=B/TASK/'candidates'/cid/'OOF.npz';assert sha(p)==old['members'][cid]['oof_sha256']
  with np.load(p) as z:old_oofs.append(z['prediction'])
 options=[]
 for alpha in [0.,.25,.5,.75,1.]:
  scores=[]
  for f in folds:
   ix=f['validation'];baseline=np.mean([rank(x[ix]) for x in old_oofs],axis=0)
   pred=(1-alpha)*rank(baseline)+alpha*rank(new[ix]);scores.append(score(y[ix],pred))
  options.append({'fine_tune_weight':alpha,'fold_scores':scores,'cv_score':float(np.mean(scores))})
 chosen=sorted(options,key=lambda x:(-x['cv_score'],x['fine_tune_weight']))[0]
 write(R/'BLEND_SELECTION_FREEZE.json',{'selected':chosen,'options':options,'unix':time.time(),
  'primary_selection_sha256':sha(R/'SELECTION_FREEZE.json'),'baseline_selection_sha256':sha(B/'SELECTION_FREEZE.json'),
  'new_test_access_exists_at_freeze':(R/'TEST_ACCESS_STARTED.json').exists()})
 assert not (R/'TEST_ACCESS_STARTED.json').exists()
 while not (R/'ALL_PREDICTIONS_FROZEN.json').exists():
  if read(R/'STATUS.json')['status']=='FAILED':raise RuntimeError('Primary training failed')
  time.sleep(5)
 pred_records=[]
 for seed in [101,202,303,404,505]:
  oldpath=B/TASK/f'final_seed{seed}'/'predictions.npz'
  newpath=R/'final'/f'seed{seed}'/f"epoch{s['epochs']:02d}"/'predictions.npz'
  assert sha(oldpath)==read(oldpath.parent/'SEAL.json')['prediction_sha256']
  assert sha(newpath)==read(newpath.parent/'SEAL.json')['prediction_sha256']
  with np.load(oldpath) as z:oldpred=z['prediction']
  with np.load(newpath) as z:newpred=z['prediction']
  alpha=chosen['fine_tune_weight'];pred=(1-alpha)*rank(oldpred)+alpha*rank(newpred)
  dest=R/f'blend_seed{seed}.npz';np.savez_compressed(dest,prediction=pred)
  pred_records.append({'seed':seed,'path':dest.name,'sha256':sha(dest),'baseline_prediction_sha256':sha(oldpath),'new_prediction_sha256':sha(newpath)})
 write(R/'BLEND_PREDICTIONS_FROZEN.json',pred_records)
 import pandas as pd
 source=Path(read(R/'INPUT_BINDING.json')['source']['development_path']).with_name('test.csv')
 assert sha(source)=='23e061c3fdc2627707c099be6a3082a55fd928a1f19e555f6f4f4b734ed8d314'
 test=pd.read_csv(source)
 ev=read(R/'evaluation.json')['rows'];ix=[x['source_row'] for x in ev]
 assert sorted(ix)==list(range(len(test))) and test.iloc[ix].Drug.tolist()==[x['raw_smiles'] for x in ev]
 scores=[]
 for row in pred_records:
  with np.load(R/row['path']) as z:pred=z['prediction']
  scores.append({'seed':row['seed'],'spearman':score(test.iloc[ix].Y.to_numpy(),pred)})
 values=[x['spearman'] for x in scores]
 write(R/'BLEND_RESULTS.json',{'selected':chosen,'rows':scores,'mean':float(np.mean(values)),
  'population_sd':float(np.std(values)),'test_sha256':sha(source),'benchmark_reuse':True})
try:run()
except Exception as e:write(R/'BLEND_ERROR.json',{'error':repr(e),'traceback':traceback.format_exc()});raise
