"""Completed-run review: no fitting and no bootstrap."""
import os
os.environ['CUDA_VISIBLE_DEVICES']=''
os.environ['OPENBLAS_NUM_THREADS']='1'
import sys,json,hashlib
from pathlib import Path
import numpy as np
import pandas as pd
import torch
from scipy.stats import spearmanr
R=Path(sys.argv[1])
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def score(y,p):return float(spearmanr(y,p).statistic)
def same(a,b):assert np.allclose(a,b,rtol=0,atol=1e-12),(a,b)
assert read(R/'STATUS.json')['status']=='FINISHED_REQUIRES_REVIEW'
for p,h in read(R/'FREEZE.json')['files'].items():assert sha(R/p)==h
binding=read(R/'INPUT_BINDING.json');dev=read(R/'development.json');ev=read(R/'evaluation.json')['rows'];y=np.array(dev['y'])
assert sha(R/'evaluation.json')==binding['evaluation_sha256']
assert sha(binding['source']['development_path'])==binding['source']['development_sha256']
data=pd.read_csv(binding['source']['development_path']);assert data.Drug.tolist()==[x['raw_smiles'] for x in dev['rows']];same(data.Y,y)
folds=read(R/'FOLDS.json')['folds'];coverage=np.zeros(len(y),int)
for f in folds:
 a,b=f['fit'],f['validation'];assert not set(a)&set(b);assert set(a)|set(b)==set(range(len(y)));coverage[b]+=1
 assert not {dev['rows'][i]['raw_smiles'] for i in a}&{dev['rows'][i]['raw_smiles'] for i in b}
assert (coverage==1).all()
s=read(R/'SELECTION_FREEZE.json');candidates=s['all_candidates'];checks=[]
for c in candidates:
 scores=[]
 for fi,f in enumerate(folds):
  d=R/'cv'/c['config']['id']/f'fold{fi}'
  st=read(d/'START.json');p=d/f"epoch{c['epochs']:02d}";seal=read(p/'SEAL.json')
  assert st['fit_row_ids']==[dev['rows'][i]['row_id'] for i in f['fit']]
  assert st['score_row_ids']==[dev['rows'][i]['row_id'] for i in f['validation']]
  assert st['cross_task_supervised_rows']==0 and not st['test_labels_used']
  same(st['target_log_mean'],np.log1p(y[f['fit']]).mean());same(st['target_log_sd'],np.log1p(y[f['fit']]).std())
  assert sha(p/'predictions.npz')==seal['prediction_sha256'] and sha(p/'checkpoint.pt')==seal['checkpoint_sha256']
  assert sha(p/'SEAL.json')==c['fold_seal_sha256'][fi]
  assert seal['encoder_probe_max_abs_change']>0
  if c['config']['scope']=='top2':
   assert seal['embedding_max_abs_change']==0
   assert all(n.startswith(('model.mol_T_layers.10.','model.mol_T_layers.11.')) for n in st['encoder_trainable_names'])
  with np.load(p/'predictions.npz') as z:pred=z['prediction']
  scores.append(score(y[f['validation']],pred))
 same(scores,c['fold_scores']);same(np.mean(scores),c['cv_score']);checks.append({'config':c['config']['id'],'epochs':c['epochs'],'cv_score':c['cv_score']})
assert sorted(candidates,key=lambda x:(-x['cv_score'],x['config']['id'],x['epochs']))[0]==s['selected']
seals=read(R/'ALL_PREDICTIONS_FROZEN.json');assert len(seals)==5
for p,h in seals.items():assert sha(R/p/'SEAL.json')==h
access=read(R/'TEST_ACCESS_STARTED.json');assert access['selection_sha256']==sha(R/'SELECTION_FREEZE.json')
assert access['all_seals_sha256']==sha(R/'ALL_PREDICTIONS_FROZEN.json')
test_path=Path(binding['source']['development_path']).with_name('test.csv');test=pd.read_csv(test_path);ix=[x['source_row'] for x in ev]
assert sorted(ix)==list(range(len(test))) and [x['raw_smiles'] for x in ev]==test.iloc[ix].Drug.tolist()
result=read(R/'RESULTS.json');assert result['test_sha256']==sha(test_path)
values=[]
for row in result['rows']:
 p=R/'final'/f"seed{row['seed']}";st=read(p/'START.json');dest=p/f"epoch{s['selected']['epochs']:02d}";seal=read(dest/'SEAL.json')
 assert st['fit_row_ids']==[x['row_id'] for x in dev['rows']]
 assert st['score_row_ids']==[x['row_id'] for x in ev]
 assert seal['fit_rows']==970 and seal['prediction_rows']==243
 assert seal['encoder_probe_max_abs_change']>0
 assert sha(dest/'checkpoint.pt')==seal['checkpoint_sha256'] and sha(dest/'predictions.npz')==seal['prediction_sha256']
 with np.load(dest/'predictions.npz') as z:pred=z['prediction']
 v=score(test.iloc[ix].Y.to_numpy(),pred);same(v,row['spearman']);values.append(v)
same(np.mean(values),result['mean']);same(np.std(values),result['population_sd'])
print(json.dumps({'status':'PASS','development_cv_replay':checks,'selected':s['selected'],
 'test_mean':result['mean'],'population_sd':result['population_sd'],'seed_scores':values,
 'gap_to_0536':.536-result['mean'],'encoder_updates_verified':True,'cv_trajectories':18,
 'final_refits':5,'test_rows':243,'scope':'target-only supervised encoder fine-tuning on a historically reused benchmark'},indent=2))
