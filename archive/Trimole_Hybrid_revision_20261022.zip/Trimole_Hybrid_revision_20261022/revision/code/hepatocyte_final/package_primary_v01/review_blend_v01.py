"""Independent replay of predeclared fusion; no fitting, bootstrap, or selection changes."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
import json,time,hashlib,traceback
from pathlib import Path
import numpy as np
from scipy.stats import rankdata,spearmanr
R=Path(__file__).resolve().parent
B=Path('/mnt/data/projects/trimole_target_only_expanded_20261013_v02')
TASK='clearance_hepatocyte_az'
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def rank(x):return rankdata(x,method='average')/len(x)
def score(y,p):return float(spearmanr(y,p).statistic)
def same(a,b):assert np.allclose(a,b,rtol=0,atol=1e-12),(a,b)
def write(name,d):
 with (R/name).open('x') as f:json.dump(d,f,indent=2,allow_nan=False)
def run():
 reg=read(R/'BLEND_REGISTRATION.json');assert sha(R/'blend.py')==reg['script_sha256']
 assert sha(R/'BLEND_ADDENDUM.md')==reg['protocol_sha256']
 dev=read(R/'development.json');ev=read(R/'evaluation.json')['rows'];oldrows=read(B/TASK/'ROWS.json')
 for part,rows in [('development',dev['rows']),('evaluation',ev)]:
  assert [(x['row_id'],x['raw_smiles']) for x in rows]==[(x['row_id'],x['raw_smiles']) for x in oldrows if x['region']==part]
 folds=read(R/'FOLDS.json')['folds'];assert folds==read(B/TASK/'FOLDS.json')['folds'];y=np.array(dev['y'])
 s=read(R/'SELECTION_FREEZE.json')['selected'];old=read(B/'SELECTION_FREEZE.json')[TASK]
 p=R/'selection_oof'/f"{s['config']['id']}_epoch{s['epochs']:02d}.npz";assert sha(p)==s['oof_sha256']
 with np.load(p) as z:new=z['prediction']
 old_oofs=[]
 for cid in old['selected']['members']:
  p=B/TASK/'candidates'/cid/'OOF.npz';assert sha(p)==old['members'][cid]['oof_sha256']
  with np.load(p) as z:old_oofs.append(z['prediction'])
 options=[]
 for alpha in [0.,.25,.5,.75,1.]:
  scores=[]
  for f in folds:
   ix=f['validation'];base=np.mean([rank(x[ix]) for x in old_oofs],axis=0)
   pred=(1-alpha)*rank(base)+alpha*rank(new[ix]);scores.append(score(y[ix],pred))
  options.append({'fine_tune_weight':alpha,'fold_scores':scores,'cv_score':float(np.mean(scores))})
 chosen=sorted(options,key=lambda x:(-x['cv_score'],x['fine_tune_weight']))[0]
 sf=read(R/'BLEND_SELECTION_FREEZE.json');assert sf['selected']==chosen and sf['options']==options
 assert sf['primary_selection_sha256']==sha(R/'SELECTION_FREEZE.json')
 assert sf['baseline_selection_sha256']==sha(B/'SELECTION_FREEZE.json')
 assert reg['unix']<sf['unix']<read(R/'TEST_ACCESS_STARTED.json')['unix']
 assert not sf['new_test_access_exists_at_freeze']
 sealed=read(R/'BLEND_PREDICTIONS_FROZEN.json');assert [x['seed'] for x in sealed]==[101,202,303,404,505]
 replays=[]
 for row in sealed:
  seed=row['seed'];p=R/row['path'];oldpath=B/TASK/f'final_seed{seed}'/'predictions.npz';newpath=R/'final'/f'seed{seed}'/f"epoch{s['epochs']:02d}"/'predictions.npz'
  assert sha(p)==row['sha256']
  assert sha(oldpath)==row['baseline_prediction_sha256']==read(oldpath.parent/'SEAL.json')['prediction_sha256']
  assert sha(newpath)==row['new_prediction_sha256']==read(newpath.parent/'SEAL.json')['prediction_sha256']
  with np.load(oldpath) as z:a=z['prediction']
  with np.load(newpath) as z:b=z['prediction']
  with np.load(p) as z:pred=z['prediction']
  alpha=chosen['fine_tune_weight'];replay=(1-alpha)*rank(a)+alpha*rank(b);same(replay,pred)
  assert len(pred)==len(ev)==243
  replays.append({'seed':seed,'max_prediction_abs_diff':float(np.max(abs(replay-pred)))})
 import pandas as pd
 source=Path(read(R/'INPUT_BINDING.json')['source']['development_path']).with_name('test.csv')
 assert sha(source)=='23e061c3fdc2627707c099be6a3082a55fd928a1f19e555f6f4f4b734ed8d314'
 test=pd.read_csv(source);ix=[x['source_row'] for x in ev]
 assert sorted(ix)==list(range(len(test))) and test.iloc[ix].Drug.tolist()==[x['raw_smiles'] for x in ev]
 result=read(R/'BLEND_RESULTS.json');assert result['selected']==chosen and result['test_sha256']==sha(source)
 vals=[]
 for row,expected in zip(sealed,result['rows']):
  with np.load(R/row['path']) as z:pred=z['prediction']
  value=score(test.iloc[ix].Y.to_numpy(),pred);assert expected['seed']==row['seed'];same(value,expected['spearman']);vals.append(value)
 same(np.mean(vals),result['mean']);same(np.std(vals),result['population_sd'])
 write('BLEND_REVIEW_v01.json',{'status':'PASS','selection_replay':chosen,'all_options':options,'prediction_replays':replays,
  'mean':result['mean'],'population_sd':result['population_sd'],'gap_to_0536':.536-result['mean'],
  'prior_startup_failure_preserved':(R/'BLEND_ERROR.json').exists(),'result_sha256':sha(R/'BLEND_RESULTS.json'),'benchmark_reuse':True})
try:
 while not (R/'BLEND_RESULTS.json').exists():
  if read(R/'STATUS.json')['status']=='FAILED':raise RuntimeError('Primary pipeline failed')
  time.sleep(15)
 run()
except Exception as exc:
 write('BLEND_REVIEW_ERROR_v01.json',{'error':repr(exc),'traceback':traceback.format_exc()});raise
