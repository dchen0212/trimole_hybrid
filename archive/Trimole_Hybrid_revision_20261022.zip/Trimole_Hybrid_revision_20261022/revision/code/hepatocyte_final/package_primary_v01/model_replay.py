import sys,json,hashlib
from pathlib import Path
import numpy as np
import torch
import run as m
R=m.R
s=m.read(R/'SELECTION_FREEZE.json')['selected']
original=torch.load(m.MODEL/'models/base.pth',map_location='cpu',weights_only=True)
original={k.removeprefix('module.'):v for k,v in original.items()}
rows=m.read(R/'evaluation.json')['rows'];inputs,_=m.encode_inputs(None,rows)
results=[]
for seed in m.SEEDS:
 d=R/'final'/f'seed{seed}'/f"epoch{s['epochs']:02d}";seal=m.read(d/'SEAL.json')
 assert m.sha(d/'checkpoint.pt')==seal['checkpoint_sha256']
 state=torch.load(d/'checkpoint.pt',map_location='cpu',weights_only=True)
 encoder,head,_=m.make_model(s['config'])
 encoder.load_state_dict({k[8:]:v for k,v in state.items() if k.startswith('encoder.')},strict=True)
 head.load_state_dict({k[5:]:v for k,v in state.items() if k.startswith('head.')},strict=True)
 changed=[];frozen_count=0
 for name,param in encoder.named_parameters():
  delta=float((param.detach().cpu()-original[name]).abs().max())
  if param.requires_grad and delta>0:changed.append(name)
  if not param.requires_grad:assert delta==0,name;frozen_count+=1
 assert changed
 pred=m.predict(encoder,head,inputs)
 with np.load(d/'predictions.npz') as z:old=z['prediction']
 assert np.allclose(pred,old,rtol=1e-5,atol=1e-5),(seed,float(np.max(abs(pred-old))))
 results.append({'seed':seed,'changed_encoder_tensors':len(changed),'unchanged_frozen_tensors':frozen_count,'max_prediction_abs_difference':float(np.max(abs(pred-old)))})
 del encoder,head,state;torch.cuda.empty_cache()
m.write(R/'MODEL_REPLAY.json',{'status':'PASS','rows':results,'comparison_tolerance':{'atol':1e-5,'rtol':1e-5},'DGL_sparse_GPU_nondeterminism_disclosed':True})
print(json.dumps(results,indent=2))
