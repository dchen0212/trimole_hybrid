# Hepatocyte target-only KPGT fine-tuning v01
Only clearance_hepatocyte_az supervision. CYP3A4 untouched. Historical test reuse.
Six recipes: top two or all 12 layers at encoder LR 1e-5/5e-5 with log1p SmoothL1; plus all-layer pairwise logistic + 0.25 SmoothL1 at both LRs. Fixed head 2304-128-1, dropout 0.1, head LR5e-4. AdamW wd0.01, clip1, batch8 FP32. Seeded DGL GPU sparse ops are not asserted bitwise deterministic.
Shared three scaffold folds. Fit-row log target standardization. Epoch4/8/16 alternatives, fixed16epoch scheduler horizon10%warmup. Select mean fold Spearman, tie configid then epoch. No official test labels in training/CV. Checkpoint actual encoder updates.
Five full refits seeds101,202,303,404,505; freeze all predictions before test scoring. Target >0.536 is aspirational, no guaranteed result or statistical superiority. Report adverse rounds.
Official base weight SHA8811c117cfedddff5ef2a512290d1a7a73d3d9560773860bc3b06942c597d15d. Existing pretrained corpus exposure not ruled out. Graph,fp,normalized descriptors keyed jointly; upstream normalized descriptor NaN->0 rule logged. No target test labels or other task supervised samples. No data loss on scoring.
Workers bounded7200s. If memory or numerical failure, preserve and document before any revised protocol. No silent batch/recipe changes.
