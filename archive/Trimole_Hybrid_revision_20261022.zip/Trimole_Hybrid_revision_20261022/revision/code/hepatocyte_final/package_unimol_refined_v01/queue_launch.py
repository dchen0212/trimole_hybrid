from pathlib import Path
import os,json,time,subprocess,traceback
R=Path(__file__).resolve().parent
A=Path('/mnt/data/projects/trimole_hepatocyte_ept_targetonly_20261014_v01')
def read(p):return json.loads(p.read_text())
def write(n,d):
 with (R/n).open('x') as f:json.dump(d,f,indent=2)
def execute(name,args,env):
 with (R/(name+'.log')).open('x') as f:subprocess.run(args,cwd=R,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
try:
 write('QUEUE_STARTED.json',{'unix':time.time(),'waiting_for':str(A)})
 skip=False
 while True:
  if (A/'NOT_STARTED_TARGET_ALREADY_EXCEEDED.json').exists():
   write('NOT_STARTED_TARGET_ALREADY_EXCEEDED.json',{'reason':'Upstream EPT skipped because an earlier method reached target','unix':time.time()});skip=True;break
  parent_error=R.parent/'trimole_hepatocyte_goal_tracking_20261014_v01/QUEUE_3D_REORDER_ERROR_v01.json'
  if parent_error.exists():raise RuntimeError('Earlier 3D queue requires inspection: '+str(parent_error))
  for n in ['SETUP_ERROR.json','REVIEW_ERROR.json','BLEND_ERROR_v01.json','BLEND_REVIEW_ERROR_v01.json','QUEUE_ERROR.json']:
   if (A/n).exists():raise RuntimeError('Upstream round requires repair: '+n)
  if (A/'STATUS.json').exists() and read(A/'STATUS.json')['status']=='FAILED':raise RuntimeError('Upstream training failed')
  needed=['REVIEW_COMPLETE.json','BLEND_REVIEW_v01.json','metric_definition_encoder_v01.json','metric_definition_blend_v01.json']
  if all((A/n).exists() for n in needed):
   assert all(read(A/n)['status']=='PASS' for n in needed);break
  time.sleep(15)
 if not skip:
  means=[read(A/'RESULTS.json')['mean'],read(A/'BLEND_RESULTS.json')['mean']]
  if max(means)>.536:write('NOT_STARTED_TARGET_ALREADY_EXCEEDED.json',{'means':means,'unix':time.time()})
  else:
   e=read(R/'ENVIRONMENT.json');env={**os.environ,**e['environment']};write('QUEUE_RELEASED.json',{'means':means,'unix':time.time(),'benchmark_reuse':True})
   execute('smoke',[e['python'],'-B',str(R/'run.py'),'smoke'],env);assert read(R/'SELFTEST.json')['status']=='PASS'
   execute('controller',[e['python'],'-B',str(R/'run.py'),'controller'],env)
   execute('review_after',[e['python'],'-B',str(R/'review_after.py')],env)
   while not (R/'BLEND_REVIEW_v01.json').exists():
    if (R/'BLEND_ERROR_v01.json').exists() or (R/'BLEND_REVIEW_ERROR_v01.json').exists():raise RuntimeError('Current blend failed')
    time.sleep(15)
   assert read(R/'BLEND_REVIEW_v01.json')['status']=='PASS'
   execute('metric_definition_blend_v01',[e['python'],'-B',str(R/'metric_definition_review.py'),str(R),'blend',str(R/'metric_definition_blend_v01.json')],env)
   assert read(R/'metric_definition_blend_v01.json')['status']=='PASS'
   write('ALL_REVIEWS_COMPLETE_v01.json',{'status':'PASS','unix':time.time()})
except Exception as exc:write('QUEUE_ERROR.json',{'error':repr(exc),'traceback':traceback.format_exc()});raise
