"""Read-only score replay from rank-correlation definition, plus explicit tie fixtures."""
import os
os.environ['OPENBLAS_NUM_THREADS']='1'
from pathlib import Path
import json,sys,hashlib
import numpy as np
import pandas as pd
from scipy.stats import rankdata,spearmanr
R=Path(sys.argv[1]);mode=sys.argv[2];OUT=Path(sys.argv[3])
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def definition(y,p):
 y=np.asarray(y,dtype=float);p=np.asarray(p,dtype=float)
 assert y.ndim==p.ndim==1 and y.shape==p.shape and len(y)>2 and np.isfinite(y).all() and np.isfinite(p).all()
 a=rankdata(y,method='average');b=rankdata(p,method='average');a-=a.mean();b-=b.mean()
 denom=float(np.linalg.norm(a)*np.linalg.norm(b));assert denom>0
 return float(np.dot(a,b)/denom)
fixtures=[([1,2,2,4],[4,3,3,1],-1.),([1,1,2,3],[1,2,2,4],5/6),([1,2,3],[1,2,3],1.)]
for y,p,expected in fixtures:assert abs(definition(y,p)-expected)<1e-12
base=R if (R/'evaluation.json').exists() else Path('/mnt/data/projects/trimole_hepatocyte_kpgt_finetune_20261014_v02')
binding=read(base/'INPUT_BINDING.json');rows=read(base/'evaluation.json')['rows']
source=Path(binding['source']['development_path']).with_name('test.csv');assert sha(source)=='23e061c3fdc2627707c099be6a3082a55fd928a1f19e555f6f4f4b734ed8d314'
filename='BLEND_RESULTS.json' if mode=='blend' else 'RESULTS.json';result=read(R/filename)
# Require all five predictions and their audit receipts before reading labels.
paths=[]
for seed in [101,202,303,404,505]:
 if mode=='blend':p=R/f'blend_seed{seed}.npz';records=read(R/'BLEND_PREDICTIONS_FROZEN.json');record=next(r for r in records if r['seed']==seed);assert sha(p)==record['sha256']
 elif mode=='encoder':
  epochs=read(R/'SELECTION_FREEZE.json')['selected']['epochs'];p=R/'final'/f'seed{seed}'/f'epoch{epochs:02d}'/'predictions.npz';assert sha(p)==read(p.parent/'SEAL.json')['prediction_sha256']
 elif mode=='readout':p=R/'final'/f'seed{seed}'/'predictions.npz';assert sha(p)==read(p.parent/'SEAL.json')['prediction_sha256']
 else:raise ValueError(mode)
 paths.append(p)
data=pd.read_csv(source);ix=[r['source_row'] for r in rows]
assert sorted(ix)==list(range(len(data))) and [r['raw_smiles'] for r in rows]==data.iloc[ix].Drug.tolist();y=data.iloc[ix].Y.to_numpy()
assert [r['seed'] for r in result['rows']]==[101,202,303,404,505]
records=[]
for p,row in zip(paths,result['rows']):
 with np.load(p,allow_pickle=False) as z:pred=z['prediction']
 value=definition(y,pred);cross=float(spearmanr(y,pred).statistic)
 assert abs(value-cross)<1e-12 and abs(value-row['spearman'])<1e-12
 records.append({'seed':row['seed'],'rank_definition_spearman':value,'scipy_spearman':cross,'saved_spearman':row['spearman'],'prediction_sha256':sha(p)})
values=[r['rank_definition_spearman'] for r in records]
assert abs(float(np.mean(values))-result['mean'])<1e-12 and abs(float(np.std(values))-result['population_sd'])<1e-12
with OUT.open('x') as f:json.dump({'status':'PASS','method_mode':mode,'fixtures_passed':3,'rows':243,'results_sha256':sha(R/filename),'records':records,'mean':float(np.mean(values)),'population_sd':float(np.std(values)),'result_is_benchmark_reuse':True},f,indent=2)
print(OUT)
