"""Direct use of pinned official Uni-Mol math with offline loading and explicit batching.
Package entrypoints, automatic downloads and the native trainer are not invoked.
"""
from pathlib import Path
import sys,types,importlib.util,json,hashlib,logging
import numpy as np
import torch
P=Path('/mnt/data/projects/trimole_hepatocyte_unimol_preparation_20261014_v01')
SRC=P/'source_files_v03/unimol_tools/unimol_tools'
NS='trimole_pinned_unimol'
WEIGHT_SHA='da27196af09a8c6d089e10b7764b6a716bcc33da227fc118f5b45b0e484585e9'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def read(p):return json.loads(Path(p).read_text())
def package(name,path=None):
 m=types.ModuleType(name);m.__path__=[] if path is None else [str(path)];sys.modules[name]=m;return m
def load(name,path):
 spec=importlib.util.spec_from_file_location(name,path);mod=importlib.util.module_from_spec(spec);sys.modules[name]=mod;spec.loader.exec_module(mod);return mod
needed=['config/model_config.py','data/dictionary.py','data/conformer.py','models/transformers.py','models/unimol.py']
records={x['path']:x for x in read(P/'SOURCE_RETRIEVAL_v03.json')['files']}
for n in needed:
 rec=records['unimol_tools/unimol_tools/'+n];assert rec['status']=='PASS' and sha(SRC/n)==rec['sha256']
assert sha(P/'mol.dict.txt')=='94135cb9a9198f988de684cb61e2c372882a3bd59b8320effbae704c38057127'
sys.path.insert(0,str(P/'vendor_addict_v01'))
if NS not in sys.modules:
 package(NS,SRC);package(NS+'.models',SRC/'models');data=package(NS+'.data',SRC/'data')
 config=package(NS+'.config',SRC/'config');cm=load(NS+'.config.model_config',SRC/'config/model_config.py');config.MODEL_CONFIG=cm.MODEL_CONFIG
 util=package(NS+'.utils');util.logger=logging.getLogger('trimole_unimol')
 def no_native_collate(*args,**kwargs):raise RuntimeError('Use adapter.batch; native utility padding is not loaded')
 util.pad_1d_tokens=util.pad_2d=util.pad_coords=no_native_collate
 weights=package(NS+'.weights');weights.WEIGHT_DIR=str(P)
 def no_download(*args,**kwargs):raise RuntimeError('Automatic weight downloads disabled; pinned files required')
 weights.weight_download=no_download
 dm=load(NS+'.data.dictionary',SRC/'data/dictionary.py');data.Dictionary=dm.Dictionary
 load(NS+'.models.transformers',SRC/'models/transformers.py')
 um=load(NS+'.models.unimol',SRC/'models/unimol.py')
 cf=load(NS+'.data.conformer',SRC/'data/conformer.py')
else:
 um=sys.modules[NS+'.models.unimol'];cf=sys.modules[NS+'.data.conformer'];dm=sys.modules[NS+'.data.dictionary']
_CKPT=None
def initial_state():
 global _CKPT
 if _CKPT is None:
  path=P/'mol_pre_no_h_220816.pt';assert sha(path)==WEIGHT_SHA
  state=torch.load(path,map_location='cpu',weights_only=True)
  if 'model' in state:state=state['model']
  elif 'model_state_dict' in state:state=state['model_state_dict']
  assert isinstance(state,dict) and all(isinstance(v,torch.Tensor) for v in state.values())
  _CKPT=state
 return _CKPT
class PinnedUniMol(um.UniMolModel):
 def load_pretrained_weights(self,path,strict=False):
  assert Path(path)==P/'mol_pre_no_h_220816.pt'
  original=initial_state();target=self.state_dict()
  missing=[k for k in target if k not in original]
  assert set(missing)=={'classification_head.out_proj.weight','classification_head.out_proj.bias'},missing
  used={k:original[k] for k in target if k in original}
  for k,v in used.items():assert v.shape==target[k].shape,k
  msg=self.load_state_dict(used,strict=False);assert set(msg.missing_keys)==set(missing) and not msg.unexpected_keys
  self.loading_report={'checkpoint_sha256':WEIGHT_SHA,'used_keys':list(used),'new_head_keys':missing,'unused_pretraining_keys':sorted(set(original)-set(used))}
def make_model(device='cpu',scope='all'):
 model=PinnedUniMol(output_dim=1,data_type='molecule',remove_hs=True,pooler_dropout=.1)
 assert len(model.encoder.layers)==15
 if scope=='top3':
  for n,p in model.named_parameters():p.requires_grad_(n.startswith(('encoder.layers.12.','encoder.layers.13.','encoder.layers.14.','classification_head.')))
 elif scope!='all':raise ValueError(scope)
 return model.to(device)
def dictionary():
 d=dm.Dictionary.load(str(P/'mol.dict.txt'));d.add_symbol('[MASK]',is_special=True);return d
def encode_geometry(rows):
 d=dictionary();out=[]
 for r in rows:
  assert len(r['atoms'])<=256 and len(r['atoms'])==len(r['coordinates'])
  x=cf.coords2unimol(r['atoms'],np.asarray(r['coordinates']),d,max_atoms=256,remove_hs=True)
  assert len(x['src_tokens'])==len(r['atoms'])+2 and not (x['src_tokens']==d.unk()).any()
  out.append(x)
 return out
def batch(items,indices,device):
 chosen=[items[i] for i in indices];n=max(len(x['src_tokens']) for x in chosen);b=len(chosen);pad=dictionary().pad()
 result={'src_tokens':torch.full((b,n),pad,dtype=torch.long),'src_distance':torch.zeros((b,n,n),dtype=torch.float32),'src_coord':torch.zeros((b,n,3),dtype=torch.float32),'src_edge_type':torch.full((b,n,n),pad,dtype=torch.long)}
 for i,x in enumerate(chosen):
  m=len(x['src_tokens']);result['src_tokens'][i,:m]=torch.as_tensor(x['src_tokens'])
  result['src_coord'][i,:m]=torch.as_tensor(x['src_coord'])
  for k in ['src_distance','src_edge_type']:result[k][i,:m,:m]=torch.as_tensor(x[k])
 return {k:v.to(device) for k,v in result.items()}
