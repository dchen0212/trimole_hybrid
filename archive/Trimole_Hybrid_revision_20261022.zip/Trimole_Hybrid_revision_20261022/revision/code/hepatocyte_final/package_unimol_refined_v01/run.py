"""Target-only fine-tuning of officially bound Uni-Mol 3D pretraining, with development-only recipe selection."""
import os
os.environ['CUDA_VISIBLE_DEVICES']='GPU-8dccd0a6-2c1e-0e9a-dda8-105662f17745'
for k in ['OMP_NUM_THREADS','OPENBLAS_NUM_THREADS','MKL_NUM_THREADS']:os.environ[k]='1'
import sys,json,hashlib,time,random,math,subprocess,traceback,copy
from pathlib import Path
import numpy as np
import torch
from scipy.stats import spearmanr
R=Path(__file__).resolve().parent
MODE=sys.argv[1] if len(sys.argv)>1 else 'import'
SEEDS=[101,202,303,404,505];EPOCHS=[8,16,32]
def guard(event,args):
 if event=='open' and isinstance(args[0],(str,bytes,os.PathLike)):
  name=Path(os.fsdecode(args[0])).name
  if MODE in ['cv','final','smoke'] and name=='test.csv':raise PermissionError('test labels forbidden in fitting workers')
  if MODE in ['cv','smoke'] and name in ['evaluation.json','evaluation_geometry.json']:raise PermissionError('evaluation structures forbidden in CV/smoke')
sys.addaudithook(guard)
def read(p):return json.loads(Path(p).read_text())
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,d):
 p=Path(p);p.parent.mkdir(parents=True,exist_ok=True)
 with p.open('x') as f:json.dump(d,f,indent=2,allow_nan=False)
def atomic(p,d):
 q=p.with_suffix('.pending');q.write_text(json.dumps(d,indent=2));os.replace(q,p)
def metric(y,p):
 value=float(spearmanr(y,p).statistic);assert np.isfinite(value);return value
def catalog():
 return [dict(id='u0',scope='all',loss='log',lr=1e-5),dict(id='u1',scope='all',loss='log',lr=1e-4),dict(id='u2',scope='all',loss='pair',lr=1e-5),dict(id='u3',scope='top3',loss='log',lr=1e-4)]
def verify():
 for p,h in read(R/'FREEZE.json')['files'].items():
  if MODE in ['cv','smoke'] and p in ['evaluation.json','evaluation_geometry.json']:continue
  assert sha(R/p)==h,p
 pins=read(R/'UNIMOL_SOURCE_BINDING.json')
 for p,h in pins['absolute_files'].items():assert sha(p)==h,p
 assert sha(read(R/'INPUT_BINDING.json')['source']['development_path'])==read(R/'INPUT_BINDING.json')['source']['development_sha256']
def seed_all(seed):
 random.seed(seed);np.random.seed(seed);torch.manual_seed(seed);torch.cuda.manual_seed_all(seed);torch.set_num_threads(2)
 torch.backends.cudnn.benchmark=False;torch.backends.cudnn.deterministic=True;torch.use_deterministic_algorithms(False)
def make_model(c):
 import unimol_adapter_v01 as adapter
 return adapter.make_model('cuda',c['scope'])
_GEO={}
def inputs(rows):
 import unimol_adapter_v01 as adapter
 part=rows[0]['region'];assert all(x['region']==part for x in rows)
 if part not in _GEO:
  p=R/f'{part}_geometry.json';assert sha(p)==read(R/'INPUT_BINDING.json')[part+'_geometry_sha256']
  d=read(p);assert d['labels_present'] is False
  features=adapter.encode_geometry(d['rows'])
  _GEO[part]={x['row_id']:v for x,v in zip(d['rows'],features)};assert len(_GEO[part])==len(d['rows'])
 return [_GEO[part][x['row_id']] for x in rows]
def batch(items,indices):
 import unimol_adapter_v01 as adapter
 return adapter.batch(items,indices,'cuda')
def forward(model,b):return model(**b).flatten()
def predict(model,items):
 model.eval();values=[]
 with torch.no_grad():
  for start in range(0,len(items),16):values.extend(forward(model,batch(items,list(range(start,min(start+16,len(items)))))).cpu().tolist())
 out=np.array(values);assert out.shape==(len(items),) and np.isfinite(out).all();return out

def train(c,seed,fit_rows,y,score_rows,max_epochs,directory,checkpoint_epochs):
 seed_all(seed);model=make_model(c);fit=inputs(fit_rows);ev=inputs(score_rows)
 initial={n:p.detach().cpu().clone() for n,p in model.named_parameters()};probe=next(n for n,p in model.named_parameters() if n.startswith('encoder.layers.') and p.ndim==2 and p.requires_grad)
 yy=np.log1p(y);mu=float(yy.mean());sd=float(yy.std()) or 1.;target=torch.tensor((yy-mu)/sd,dtype=torch.float32,device='cuda')
 opt=torch.optim.AdamW([{'params':[p for n,p in model.named_parameters() if p.requires_grad and not n.startswith('classification_head.')],'lr':c['lr']},{'params':model.classification_head.parameters(),'lr':5e-4}],weight_decay=.01)
 horizon=32*math.ceil(len(fit)/16);warmup=max(1,int(.1*horizon))
 schedule=lambda step:(step+1)/warmup if step<warmup else max(0.,(horizon-step)/(horizon-warmup))
 sched=torch.optim.lr_scheduler.LambdaLR(opt,schedule);rng=np.random.RandomState(seed);updates=0;records=[];started=time.time()
 directory.mkdir(parents=True,exist_ok=False)
 torch.save(initial,directory/'initial_parameters.pt')
 write(directory/'START.json',{'config':c,'loading':model.loading_report,'seed':seed,'fit_row_ids':[r['row_id'] for r in fit_rows],'score_row_ids':[r['row_id'] for r in score_rows],'initial_parameters_sha256':sha(directory/'initial_parameters.pt'),'initialization':'official Uni-Mol molecular pretraining; new regression head; no historical supervised checkpoint','cross_task_supervised_rows':0,'target_log_mean':mu,'target_log_sd':sd,'test_labels_used':False,'encoder_probe':probe,'source_binding_sha256':sha(R/'UNIMOL_SOURCE_BINDING.json'),'code_freeze_sha256':sha(R/'FREEZE.json')})
 for epoch in range(1,max_epochs+1):
  model.train();order=rng.permutation(len(fit));total=0.
  for start in range(0,len(fit),16):
   ix=order[start:start+16].tolist();opt.zero_grad(set_to_none=True);pred=forward(model,batch(fit,ix));loss=torch.nn.functional.smooth_l1_loss(pred,target[ix])
   if c['loss']=='pair':
    delta=target[ix][:,None]-target[ix][None,:];mask=torch.triu(torch.ones_like(delta,dtype=torch.bool),diagonal=1)&(delta!=0)
    ranking=torch.nn.functional.softplus(-(pred[:,None]-pred[None,:])*delta.sign())[mask].mean() if mask.any() else pred.sum()*0
    loss=ranking+.25*loss
   assert torch.isfinite(loss);loss.backward();torch.nn.utils.clip_grad_norm_(model.parameters(),1.,error_if_nonfinite=True);opt.step();sched.step();updates+=1;total+=float(loss.detach().cpu())*len(ix)
  rec={'epoch':epoch,'loss':total/len(fit),'updates':updates,'seconds':time.time()-started};records.append(rec);print(json.dumps(rec),flush=True)
  if epoch in checkpoint_epochs:
   pred=predict(model,ev);dest=directory/f'epoch{epoch:02d}';dest.mkdir()
   np.savez_compressed(dest/'predictions.npz',prediction=pred,row_ids=np.array([r['row_id'] for r in score_rows]))
   state={k:v.detach().cpu() for k,v in model.state_dict().items()};torch.save(state,dest/'checkpoint.pt')
   changed=[n for n,p in model.named_parameters() if not n.startswith('classification_head.') and not torch.equal(state[n],initial[n])];assert changed
   diff=float((state[probe]-initial[probe]).abs().max());assert diff>0
   write(dest/'SEAL.json',{'epoch':epoch,'config':c,'seed':seed,'fit_rows':len(fit),'prediction_rows':len(ev),'prediction_sha256':sha(dest/'predictions.npz'),'checkpoint_sha256':sha(dest/'checkpoint.pt'),'encoder_probe_max_abs_change':diff,'changed_encoder_tensors':len(changed),'initialization':'official Uni-Mol pretraining plus fresh target regression head','initial_parameters_sha256':sha(directory/'initial_parameters.pt'),'updates':updates,'input_binding_sha256':sha(R/'INPUT_BINDING.json'),'code_freeze_sha256':sha(R/'FREEZE.json')})
  atomic(directory/'PROGRESS.json',{'epoch':epoch,'max_epochs':max_epochs,'seconds':time.time()-started})
 write(directory/'COMPLETE.json',{'status':'COMPLETE','epochs':records,'seconds':time.time()-started})

def cv(cid,fi):
 verify();d=read(R/'development.json');f=read(R/'FOLDS.json')['folds'][fi];a,b=f['fit'],f['validation'];assert not set(a)&set(b)
 c=next(v for v in catalog() if v['id']==cid)
 train(c,101,[d['rows'][i] for i in a],np.array(d['y'])[a],[d['rows'][i] for i in b],32,R/'cv'/cid/f'fold{fi}',EPOCHS)
def select():
 d=read(R/'development.json');y=np.array(d['y']);folds=read(R/'FOLDS.json')['folds'];results=[]
 for c in catalog():
  for epoch in EPOCHS:
   oof=np.full(len(y),np.nan);scores=[];bindings=[]
   for fi,f in enumerate(folds):
    p=R/'cv'/c['id']/f'fold{fi}'/f'epoch{epoch:02d}';seal=read(p/'SEAL.json');assert sha(p/'predictions.npz')==seal['prediction_sha256']
    with np.load(p/'predictions.npz') as z:pred=z['prediction'];assert z['row_ids'].tolist()==[d['rows'][i]['row_id'] for i in f['validation']]
    oof[f['validation']]=pred;scores.append(metric(y[f['validation']],pred));bindings.append(sha(p/'SEAL.json'))
   assert np.isfinite(oof).all();path=R/'selection_oof'/f"{c['id']}_epoch{epoch:02d}.npz";path.parent.mkdir(exist_ok=True);np.savez_compressed(path,prediction=oof)
   results.append({'config':c,'epochs':epoch,'fold_scores':scores,'cv_score':float(np.mean(scores)),'oof_sha256':sha(path),'fold_seal_sha256':bindings})
 chosen=sorted(results,key=lambda x:(-x['cv_score'],x['config']['id'],x['epochs']))[0]
 write(R/'SELECTION_FREEZE.json',{'selected':chosen,'all_candidates':results,'unix':time.time(),'test_used_for_selection':False,'historical_test_exposure':True})
def final(seed):
 verify();d=read(R/'development.json');ev=read(R/'evaluation.json');assert ev['labels_present'] is False and sha(R/'evaluation.json')==read(R/'INPUT_BINDING.json')['evaluation_sha256'];s=read(R/'SELECTION_FREEZE.json')['selected']
 train(s['config'],seed,d['rows'],np.array(d['y']),ev['rows'],s['epochs'],R/'final'/f'seed{seed}',[s['epochs']])
def evaluate():
 import pandas as pd
 s=read(R/'SELECTION_FREEZE.json')['selected'];paths=[R/'final'/f'seed{x}'/f"epoch{s['epochs']:02d}" for x in SEEDS]
 write(R/'ALL_PREDICTIONS_FROZEN.json',{str(p.relative_to(R)):sha(p/'SEAL.json') for p in paths})
 write(R/'TEST_ACCESS_STARTED.json',{'unix':time.time(),'selection_sha256':sha(R/'SELECTION_FREEZE.json'),'all_seals_sha256':sha(R/'ALL_PREDICTIONS_FROZEN.json')})
 source=Path(read(R/'INPUT_BINDING.json')['source']['development_path']).with_name('test.csv');assert sha(source)=='23e061c3fdc2627707c099be6a3082a55fd928a1f19e555f6f4f4b734ed8d314'
 table=pd.read_csv(source);ev=read(R/'evaluation.json')['rows'];ix=[r['source_row'] for r in ev];assert sorted(ix)==list(range(len(table))) and table.iloc[ix].Drug.tolist()==[r['raw_smiles'] for r in ev];scores=[]
 for seed,p in zip(SEEDS,paths):
  assert sha(p/'predictions.npz')==read(p/'SEAL.json')['prediction_sha256']
  with np.load(p/'predictions.npz') as z:pred=z['prediction'];assert z['row_ids'].tolist()==[r['row_id'] for r in ev]
  scores.append({'seed':seed,'spearman':metric(table.iloc[ix].Y.to_numpy(),pred)})
 vals=[r['spearman'] for r in scores]
 write(R/'RESULTS.json',{'task':'clearance_hepatocyte_az','method':'target-only official Uni-Mol 3D encoder fine-tuning','rows':scores,'mean':float(np.mean(vals)),'population_sd':float(np.std(vals)),'test_sha256':sha(source),'test_rows':len(ev),'benchmark_reuse':True})
def worker(args):
 p=R/'logs'/('_'.join(args)+'.log');p.parent.mkdir(exist_ok=True)
 with p.open('x') as log:
  proc=subprocess.Popen([sys.executable,'-B',str(R/'run.py'),*args],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  try:rc=proc.wait(timeout=7200)
  except subprocess.TimeoutExpired:
   import signal
   os.killpg(proc.pid,signal.SIGKILL);proc.wait();raise
 assert rc==0,(args,rc)
def controller():
 state={'status':'CV_RUNNING','started_unix':time.time(),'completed':[]};atomic(R/'STATUS.json',state)
 try:
  for c in catalog():
   for fi in range(3):
    args=['cv',c['id'],str(fi)];worker(args);state['completed'].append(args);atomic(R/'STATUS.json',state)
  select();state['status']='FINAL_REFIT';atomic(R/'STATUS.json',state)
  for seed in SEEDS:
   args=['final',str(seed)];worker(args);state['completed'].append(args);atomic(R/'STATUS.json',state)
  evaluate();state['status']='FINISHED_REQUIRES_REVIEW'
 except Exception as exc:state.update(status='FAILED',error=repr(exc),traceback=traceback.format_exc())
 state['ended_unix']=time.time();atomic(R/'STATUS.json',state)
def smoke():
 verify();d=read(R/'development.json');f=read(R/'FOLDS.json')['folds'][0];a=f['fit'][:16];b=f['validation'][:8];c=catalog()[0]
 train(c,7,[d['rows'][i] for i in a],np.array(d['y'])[a],[d['rows'][i] for i in b],1,R/'smoke',[1])
 write(R/'SELFTEST.json',{'status':'PASS','scope':'One GPU epoch from bound official pretraining, fitting/validation rows disjoint, real encoder updates, finite predictions. Not a benchmark score.'})
if __name__=='__main__':
 if MODE=='cv':cv(sys.argv[2],int(sys.argv[3]))
 elif MODE=='final':final(int(sys.argv[2]))
 elif MODE=='controller':controller()
 elif MODE=='smoke':smoke()
