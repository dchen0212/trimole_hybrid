from pathlib import Path
import json,hashlib,time
import numpy as np
from rdkit import Chem
import run as m
R=m.R;m.verify();assert m.catalog()==m.read(R/'CATALOG.json')
dev=m.read(R/'development.json');rows=dev['rows'];folds=m.read(R/'FOLDS.json')['folds'];identities=[Chem.MolToSmiles(Chem.MolFromSmiles(x['raw_smiles']),canonical=True,isomericSmiles=True) for x in rows]
cover=np.zeros(len(rows),int)
for f in folds:
 a,b=f['fit'],f['validation'];assert not set(a)&set(b) and set(a)|set(b)==set(range(len(rows)))
 assert not {identities[i] for i in a}&{identities[i] for i in b};cover[b]+=1
assert (cover==1).all() and len(rows)==970
inputs=m.inputs([rows[i] for i in folds[0]['fit'][:2]])
assert len(inputs)==2 and all(np.isfinite(x['src_distance']).all() for x in inputs)
from scipy.stats import rankdata,spearmanr
B=R.parent/'trimole_target_only_expanded_20261013_v02';C=R.parent/'trimole_hepatocyte_kpgt_finetune_20261014_v02';D=R.parent/'trimole_hepatocyte_staged_kpgt_20261014_v03';task='clearance_hepatocyte_az'
reg=m.read(R/'BLEND_REGISTRATION.json')
for path,h in reg['reference_hashes'].items():assert m.sha(path)==h
rank=lambda v:rankdata(v,method='average')/len(v)
def load(p):
 with np.load(p,allow_pickle=False) as z:return z['prediction'].copy()
base=m.read(B/'SELECTION_FREEZE.json')[task];old=[]
for cid in base['selected']['members']:
 p=B/task/'candidates'/cid/'OOF.npz';assert m.sha(p)==base['members'][cid]['oof_sha256'];old.append(load(p))
cs=m.read(C/'SELECTION_FREEZE.json')['selected'];ds=m.read(D/'SELECTION_FREEZE.json')['selected']
cp=C/'selection_oof'/f"{cs['config']['id']}_epoch{cs['epochs']:02d}.npz";dp=D/'selection_oof'/f"{ds['config']['id']}_epoch{ds['epochs']:02d}.npz"
assert m.sha(cp)==cs['oof_sha256'] and m.sha(dp)==ds['oof_sha256'];canonical=load(cp);staged=load(dp)
cw=m.read(C/'BLEND_SELECTION_FREEZE.json')['selected'];dw=m.read(D/'BLEND_SELECTION_FREEZE.json')['selected'];assert dw['anchor']=='prior_fused'
ref_scores={'prior_fused':[],'staged_fused':[]};y=np.array(dev['y'])
for f in folds:
 ix=f['validation'];b=np.mean([rank(z[ix]) for z in old],axis=0);c=(1-cw['fine_tune_weight'])*rank(b)+cw['fine_tune_weight']*rank(canonical[ix]);d=(1-dw['fine_tune_weight'])*rank(c)+dw['fine_tune_weight']*rank(staged[ix])
 ref_scores['prior_fused'].append(float(spearmanr(y[ix],c).statistic));ref_scores['staged_fused'].append(float(spearmanr(y[ix],d).statistic))
assert np.allclose(ref_scores['prior_fused'],cw['fold_scores'],atol=1e-12,rtol=0)
assert np.allclose(ref_scores['staged_fused'],dw['fold_scores'],atol=1e-12,rtol=0)
m.write(R/'PREFLIGHT.json',{'status':'PASS','unix':time.time(),'development_rows':970,'canonical_molecules':len(set(identities)),'folds_disjoint_and_complete':True,'source_and_geometry_hashes_verified':True,'native_input_conversion_checked':True,'reference_development_scores_replayed':ref_scores,'models_fitted':0,'GPU_allocated':False,'scope':'Input and source preflight; GPU training check occurs only after upstream queue release'})
print('PREFLIGHT PASS')
