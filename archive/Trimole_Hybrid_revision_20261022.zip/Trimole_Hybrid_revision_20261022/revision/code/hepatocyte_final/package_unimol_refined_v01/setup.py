"""Bind prepared files and freeze this new experiment before any GPU training."""
from pathlib import Path
import json,hashlib,time,os,subprocess,ast
R=Path(__file__).resolve().parent
P=R.parent/'trimole_hepatocyte_unimol_preparation_20261014_v01'
C=R.parent/'trimole_hepatocyte_kpgt_finetune_20261014_v02'
E=R.parent/'trimole_hepatocyte_ept_targetonly_20261014_v01'
D=R.parent/'trimole_hepatocyte_staged_kpgt_20261014_v03'
B=R.parent/'trimole_target_only_expanded_20261013_v02'
G={'development':R.parent/'trimole_hepatocyte_geometry_refinement_20261014_v01','evaluation':R.parent/'trimole_hepatocyte_geometry_refinement_evaluation_20261014_v01'}
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(n,x):
 with (R/n).open('x') as f:json.dump(x,f,indent=2,allow_nan=False)
def copy(src,n):
 with (R/n).open('xb') as f:f.write(src.read_bytes())
 assert sha(R/n)==sha(src)
assert not (R/'FREEZE.json').exists() and not (R/'STATUS.json').exists()
for p,h in read(R/'UPLOAD_MANIFEST.json').items():assert sha(R/p)==h,p
comparison=read(R/'COMPARISON_BINDING_v01.json')
for name,h in comparison['unchanged_files'].items():
 assert sha(Path(comparison['original_experiment'])/name)==sha(R/name)==h,name
ob=read(P/'OFFICIAL_BINDING_v01.json');ready=read(P/'CPU_READINESS_SMOKE_v02.json');geo=read(P/'GEOMETRY_MAPPING_RECEIPT_v01.json')
assert ob['status']==ready['status']==geo['status']=='PASS'
assert ready['adapter_sha256']==sha(R/'unimol_adapter_v01.py')
absolute={}
for path,h in ob['used_official_source_files'].items():
 p=P/'source_files_v03'/path;assert sha(p)==h;absolute[str(p)]=h
for n in ['mol_pre_no_h_220816.pt','mol.dict.txt','SOURCE_RETRIEVAL_v03.json','OFFICIAL_BINDING_v01.json','CPU_READINESS_SMOKE_v02.json','ADDICT_BINDING_v01.json']:
 absolute[str(P/n)]=sha(P/n)
assert absolute[str(P/'mol_pre_no_h_220816.pt')]==ob['weight_sha256']
assert absolute[str(P/'mol.dict.txt')]==ob['dictionary_sha256']
for p in sorted((P/'vendor_addict_v01').rglob('*.py')):absolute[str(p)]=sha(p)
write('UNIMOL_SOURCE_BINDING.json',{'official_binding':ob,'absolute_files':absolute,'scope':'Only bound core modules plus explicit offline/batching adapter; upstream corpus membership unresolved'})
for n in ['development.json','evaluation.json','FOLDS.json']:copy(C/n,n)
geometry_receipts={}
for part in ['development','evaluation']:
 g=G[part];review=read(g/'GEOMETRY_REVIEW_v01.json');assert review['status']=='PASS' and not review['nonconverged_rows_retained']
 src=g/(part+'_geometry_refined_v01.json');assert sha(src)==review['dataset_sha256']
 copy(src,part+'_geometry.json')
 geometry_receipts[part]={'directory':str(g),'review':review,'review_sha256':sha(g/'GEOMETRY_REVIEW_v01.json'),'registration_sha256':sha(g/'GEOMETRY_REGISTRATION.json'),'refinement_script_sha256':sha(g/'refine.py')}
write('GEOMETRY_SOURCE_RECEIPT.json',{'status':'PASS','parts':geometry_receipts,'scope':'Paired MMFF94s or UFF refinement of inherited conformers; no geometry choice based on labels or scores'})
source=read(C/'INPUT_BINDING.json')['source']
write('INPUT_BINDING.json',{'source':source,'development_sha256':sha(R/'development.json'),'evaluation_sha256':sha(R/'evaluation.json'),'folds_sha256':sha(R/'FOLDS.json'),'development_geometry_sha256':sha(R/'development_geometry.json'),'evaluation_geometry_sha256':sha(R/'evaluation_geometry.json'),'unimol_source_binding_sha256':sha(R/'UNIMOL_SOURCE_BINDING.json')})
for part in ['development','evaluation']:
 rows=read(R/(part+'.json'))['rows'];g=read(R/(part+'_geometry.json'))
 assert not g['labels_present'] and [(x['row_id'],x['raw_smiles'],x['source_row']) for x in rows]==[(x['row_id'],x['raw_smiles'],x['source_row']) for x in g['rows']]
 assert all(len(x['atoms'])<=256 for x in g['rows'])
catalog=[dict(id='u0',scope='all',loss='log',lr=1e-5),dict(id='u1',scope='all',loss='log',lr=1e-4),dict(id='u2',scope='all',loss='pair',lr=1e-5),dict(id='u3',scope='top3',loss='log',lr=1e-4)]
write('CATALOG.json',catalog)
env=read(E/'ENVIRONMENT.json');env['environment']={k:v.replace(str(E),str(R)) if isinstance(v,str) else v for k,v in env['environment'].items()}
write('ENVIRONMENT.json',env)
for p in R.glob('*.py'):compile(p.read_text(),str(p),'exec')
write('FREEZE.json',{'unix':time.time(),'files':{p.name:sha(p) for p in sorted(R.iterdir()) if p.is_file()},'epochs':[8,16,32],'seeds':[101,202,303,404,505],'test_exposure':'historical and earlier adaptive rounds; benchmark reuse'})
refs=[B/'SELECTION_FREEZE.json']
for base in [C,D]:refs += [base/n for n in ['SELECTION_FREEZE.json','BLEND_SELECTION_FREEZE.json','BLEND_RESULTS.json','BLEND_REVIEW_v01.json','REVIEW_COMPLETE.json']]
write('BLEND_REGISTRATION.json',{'unix':time.time(),'script_sha256':sha(R/'blend.py'),'protocol_sha256':sha(R/'BLEND_ADDENDUM.md'),'reference_hashes':{str(p):sha(p) for p in refs},'stage_training_started':False,'staged_test_access_exists':False,'earlier_test_results_known':True,'reference_selection_basis':'Three references explicitly registered before Uni-Mol training; choose among 15 rank options using development folds only.'})
write('REGISTRATION.json',{'unix':time.time(),'freeze_sha256':sha(R/'FREEZE.json'),'protocol_sha256':sha(R/'PROTOCOL.md'),'catalog':catalog,'cv_trajectories':12,'cv_checkpoints':36,'final_fits':5,'supervised_data':'target-only development rows','prior_test_results_known':True,'queue_after':str(E),'healthy_GPU_UUID':'GPU-8dccd0a6-2c1e-0e9a-dda8-105662f17745'})
with (R/'preflight.log').open('x') as log:subprocess.run([env['python'],'-B',str(R/'preflight.py')],cwd=R,env={**os.environ,**env['environment']},stdout=log,stderr=subprocess.STDOUT,check=True)
assert read(R/'PREFLIGHT.json')['status']=='PASS'
print({'status':'REGISTERED','freeze_sha256':sha(R/'FREEZE.json'),'GPU_training_started':False})
