"""Replay every final Uni-Mol model and bind its captured starting encoder to official weights."""
import json
import numpy as np
import torch
from rdkit import Chem
import run as m
import unimol_adapter_v01 as adapter
R=m.R;m.verify();s=m.read(R/'SELECTION_FREEZE.json')['selected']
dev=m.read(R/'development.json');folds=m.read(R/'FOLDS.json')['folds'];canonical=[Chem.MolToSmiles(Chem.MolFromSmiles(x['raw_smiles']),canonical=True,isomericSmiles=True) for x in dev['rows']]
for fold in folds:assert not {canonical[i] for i in fold['fit']}&{canonical[i] for i in fold['validation']}
rows=m.read(R/'evaluation.json')['rows'];items=m.inputs(rows);original=adapter.initial_state();results=[]
for seed in m.SEEDS:
 root=R/'final'/f'seed{seed}';dest=root/f"epoch{s['epochs']:02d}";start=m.read(root/'START.json');seal=m.read(dest/'SEAL.json')
 assert m.sha(dest/'checkpoint.pt')==seal['checkpoint_sha256']
 assert m.sha(root/'initial_parameters.pt')==start['initial_parameters_sha256']==seal['initial_parameters_sha256']
 initial=torch.load(root/'initial_parameters.pt',map_location='cpu',weights_only=True)
 state=torch.load(dest/'checkpoint.pt',map_location='cpu',weights_only=True)
 model=m.make_model(s['config']);assert start['loading']==model.loading_report
 model.load_state_dict(state,strict=True);changed=[];frozen=[]
 for n,p in model.named_parameters():
  assert n in initial
  if not n.startswith('classification_head.'):assert torch.equal(initial[n],original[n]),n
  if not p.requires_grad:assert torch.equal(state[n],initial[n]),n;frozen.append(n)
  elif not n.startswith('classification_head.') and not torch.equal(state[n],initial[n]):changed.append(n)
 assert len(changed)==seal['changed_encoder_tensors'] and any(x.startswith('encoder.layers.') for x in changed)
 pred=m.predict(model,items)
 with np.load(dest/'predictions.npz',allow_pickle=False) as z:old=z['prediction'];assert z['row_ids'].tolist()==[x['row_id'] for x in rows]
 assert np.allclose(pred,old,atol=1e-5,rtol=1e-5),(seed,float(np.max(abs(pred-old))))
 results.append({'seed':seed,'changed_non_head_tensors':len(changed),'unchanged_frozen_parameters':len(frozen),'all_initial_non_head_parameters_equal_official':True,'max_prediction_abs_difference':float(np.max(abs(pred-old)))})
 del initial,state,model;torch.cuda.empty_cache()
m.write(R/'MODEL_REPLAY.json',{'status':'PASS','rows':results,'canonical_molecule_disjoint_cv':True,'test_labels_read':False,'prediction_tolerance':{'atol':1e-5,'rtol':1e-5},'scope':'Five saved Uni-Mol states replayed; initial non-head parameters bound to official pretrained bytes; not a second independent retraining.'})
print(json.dumps(results,indent=2))
