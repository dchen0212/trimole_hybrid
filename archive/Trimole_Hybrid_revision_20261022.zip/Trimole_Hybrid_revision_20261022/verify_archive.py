from pathlib import Path
import json, hashlib
root = Path(__file__).resolve().parent
records = json.loads((root / 'MANIFEST_SHA256.json').read_text())
for record in records:
    file = root / record['path']
    assert file.stat().st_size == record['bytes'], record['path']
    assert hashlib.sha256(file.read_bytes()).hexdigest() == record['sha256'], record['path']
print(f"PASS: {len(records)} files verified; no experiment executed")
